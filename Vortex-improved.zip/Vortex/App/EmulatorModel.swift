//
//  EmulatorModel.swift
//  Vortex
//
//  Owns the core handle, the frame loop and the measured dashboard state.
//  Everything runs on the main thread.
//

import Foundation
import QuartzCore

final class EmulatorModel: ObservableObject {
    @Published private(set) var snapshot: PerformanceSnapshot = .placeholder
    @Published private(set) var failureMessage: String?
    @Published private(set) var isPaused: Bool = false
    @Published var isFullScreenPresented: Bool = false
    @Published var isShowingEnvironment = false

    /// The frame limit the user asked for. `effectiveFrameLimit` is what the
    /// renderer is actually running at after thermal pacing.
    @Published var frameLimit: FrameLimitTarget = .fps120 {
        didSet {
            requestedFrameLimit = frameLimit
            applyFrameLimit(frameLimit)
            publishSnapshot()
        }
    }

    @Published private(set) var effectiveFrameLimit: FrameLimitTarget = .fps120
    @Published private(set) var thermalNotice: String?
    @Published private(set) var adaptiveScale: Double = 1.0

    /// True while the scale is being decided from measured frame time.
    @Published var isAdaptiveResolutionEnabled = true {
        didSet {
            if !isAdaptiveResolutionEnabled {
                adaptive.reset()
                adaptiveScale = 1.0
            }
        }
    }

    @Published var isShowingJITStatus = false

    let core: VortexCoreHandle
    let loop: FrameLoop
    let jit: JITCoordinator

    private var fullScreenLoop: FrameLoop?
    private var latestReport: FrameLoop.FrameReport?
    private var lastSnapshotTime: Double = 0
    private var requestedFrameLimit: FrameLimitTarget = .fps120
    private var adaptive = AdaptiveResolution()

    init() {
        let core = VortexCoreHandle()
        let loop = FrameLoop(core: core)

        self.core = core
        self.loop = loop
        self.jit = JITCoordinator()

        loop.limit = .fps120
        loop.onReport = { [weak self] report in
            self?.receive(report)
        }
        loop.onFailure = { [weak self] message in
            self?.failureMessage = message
        }

        core.loadFilesystem(from: GuestFilesystem.containerURL.path)
        publishSnapshot()
    }

    private func applyFrameLimit(_ target: FrameLimitTarget) {
        effectiveFrameLimit = target
        loop.limit = target
        fullScreenLoop?.limit = target
    }

    // MARK: - Reporting

    private func receive(_ report: FrameLoop.FrameReport) {
        latestReport = report

        let now = CACurrentMediaTime()
        guard now - lastSnapshotTime >= 0.1 else { return }
        lastSnapshotTime = now

        applyThermalPacing()
        applyAdaptiveResolution(report)
        publishSnapshot()
    }

    /// Drops the target when the device is hot or in low-power mode. Never raises
    /// it: the user asks again, or relaunches.
    private func applyThermalPacing() {
        let processInfo = ProcessInfo.processInfo
        let thermal = ThermalLevel(thermalState: processInfo.thermalState)

        guard let target = ThermalPacing.recommendedTarget(thermal: thermal,
                                                           isLowPowerMode: processInfo.isLowPowerModeEnabled,
                                                           requested: requestedFrameLimit) else {
            return
        }
        guard target != effectiveFrameLimit else { return }

        applyFrameLimit(target)
        thermalNotice = ThermalPacing.reason(thermal: thermal,
                                             isLowPowerMode: processInfo.isLowPowerModeEnabled)
    }

    private func applyAdaptiveResolution(_ report: FrameLoop.FrameReport) {
        guard isAdaptiveResolutionEnabled else { return }
        guard report.frameTimeMs > 0 else { return }
        let budget = effectiveFrameLimit.budgetMs(refreshRate: report.displayRefreshRate)
        if let newScale = adaptive.record(frameTimeMs: report.frameTimeMs, budgetMs: budget) {
            adaptiveScale = newScale
        }
    }

    func publishSnapshot() {
        let stats = core.stats
        let processInfo = ProcessInfo.processInfo
        let refreshRate = latestReport?.displayRefreshRate ?? snapshot.displayRefreshRate

        snapshot = PerformanceSnapshot(measuredFPS: isPaused ? 0 : (latestReport?.measuredFPS ?? 0),
                                       frameTimeMs: latestReport?.frameTimeMs ?? 0,
                                       frameTimeSamples: latestReport?.frameTimeSamples ?? [],
                                       gpuTimeMs: latestReport?.gpuTimeMs,
                                       budgetMs: effectiveFrameLimit.budgetMs(refreshRate: refreshRate),
                                       memoryFootprintBytes: MemoryProbe.footprintBytes(),
                                       thermal: ThermalLevel(thermalState: processInfo.thermalState),
                                       isLowPowerMode: processInfo.isLowPowerModeEnabled,
                                       framesPresented: stats.framesPresented,
                                       framesSkipped: stats.framesSkipped,
                                       instructionsExecuted: stats.instructionsExecuted,
                                       emulationErrors: stats.emulationErrors,
                                       guestTicks: stats.guestTicks,
                                       guestWidth: stats.guestWidth,
                                       guestHeight: stats.guestHeight,
                                       renderScale: latestReport?.renderScale ?? snapshot.renderScale,
                                       displayRefreshRate: refreshRate,
                                       guestProcesses: stats.guestProcesses,
                                       guestRunning: stats.guestRunning,
                                       syscallsServiced: stats.syscallsServiced)
    }

    // MARK: - Controls

    func togglePause() {
        isPaused.toggle()
        loop.isPaused = isPaused
        publishSnapshot()
    }

    func resetMetrics() {
        loop.resetMetrics()
        latestReport = nil
        adaptive.reset()
        adaptiveScale = 1.0
        thermalNotice = nil
        applyFrameLimit(requestedFrameLimit)
        publishSnapshot()
    }

    func dismissThermalNotice() {
        thermalNotice = nil
    }

    // MARK: - Guest control

    /// Boots the framebuffer painter on the host display.
    func startPainter() {
        let result = core.launchSample(.painter)
        failureMessage = result >= 0 ? nil : (core.runtimeErrorText ?? "The runtime refused the launch.")
    }

    func stopGuests() {
        core.stopGuests()
    }

    // MARK: - Full screen session

    func beginFullScreenSession(with fullScreenLoop: FrameLoop) {
        self.fullScreenLoop = fullScreenLoop
        fullScreenLoop.limit = effectiveFrameLimit
        fullScreenLoop.onReport = { [weak self] report in
            self?.receive(report)
        }
        loop.isPaused = true
    }

    func endFullScreenSession() {
        fullScreenLoop?.detach()
        fullScreenLoop = nil
        loop.isPaused = isPaused
        publishSnapshot()
    }
}
