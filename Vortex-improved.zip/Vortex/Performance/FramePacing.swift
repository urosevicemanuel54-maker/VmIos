//
//  FramePacing.swift
//  Vortex
//
//  Frame-limit targets, the presentation gate and frame-interval measurement.
//  Everything here is pure arithmetic so it can be tested without a display.
//

import Foundation
import QuartzCore

/// Frame limit choices offered by the display bar.
enum FrameLimitTarget: Int, CaseIterable, Identifiable {
    case fps30
    case fps60
    case fps120
    case displayMax

    var id: Int { rawValue }

    var title: String {
        switch self {
        case .fps30: return "30"
        case .fps60: return "60"
        case .fps120: return "120"
        case .displayMax: return "Max"
        }
    }

    var accessibilityTitle: String {
        switch self {
        case .fps30: return "30 frames per second"
        case .fps60: return "60 frames per second"
        case .fps120: return "120 frames per second"
        case .displayMax: return "Display maximum"
        }
    }

    /// The measurable rate requested by this target, or nil when the display
    /// is allowed to run as fast as it can.
    var framesPerSecond: Double? {
        switch self {
        case .fps30: return 30
        case .fps60: return 60
        case .fps120: return 120
        case .displayMax: return nil
        }
    }

    /// Minimum spacing between presented frames. Zero means "no gate".
    func targetInterval(refreshRate: Double) -> Double {
        guard let fps = framesPerSecond, fps > 0 else { return 0 }
        return 1.0 / fps
    }

    /// The frame-time budget shown in the dashboard, in milliseconds.
    func budgetMs(refreshRate: Double) -> Double {
        if let fps = framesPerSecond { return 1000.0 / fps }
        return 1000.0 / max(1.0, refreshRate)
    }

    /// Range handed to CADisplayLink so the system paces the display to us.
    func preferredRange(maxRefreshRate: Float) -> CAFrameRateRange {
        let ceiling = max(30, maxRefreshRate)
        if let fps = framesPerSecond {
            let rate = min(Float(fps), ceiling)
            return CAFrameRateRange(minimum: rate, maximum: rate, preferred: rate)
        }
        return CAFrameRateRange(minimum: 0, maximum: ceiling, preferred: ceiling)
    }
}

/// Rejects display-link callbacks that arrive faster than the chosen target.
///
/// The display link cannot always be told to fire at exactly the rate we want
/// (a 60 Hz request on a 120 Hz panel still delivers 120 callbacks on some
/// configurations), so the gate is what actually enforces the limit.
struct FrameLimiter {
    /// Spacing between accepted frames in seconds. Zero disables the gate.
    var targetInterval: Double
    private(set) var lastAcceptedTime: Double?
    private(set) var skippedFrames: UInt64 = 0

    init(targetInterval: Double = 0) {
        self.targetInterval = max(0, targetInterval)
    }

    mutating func reset() {
        lastAcceptedTime = nil
        skippedFrames = 0
    }

    /// Returns true when a frame may be rendered at `time` (seconds).
    mutating func shouldRender(at time: Double) -> Bool {
        guard targetInterval > 0 else { return true }
        guard let last = lastAcceptedTime else {
            lastAcceptedTime = time
            return true
        }

        let elapsed = time - last
        let tolerance = targetInterval * 0.05
        if elapsed + tolerance < targetInterval {
            skippedFrames += 1
            return false
        }

        var next = last + targetInterval
        if time - next > targetInterval {
            next = time
        }
        lastAcceptedTime = next
        return true
    }
}

/// Picks a frame limit from thermal pressure and low-power mode.
///
/// The rule is deliberately blunt: only the hottest states or low-power mode
/// change anything, and the target never rises on its own — a device that was
/// throttled stays throttled until the caller explicitly re-arms it, so the
/// frame rate does not oscillate between two bands.
enum ThermalPacing {
    /// Targets considered in order of preference.
    static func recommendedTarget(thermal: ThermalLevel,
                                  isLowPowerMode: Bool,
                                  requested: FrameLimitTarget) -> FrameLimitTarget? {
        let ceiling: FrameLimitTarget
        if isLowPowerMode || thermal == .critical {
            ceiling = .fps30
        } else if thermal == .serious {
            ceiling = .fps60
        } else {
            return nil
        }

        // Only lower the target: a user who asked for 30 keeps 30 on a cool
        // device, and a hot device never exceeds the ceiling.
        return requested.rank > ceiling.rank ? ceiling : nil
    }

    /// Why the target was changed, for the banner.
    static func reason(thermal: ThermalLevel, isLowPowerMode: Bool) -> String {
        if isLowPowerMode {
            return "Low Power Mode is on, so the frame limit dropped to 30."
        }
        switch thermal {
        case .critical:
            return "The device reported critical thermal pressure, so the frame limit dropped to 30."
        case .serious:
            return "The device reported serious thermal pressure, so the frame limit dropped to 60."
        case .fair, .nominal:
            return "Thermal pressure eased."
        }
    }
}

extension FrameLimitTarget {
    /// Ordering used to compare targets: more frames per second is higher.
    var rank: Int {
        switch self {
        case .fps30: return 0
        case .fps60: return 1
        case .fps120: return 2
        case .displayMax: return 3
        }
    }
}

/// Decides the render scale from a sustained miss of the frame-time budget.
///
/// Scaling only ever steps one notch at a time and only after the budget has
/// been missed for a whole window, so a single slow frame cannot make the image
/// flicker between resolutions.
struct AdaptiveResolution {
    /// Available scales, highest first, mapped to the multiplier the renderer
    /// applies to the guest raster.
    static let steps: [Double] = [1.0, 0.85, 0.7, 0.5]
    static let minimumScale: Double = 0.5

    private(set) var scale: Double = 1.0
    private var overBudgetSeconds: Double = 0

    /// Seconds of sustained overshoot before the scale drops.
    var window: Double = 1.5

    mutating func reset() {
        scale = 1.0
        overBudgetSeconds = 0
    }

    /// Feeds one measured frame. Returns the new scale when it changed.
    mutating func record(frameTimeMs: Double, budgetMs: Double) -> Double? {
        guard budgetMs > 0, frameTimeMs.isFinite, frameTimeMs >= 0 else { return nil }

        if frameTimeMs > budgetMs * 1.15 {
            overBudgetSeconds += frameTimeMs / 1000.0
        } else {
            // Recover the window slowly, so one good frame does not cancel a
            // sustained overshoot.
            overBudgetSeconds = max(0, overBudgetSeconds - frameTimeMs / 1000.0 * 0.5)
        }

        guard overBudgetSeconds >= window, scale > AdaptiveResolution.minimumScale else { return nil }
        guard let index = AdaptiveResolution.steps.firstIndex(of: scale),
              index + 1 < AdaptiveResolution.steps.count else { return nil }

        scale = AdaptiveResolution.steps[index + 1]
        overBudgetSeconds = 0
        return scale
    }
}


struct FrameIntervalSampler {
    private(set) var intervals: [Double] = []
    private var timestamps: [Double] = []
    private let intervalCapacity: Int
    private let window: Double

    init(intervalCapacity: Int = 90, window: Double = 1.0) {
        self.intervalCapacity = max(2, intervalCapacity)
        self.window = max(0.25, window)
    }

    mutating func record(timestamp: Double) {
        if let previous = timestamps.last {
            let delta = timestamp - previous
            if delta > 0 {
                intervals.append(delta)
                if intervals.count > intervalCapacity {
                    intervals.removeFirst(intervals.count - intervalCapacity)
                }
            }
        }

        timestamps.append(timestamp)
        let cutoff = timestamp - window
        while timestamps.count > 2, let first = timestamps.first, first < cutoff {
            timestamps.removeFirst()
        }
    }

    /// Frames per second over the sampling window, measured from timestamps.
    var measuredFramesPerSecond: Double {
        guard timestamps.count >= 2,
              let first = timestamps.first,
              let last = timestamps.last,
              last > first else {
            return 0
        }
        return Double(timestamps.count - 1) / (last - first)
    }

    var averageFrameTimeMs: Double {
        guard !intervals.isEmpty else { return 0 }
        let total = intervals.reduce(0, +)
        return (total / Double(intervals.count)) * 1000.0
    }

    /// Interval history in milliseconds, newest last, for the sparkline.
    var recentIntervalsMs: [Double] {
        intervals.map { $0 * 1000.0 }
    }
}
