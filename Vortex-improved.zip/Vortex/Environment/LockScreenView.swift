//
//  LockScreenView.swift
//  Vortex
//
//  The lock screen shown while the simulated environment boots: a large clock,
//  the boot progress readout, and the swipe-up unlock gesture.
//
//  This is an original Vortex interface, not Apple's lock screen.
//

import SwiftUI

struct LockScreenView: View {
    @ObservedObject var environment: GuestEnvironmentModel

    @State private var dragOffset: CGFloat = 0
    @State private var isSwiping = false
    @State private var startedAt = Date()

    private var stage: GuestEnvironmentModel.BootStage { environment.bootStage }

    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                Spacer(minLength: 0)

                TimelineView(.periodic(from: .now, by: 60)) { context in
                    VStack(spacing: 6) {
                        Text(SimulatedClock.timeString(elapsed: context.date.timeIntervalSince(startedAt)))
                            .font(.system(size: 78, weight: .thin, design: .rounded))
                            .monospacedDigit()
                            .foregroundStyle(.white)
                            .shadow(color: .black.opacity(0.28), radius: 12, y: 4)

                        Text(dateString(context.date))
                            .font(.system(size: 16, weight: .medium))
                            .foregroundStyle(Color.white.opacity(0.78))
                    }
                }

                Spacer(minLength: 0)

                bootPanel
                    .padding(.horizontal, 26)
                    .padding(.bottom, 22)

                unlockHint
                    .padding(.bottom, 26)
            }
            .offset(y: dragOffset)
            .opacity(1 - min(dragOffset / -320, 0.6))
            .gesture(
                DragGesture(minimumDistance: 12)
                    .onChanged { value in
                        isSwiping = true
                        // Upward drag is negative; the sheet follows it so the
                        // gesture reads as a pull rather than a jump.
                        dragOffset = min(0, max(-260, value.translation.height))
                    }
                    .onEnded { value in
                        isSwiping = false
                        let shouldUnlock = value.translation.height < -90 || value.predictedEndTranslation.height < -180
                        if shouldUnlock {
                            withAnimation(.easeOut(duration: 0.24)) {
                                dragOffset = -420
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) {
                                environment.unlock()
                                dragOffset = 0
                            }
                        } else {
                            withAnimation(.spring(response: 0.34, dampingFraction: 0.82)) {
                                dragOffset = 0
                            }
                        }
                    }
            )
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background {
            SimulatedWallpaperView(wallpaper: SimulatedWallpaper.fallback)
                .ignoresSafeArea()
                .overlay(Color.black.opacity(0.34).ignoresSafeArea())
                .blur(radius: isSwiping ? 2 : 0)
        }
        .accessibilityElement(children: .contain)
        .accessibilityAction(named: "Unlock") {
            environment.unlock()
        }
    }

    // MARK: - Boot readout

    private var bootPanel: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Circle()
                    .fill(stage == .ready ? VortexPalette.positive : VortexPalette.accent)
                    .frame(width: 8, height: 8)
                Text(stage == .ready ? "Guest environment ready" : "Booting \(stage.title.lowercased())")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(.white)
                Spacer(minLength: 0)
                Text("\(Int((stage.progress * 100).rounded()))%")
                    .font(.system(size: 12, weight: .medium, design: .monospaced))
                    .foregroundStyle(Color.white.opacity(0.7))
            }

            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.white.opacity(0.16))
                    Capsule()
                        .fill(VortexPalette.accent)
                        .frame(width: max(2, geometry.size.width * stage.progress))
                }
            }
            .frame(height: 4)
            .animation(.easeOut(duration: 0.3), value: stage)

            if let last = environment.bootLog.last {
                Text(last)
                    .font(.system(size: 11))
                    .foregroundStyle(Color.white.opacity(0.62))
                    .lineLimit(3)
                    .fixedSize(horizontal: false, vertical: true)
            }

            Text("Simulated environment — an original interface by Vortex, not Apple's operating system.")
                .font(.system(size: 10.5))
                .foregroundStyle(Color.white.opacity(0.45))
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(16)
        .background {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(.ultraThinMaterial)
                .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .fill(Color.black.opacity(0.18)))
                .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .strokeBorder(Color.white.opacity(0.12), lineWidth: 1))
        }
    }

    private var unlockHint: some View {
        VStack(spacing: 10) {
            Image(systemName: "chevron.up")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(Color.white.opacity(0.85))
            Text(stage == .ready ? "Swipe up to unlock" : "Swipe up to open while booting")
                .font(.system(size: 12, weight: .medium))
                .foregroundStyle(Color.white.opacity(0.7))
        }
    }

    // MARK: - Formatting

    private func dateString(_ date: Date) -> String {
        date.formatted(.dateTime.weekday(.wide).month(.wide).day())
    }
}
