//
//  SpringBoardModel.swift
//  Vortex
//
//  Home screen layout, editing, drag-to-reposition and the single launch
//  pipeline. Layout is persisted, so a rearrangement survives relaunch.
//

import Foundation
import SwiftUI

final class SpringBoardModel: ObservableObject {
    struct Layout: Codable, Equatable {
        var version: Int
        var pages: [[String]]
        var dock: [String]
        var wallpaper: String
    }

    enum Slot: Equatable {
        case page(Int, Int)
        case dock(Int)
    }

    static let pageCapacity = 8
    static let storageKey = "vortex.environment.layout.v1"
    static let currentVersion = 1

    @Published private(set) var pages: [[String]]
    @Published private(set) var dock: [String]
    @Published private(set) var wallpaper: SimulatedWallpaper
    @Published var isEditing = false
    @Published var pendingDeletion: SimulatedApp?
    @Published var launchReport: LaunchReport?

    private let defaults: UserDefaults

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        let loaded = Self.loadLayout(from: defaults)
        pages = loaded.pages
        dock = loaded.dock
        wallpaper = SimulatedWallpaper.wallpaper(id: loaded.wallpaper)
    }

    // MARK: - Reading

    var pageCount: Int { max(1, pages.count) }

    func apps(onPage index: Int) -> [SimulatedApp] {
        guard pages.indices.contains(index) else { return [] }
        return pages[index].compactMap { SimulatedAppCatalog.app(id: $0) }
    }

    var dockApps: [SimulatedApp] {
        dock.compactMap { SimulatedAppCatalog.app(id: $0) }
    }

    func app(id: String) -> SimulatedApp? {
        SimulatedAppCatalog.app(id: id)
    }

    func slot(of identifier: String) -> Slot? {
        for (pageIndex, page) in pages.enumerated() {
            if let itemIndex = page.firstIndex(of: identifier) {
                return .page(pageIndex, itemIndex)
            }
        }
        if let dockIndex = dock.firstIndex(of: identifier) {
            return .dock(dockIndex)
        }
        return nil
    }

    // MARK: - Editing

    func beginEditing() {
        withAnimation(.easeInOut(duration: 0.2)) { isEditing = true }
    }

    func endEditing() {
        withAnimation(.easeInOut(duration: 0.2)) { isEditing = false }
        pendingDeletion = nil
    }

    func requestDeletion(_ app: SimulatedApp) {
        guard app.isRemovable else { return }
        pendingDeletion = app
    }

    func cancelDeletion() {
        pendingDeletion = nil
    }

    func confirmDeletion() {
        guard let app = pendingDeletion else { return }
        pendingDeletion = nil
        remove(app.id)
    }

    func remove(_ identifier: String) {
        for index in pages.indices {
            pages[index].removeAll { $0 == identifier }
        }
        dock.removeAll { $0 == identifier }
        normalisePages()
        persist()
    }

    /// Moves an item so it sits where the target item was.
    func move(draggedID: String, before targetID: String) {
        guard draggedID != targetID,
              let dragged = app(id: draggedID), dragged.isMovable,
              slot(of: draggedID) != nil else { return }

        removeFromLayout(draggedID)
        guard let targetSlot = slot(of: targetID) else {
            persist()
            return
        }
        switch targetSlot {
        case .page(let pageIndex, let itemIndex):
            pages[pageIndex].insert(draggedID, at: min(itemIndex, pages[pageIndex].count))
        case .dock(let dockIndex):
            dock.insert(draggedID, at: min(dockIndex, dock.count))
        }
        normalisePages()
        persist()
    }

    func restoreDefaultLayout() {
        pages = SimulatedAppCatalog.defaultPages
        dock = SimulatedAppCatalog.defaultDock
        wallpaper = SimulatedWallpaper.fallback
        isEditing = false
        pendingDeletion = nil
        persist()
    }

    func selectWallpaper(_ choice: SimulatedWallpaper) {
        wallpaper = choice
        persist()
    }

    // MARK: - Launch pipeline

    /// The single path every icon that has no host-side destination goes
    /// through. The environment calls this only when no installed package
    /// claims the icon, so the report it builds is about a missing package
    /// rather than a missing subsystem.
    func launch(_ app: SimulatedApp) {
        guard !isEditing else { return }

        if app.role == .hostDisplay {
            launchReport = LaunchReport(app: app,
                                        checks: [LaunchReport.Check(id: "host",
                                                                    title: "Destination",
                                                                    detail: "Monitor is the host display, not a guest process.",
                                                                    state: .info)],
                                        outcome: .returnedToHost,
                                        footnote: Self.environmentFootnote)
            return
        }

        let checks = [
            LaunchReport.Check(id: "package",
                               title: "Package",
                               detail: "\(app.source.label). No installed package claims this icon.",
                               state: .fail),
            LaunchReport.Check(id: "executable",
                               title: "Guest executable",
                               detail: "Nothing in /Apps provides a binary for this icon.",
                               state: .fail),
            LaunchReport.Check(id: "filesystem",
                               title: "Virtual filesystem",
                               detail: "Mounted. Import a package folder from Files to give this icon a binary.",
                               state: .pass),
            LaunchReport.Check(id: "runtime",
                               title: "Guest runtime",
                               detail: "Ready. It starts any ARM64 image that is a multiple of four bytes.",
                               state: .pass)
        ]

        let reason = "\(app.name) has no guest executable to run. Vortex can interpret ARM64 and its runtime can service syscalls, but this icon has no installed package behind it. Import one from Files to give it a binary."
        launchReport = LaunchReport(app: app, checks: checks, outcome: .cannotLaunch(reason), footnote: Self.environmentFootnote)
    }

    static let environmentFootnote = "Simulated environment — an original interface by Vortex, not Apple's operating system. These icons are not installed apps unless the checks say so."

    // MARK: - Layout helpers

    private func removeFromLayout(_ identifier: String) {
        for index in pages.indices {
            pages[index].removeAll { $0 == identifier }
        }
        dock.removeAll { $0 == identifier }
    }

    private func normalisePages() {
        pages.removeAll { $0.isEmpty }
        if pages.isEmpty {
            pages = [[]]
        }
    }

    static func paginate(_ identifiers: [String], capacity: Int = pageCapacity) -> [[String]] {
        guard capacity > 0 else { return [identifiers] }
        guard !identifiers.isEmpty else { return [[]] }
        return stride(from: 0, to: identifiers.count, by: capacity).map {
            Array(identifiers[$0..<min($0 + capacity, identifiers.count)])
        }
    }

    // MARK: - Persistence

    private func persist() {
        let layout = Layout(version: Self.currentVersion,
                            pages: pages,
                            dock: dock,
                            wallpaper: wallpaper.id)
        if let data = try? JSONEncoder().encode(layout) {
            defaults.set(data, forKey: Self.storageKey)
        }
    }

    static func loadLayout(from defaults: UserDefaults) -> Layout {
        let fallback = Layout(version: currentVersion,
                              pages: SimulatedAppCatalog.defaultPages,
                              dock: SimulatedAppCatalog.defaultDock,
                              wallpaper: SimulatedWallpaper.fallback.id)

        guard let data = defaults.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode(Layout.self, from: data) else {
            return fallback
        }

        // Drop identifiers this build no longer knows about.
        var pages = decoded.pages.map { page in
            page.filter { SimulatedAppCatalog.app(id: $0) != nil }
        }
        pages.removeAll { $0.isEmpty }
        if pages.isEmpty {
            pages = [[]]
        }
        let dock = decoded.dock.filter { SimulatedAppCatalog.app(id: $0) != nil }
        let wallpaperID = SimulatedWallpaper.all.contains { $0.id == decoded.wallpaper }
            ? decoded.wallpaper
            : SimulatedWallpaper.fallback.id

        return Layout(version: currentVersion, pages: pages, dock: dock, wallpaper: wallpaperID)
    }
}
