//
//  SimulatedApp.swift
//  Vortex
//
//  The simulated environment's app model. These are original simulated apps
//  built into Vortex — not Apple apps, and not installed guest packages yet.
//  The model keeps a `source` field so a package loader can feed this list in
//  the milestone that adds one.
//

import SwiftUI

enum SimulatedGlyph: String {
    case folder
    case gear
    case terminal
    case note
    case clock
    case photos
    case compass
    case bag
    case display
}

struct SimulatedAppTint {
    let top: Color
    let bottom: Color
    let glyph: Color
}

enum SimulatedAppSource: Equatable {
    case builtIn
    case installedPackage(identifier: String)

    var label: String {
        switch self {
        case .builtIn:
            return "Built into the simulated environment"
        case .installedPackage(let identifier):
            return "Installed package \(identifier)"
        }
    }
}

struct SimulatedApp: Identifiable {
    enum Role: String {
        case system
        case hostDisplay
    }

    let id: String
    let name: String
    let glyph: SimulatedGlyph
    let tint: SimulatedAppTint
    let role: Role
    let source: SimulatedAppSource

    /// Settings stays put; everything else can be removed from the home screen.
    var isRemovable: Bool {
        role == .system && id != "settings"
    }

    var isMovable: Bool { true }
}

enum SimulatedAppCatalog {
    static let apps: [SimulatedApp] = [
        SimulatedApp(id: "files",
                     name: "Files",
                     glyph: .folder,
                     tint: SimulatedAppTint(top: Color(red: 0.31, green: 0.57, blue: 0.90),
                                            bottom: Color(red: 0.17, green: 0.42, blue: 0.82),
                                            glyph: .white),
                     role: .system,
                     source: .builtIn),
        SimulatedApp(id: "settings",
                     name: "Settings",
                     glyph: .gear,
                     tint: SimulatedAppTint(top: Color(red: 0.24, green: 0.25, blue: 0.28),
                                            bottom: Color(red: 0.13, green: 0.14, blue: 0.16),
                                            glyph: Color(white: 0.83)),
                     role: .system,
                     source: .builtIn),
        SimulatedApp(id: "terminal",
                     name: "Terminal",
                     glyph: .terminal,
                     tint: SimulatedAppTint(top: Color(red: 0.12, green: 0.12, blue: 0.14),
                                            bottom: Color(red: 0.05, green: 0.05, blue: 0.07),
                                            glyph: .white),
                     role: .system,
                     source: .builtIn),
        SimulatedApp(id: "notes",
                     name: "Notes",
                     glyph: .note,
                     tint: SimulatedAppTint(top: Color(red: 0.67, green: 0.60, blue: 0.39),
                                            bottom: Color(red: 0.55, green: 0.48, blue: 0.28),
                                            glyph: .white),
                     role: .system,
                     source: .builtIn),
        SimulatedApp(id: "clock",
                     name: "Clock",
                     glyph: .clock,
                     tint: SimulatedAppTint(top: Color(red: 0.47, green: 0.33, blue: 0.82),
                                            bottom: Color(red: 0.28, green: 0.16, blue: 0.58),
                                            glyph: .white),
                     role: .system,
                     source: .builtIn),
        SimulatedApp(id: "photos",
                     name: "Photos",
                     glyph: .photos,
                     tint: SimulatedAppTint(top: Color(red: 0.17, green: 0.18, blue: 0.20),
                                            bottom: Color(red: 0.09, green: 0.10, blue: 0.12),
                                            glyph: .white),
                     role: .system,
                     source: .builtIn),
        SimulatedApp(id: "browser",
                     name: "Browser",
                     glyph: .compass,
                     tint: SimulatedAppTint(top: Color(red: 0.30, green: 0.55, blue: 0.88),
                                            bottom: Color(red: 0.16, green: 0.36, blue: 0.71),
                                            glyph: .white),
                     role: .system,
                     source: .builtIn),
        SimulatedApp(id: "store",
                     name: "Store",
                     glyph: .bag,
                     tint: SimulatedAppTint(top: Color(red: 0.55, green: 0.37, blue: 0.96),
                                            bottom: Color(red: 0.42, green: 0.24, blue: 0.85),
                                            glyph: .white),
                     role: .system,
                     source: .builtIn),
        SimulatedApp(id: "monitor",
                     name: "Monitor",
                     glyph: .display,
                     tint: SimulatedAppTint(top: Color(red: 0.18, green: 0.19, blue: 0.22),
                                            bottom: Color(red: 0.10, green: 0.11, blue: 0.13),
                                            glyph: Color(white: 0.88)),
                     role: .hostDisplay,
                     source: .builtIn)
    ]

    static func app(id: String) -> SimulatedApp? {
        apps.first { $0.id == id }
    }

    /// The home screen grid, in the order the mockup shows.
    static let defaultPages: [[String]] = [
        ["files", "settings", "terminal", "notes", "clock", "photos", "browser", "store"]
    ]

    static let defaultDock: [String] = ["monitor", "terminal", "files", "settings"]
}
