//
//  FilesAppView.swift
//  Vortex
//
//  The environment's Files app: a browser for the virtual filesystem, plus the
//  install flow for virtual app packages.
//
//  Import accepts a folder staged in the app's Documents directory (visible in
//  iOS Files under On My iPhone/Vortex). A folder the system hands over through
//  the share sheet is security-scoped; it is copied into Documents first so the
//  package outlives the picker.
//

import SwiftUI

struct FilesAppView: View {
    @ObservedObject var environment: GuestEnvironmentModel
    @Environment(\.dismiss) private var dismiss

    @State private var selectedFile: VirtualFileEntry?
    @State private var importMessage: ImportMessage?
    @State private var isImporting = false
    @State private var candidates: [ImportCandidate] = []

    struct ImportMessage: Identifiable {
        enum Kind { case success, failure }
        let id = UUID()
        let kind: Kind
        let title: String
        let detail: String
    }

    private var filesystem: GuestFilesystem { environment.filesystem }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    ForEach(filesystem.entries) { entry in
                        Button {
                            if entry.kind == .file {
                                selectedFile = entry
                            }
                        } label: {
                            row(entry)
                        }
                        .buttonStyle(.plain)
                        .swipeActions(edge: .trailing) {
                            if entry.path != "/" && !entry.path.hasPrefix("/System") {
                                Button(role: .destructive) {
                                    delete(entry)
                                } label: {
                                    Label("Delete", systemImage: "trash")
                                }
                            }
                        }
                    }
                } header: {
                    Text("Virtual filesystem · \(filesystem.nodeCount) entries")
                } footer: {
                    Text("Stored in one container file in the app's Application Support directory. Guest processes reach it through the runtime's syscall table.")
                        .font(.system(size: 11))
                }

                Section {
                    if candidates.isEmpty {
                        Text("No folders staged in Documents. Save a package folder into Vortex's Documents folder from iOS Files, then return here.")
                            .font(.system(size: 12))
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(candidates) { candidate in
                            Button {
                                importPackage(candidate)
                            } label: {
                                HStack {
                                    Image(systemName: candidate.isDirectory ? "shippingbox.fill" : "doc.text")
                                        .foregroundStyle(VortexPalette.accent)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(candidate.name)
                                            .font(.system(size: 14, weight: .medium))
                                            .foregroundStyle(.primary)
                                        Text("Tap to validate and install")
                                            .font(.system(size: 11))
                                            .foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    Image(systemName: "arrow.down.circle")
                                        .foregroundStyle(.secondary)
                                }
                            }
                        }
                    }

                    Button {
                        candidates = GuestFilesystem.importCandidates()
                    } label: {
                        Label("Refresh Documents", systemImage: "arrow.clockwise")
                    }
                } header: {
                    Text("Import package")
                } footer: {
                    Text("A package is a folder with a manifest.json (displayName, identifier, version, executable) and an ARM64 executable that is a multiple of four bytes. The executable is loaded into the interpreter, not executed natively.")
                        .font(.system(size: 11))
                }

                Section("Packages") {
                    let installed = filesystem.installedPackages
                    if installed.isEmpty {
                        Text("No packages installed.")
                            .font(.system(size: 12))
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(installed, id: \.identifier) { package in
                            VStack(alignment: .leading, spacing: 3) {
                                Text(package.displayName)
                                    .font(.system(size: 14, weight: .medium))
                                Text("\(package.identifier) · v\(package.version) · \(package.executable)")
                                    .font(.system(size: 11, design: .monospaced))
                                    .foregroundStyle(.secondary)
                                if !package.capabilities.isEmpty {
                                    Text("Requests: \(package.capabilities.joined(separator: ", "))")
                                        .font(.system(size: 11))
                                        .foregroundStyle(.secondary)
                                }
                            }
                            .padding(.vertical, 2)
                        }
                    }
                }
            }
            .navigationTitle("Files")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
            .task {
                candidates = GuestFilesystem.importCandidates()
            }
            .sheet(item: $selectedFile) { entry in
                FilePreviewView(entry: entry, filesystem: filesystem)
            }
            .alert(item: $importMessage) { message in
                Alert(title: Text(message.title),
                      message: Text(message.detail),
                      dismissButton: .default(Text("OK")))
            }
        }
        .preferredColorScheme(.dark)
    }

    private func row(_ entry: VirtualFileEntry) -> some View {
        HStack(spacing: 10) {
            Image(systemName: entry.kind.symbolName)
                .foregroundStyle(entry.kind == .directory ? VortexPalette.accent : Color.secondary)
                .frame(width: 22)
            VStack(alignment: .leading, spacing: 2) {
                Text(entry.name)
                    .font(.system(size: 14, weight: entry.depth == 0 ? .semibold : .regular))
                    .foregroundStyle(.primary)
                if entry.size > 0 {
                    Text("\(entry.size) bytes")
                        .font(.system(size: 11))
                        .foregroundStyle(.secondary)
                }
            }
            Spacer()
            if entry.kind == .file {
                Image(systemName: "chevron.right")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(.tertiary)
            }
        }
    }

    private func delete(_ entry: VirtualFileEntry) {
        let removed = filesystem.remove(entry.path)
        environment.systemEvent(removed ? "Removed \(entry.path)" : "Could not remove \(entry.path): \(filesystem.lastError)",
                                severity: removed ? .info : .error)
        filesystem.save()
    }

    private func importPackage(_ candidate: ImportCandidate) {
        guard candidate.isDirectory else {
            importMessage = ImportMessage(kind: .failure,
                                          title: "Not a package",
                                          detail: "\(candidate.name) is a loose file. A package is a folder with a manifest.json inside it.")
            return
        }

        do {
            let inspection = try GuestFilesystem.inspectPackage(at: candidate.url)
            let root = try filesystem.install(inspection)
            filesystem.save()
            importMessage = ImportMessage(kind: .success,
                                          title: "Installed \(inspection.manifest.displayName)",
                                          detail: "Placed at \(root) with \(inspection.files.count) files. Launch passes the executable at \(inspection.manifest.executable) to the interpreter.")
            environment.systemEvent("Installed package \(inspection.manifest.identifier)", severity: .info)
            candidates = GuestFilesystem.importCandidates()
        } catch {
            let detail = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
            importMessage = ImportMessage(kind: .failure,
                                          title: "Install rejected",
                                          detail: detail)
            environment.systemEvent("Package \(candidate.name) rejected: \(detail)", severity: .error)
        }
    }
}

// MARK: - File preview

struct FilePreviewView: View {
    let entry: VirtualFileEntry
    let filesystem: GuestFilesystem
    @Environment(\.dismiss) private var dismiss

    private var data: Data? { filesystem.readFile(entry.path) }

    private var text: String? {
        guard let data, data.count <= 16 * 1024 else { return nil }
        guard let string = String(data: data, encoding: .utf8) else { return nil }
        // Reject binary payloads so the preview never renders garbage.
        return string.unicodeScalars.allSatisfy { $0.value == 9 || $0.value == 10 || $0.value == 13 || $0.value >= 32 } ? string : nil
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    LabeledContent("Path", value: entry.path)
                        .font(.system(size: 12, design: .monospaced))
                    LabeledContent("Size", value: "\(entry.size) bytes")
                        .font(.system(size: 12))

                    if let text {
                        Text(text)
                            .font(.system(size: 12, design: .monospaced))
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(12)
                            .background(RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .fill(VortexPalette.surface))
                    } else {
                        Text(entry.size == 0 ? "Empty file." : "Binary content. Vortex does not decode this file in the browser; an executable is loaded into the interpreter instead.")
                            .font(.system(size: 12))
                            .foregroundStyle(.secondary)
                    }
                }
                .padding(18)
            }
            .navigationTitle(entry.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}
