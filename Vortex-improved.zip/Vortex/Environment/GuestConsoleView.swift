//
//  GuestConsoleView.swift
//  Vortex
//
//  The environment's Terminal: the guest runtime's console, the sample programs,
//  and the program images the runtime will accept with what it rejected and why.
//

import SwiftUI

struct GuestConsoleView: View {
    @ObservedObject var environment: GuestEnvironmentModel
    @Environment(\.dismiss) private var dismiss

    @State private var pendingError: String?

    private var runtime: GuestRuntime { environment.runtime }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    consoleCard
                    programsCard
                    processCard
                }
                .padding(16)
            }
            .background(VortexPalette.background.ignoresSafeArea())
            .navigationTitle("Terminal")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Clear") {
                        runtime.clearConsole()
                    }
                }
            }
            .alert("Launch refused",
                   isPresented: Binding(get: { pendingError != nil },
                                        set: { if !$0 { pendingError = nil } })) {
                Button("OK") { pendingError = nil }
            } message: {
                Text(pendingError ?? "")
            }
        }
        .preferredColorScheme(.dark)
    }

    // MARK: - Console

    private var consoleCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("CONSOLE")
                    .font(.system(size: 10.5, weight: .semibold))
                    .tracking(1.2)
                    .foregroundStyle(VortexPalette.tertiaryText)
                Spacer()
                Text("\(runtime.syscallCount) syscalls")
                    .font(.system(size: 10.5, design: .monospaced))
                    .foregroundStyle(VortexPalette.tertiaryText)
            }

            let text = runtime.consoleText
            ScrollView {
                Text(text.isEmpty ? "No guest output yet. Start a program below; both print through the stdout syscall." : text)
                    .font(.system(size: 11.5, design: .monospaced))
                    .foregroundStyle(text.isEmpty ? VortexPalette.tertiaryText : VortexPalette.primaryText)
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(height: 190)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 20, style: .continuous).fill(Color.black))
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous)
            .strokeBorder(VortexPalette.stroke, lineWidth: 1))
    }

    // MARK: - Programs

    private var programsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("SAMPLE PROGRAMS")
                .font(.system(size: 10.5, weight: .semibold))
                .tracking(1.2)
                .foregroundStyle(VortexPalette.tertiaryText)

            ForEach(VortexGuestProgram.allCases) { program in
                VStack(alignment: .leading, spacing: 6) {
                    HStack(spacing: 8) {
                        Image(systemName: program.symbolName)
                            .font(.system(size: 13))
                            .foregroundStyle(VortexPalette.accent)
                        Text(program.title)
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundStyle(VortexPalette.primaryText)
                        Spacer()
                        Button {
                            start(program)
                        } label: {
                            Text("Run")
                                .font(.system(size: 12, weight: .semibold))
                                .padding(.horizontal, 14)
                                .padding(.vertical, 6)
                                .background(Capsule().fill(VortexPalette.accent))
                                .foregroundStyle(.white)
                        }
                        .buttonStyle(.plain)
                    }
                    Text(program.summary)
                        .font(.system(size: 11.5))
                        .foregroundStyle(VortexPalette.secondaryText)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(12)
                .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(VortexPalette.surface))
            }

            if let result = runtime.benchmarkResult(using: environment.core), result > 0 {
                Text("Benchmark result read from guest memory at 0x8000: \(result)")
                    .font(.system(size: 11.5, design: .monospaced))
                    .foregroundStyle(VortexPalette.positive)
            }
        }
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 20, style: .continuous).fill(VortexPalette.surfaceRaised))
    }

    // MARK: - Processes

    private var processCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("PROCESSES")
                    .font(.system(size: 10.5, weight: .semibold))
                    .tracking(1.2)
                    .foregroundStyle(VortexPalette.tertiaryText)
                Spacer()
                Button("Stop all") {
                    environment.core.stopGuests()
                    environment.systemEvent("All guest processes stopped", severity: .warning)
                }
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(VortexPalette.warning)
            }

            if runtime.processes.isEmpty {
                Text("No guest processes.")
                    .font(.system(size: 12))
                    .foregroundStyle(VortexPalette.secondaryText)
            } else {
                ForEach(runtime.processes) { process in
                    VStack(alignment: .leading, spacing: 3) {
                        HStack {
                            Text(process.name)
                                .font(.system(size: 13, weight: .semibold, design: .monospaced))
                                .foregroundStyle(VortexPalette.primaryText)
                            Spacer()
                            Text(process.state.label)
                                .font(.system(size: 10.5, weight: .medium))
                                .foregroundStyle(stateTint(process.state))
                        }
                        Text(String(format: "pc 0x%05llx · slices %llu · exit %d",
                                    process.pc, process.slices, process.exitCode))
                            .font(.system(size: 10.5, design: .monospaced))
                            .foregroundStyle(VortexPalette.tertiaryText)
                        if !process.diagnosis.isEmpty {
                            Text(process.diagnosis)
                                .font(.system(size: 11))
                                .foregroundStyle(VortexPalette.critical)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    .padding(10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(VortexPalette.surface))
                }
            }
        }
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 20, style: .continuous).fill(VortexPalette.surfaceRaised))
    }

    private func stateTint(_ state: GuestProcessInfo.State) -> Color {
        switch state {
        case .ready: return VortexPalette.accent
        case .running: return VortexPalette.positive
        case .exited: return VortexPalette.secondaryText
        case .trapped: return VortexPalette.critical
        case .unused: return VortexPalette.tertiaryText
        }
    }

    private func start(_ program: VortexGuestProgram) {
        let result = environment.core.launchSample(program)
        environment.loadEvents()
        if result < 0 {
            let reason = runtime.errorText
            pendingError = reason.isEmpty ? "The runtime refused the launch without a reason." : reason
        } else {
            environment.systemEvent("Started \(program.name) in process \(result)", severity: .info)
        }
    }
}
