//
//  HomeScreenView.swift
//  Vortex
//
//  The simulated SpringBoard-style home screen: wallpaper, simulated status bar,
//  paged icon grid, dock, edit mode with jiggle, drag-to-reposition and the
//  launch report.
//

import SwiftUI

// MARK: - Clock

enum SimulatedClock {
    static let baseMinutes = 9 * 60 + 41

    static func timeString(elapsed: TimeInterval) -> String {
        let advance = Int(max(0, elapsed)) / 60
        let minutes = (baseMinutes + advance) % (24 * 60)
        return String(format: "%d:%02d", minutes / 60, minutes % 60)
    }
}

// MARK: - Home screen

struct HomeScreenView: View {
    @ObservedObject var environment: GuestEnvironmentModel
    var onReturnToHost: () -> Void
    var onOpenFiles: () -> Void
    var onOpenSettings: () -> Void
    var onOpenMonitor: () -> Void

    @StateObject private var model = SpringBoardModel()
    @Environment(\.dismiss) private var dismiss

    @State private var pageIndex = 0
    @State private var isShowingWallpaperPicker = false
    @State private var sessionStart = Date()
    @State private var launchReport: LaunchReport?
    @State private var isShowingConsole = false

    private let columns = Array(repeating: GridItem(.flexible(), spacing: 12), count: 4)

    var body: some View {
        ZStack {
            SimulatedWallpaperView(wallpaper: model.wallpaper)
                .ignoresSafeArea()
                .onLongPressGesture(minimumDuration: 0.6) {
                    isShowingWallpaperPicker = true
                }

            VStack(spacing: 0) {
                statusBar

                Text("Simulated environment")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(Color.white.opacity(0.55))
                    .padding(.top, 10)

                pagesView

                pageDots
                    .padding(.top, 6)
                    .padding(.bottom, model.isEditing ? 8 : 16)

                if model.isEditing {
                    editBar
                        .padding(.horizontal, 20)
                        .padding(.bottom, 10)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                }

                dock
                    .padding(.horizontal, 16)

                homeIndicator
                    .padding(.top, 10)
                    .padding(.bottom, 8)
            }
        }
        .statusBarHidden(true)
        .preferredColorScheme(.dark)
        .simultaneousGesture(
            DragGesture(minimumDistance: 30)
                .onEnded { value in
                    guard !model.isEditing else { return }
                    if value.translation.height > 100,
                       abs(value.translation.width) < 80 {
                        onReturnToHost()
                    }
                }
        )
        .sheet(item: $launchReport) { report in
            LaunchReportView(report: report,
                             onReturnToDisplay: {
                                 launchReport = nil
                                 dismiss()
                             })
        }
        .sheet(isPresented: $isShowingWallpaperPicker) {
            WallpaperPickerView(model: model)
        }
        .sheet(isPresented: $isShowingConsole) {
            GuestConsoleView(environment: environment)
        }
        .alert("Remove \(model.pendingDeletion?.name ?? "app")?",
               isPresented: Binding(get: { model.pendingDeletion != nil },
                                    set: { if !$0 { model.cancelDeletion() } })) {
            Button("Remove", role: .destructive) {
                model.confirmDeletion()
            }
            Button("Cancel", role: .cancel) {
                model.cancelDeletion()
            }
        } message: {
            Text("Only the home-screen entry is removed. This does not delete an installed package from the virtual filesystem.")
        }
        .onChange(of: pageIndex) { _, newValue in
            if newValue >= model.pageCount {
                pageIndex = max(0, model.pageCount - 1)
            }
        }
        .onReceive(Timer.publish(every: 0.5, on: .main, in: .common).autoconnect()) { _ in
            environment.tick(environment.core.stats)
        }
    }

    // MARK: - Status bar and overlays

    private var statusBar: some View {
        ZStack {
            TimelineView(.periodic(from: .now, by: 1)) { context in
                SimulatedStatusBar(date: context.date, sessionStart: sessionStart)
            }

            HStack(spacing: 0) {
                // Pull down on the left half for notifications.
                Color.clear
                    .contentShape(Rectangle())
                    .gesture(
                        DragGesture(minimumDistance: 24)
                            .onEnded { value in
                                guard value.translation.height > 26 else { return }
                                withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) {
                                    environment.overlay = .notifications
                                }
                            }
                    )
                // Pull down on the right half for Control Centre.
                Color.clear
                    .contentShape(Rectangle())
                    .gesture(
                        DragGesture(minimumDistance: 24)
                            .onEnded { value in
                                guard value.translation.height > 26 else { return }
                                withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) {
                                    environment.overlay = .controlCentre
                                }
                            }
                    )
            }
        }
        .frame(height: 26)
        .padding(.horizontal, 24)
        .padding(.top, 4)
    }

    private var overlayShortcuts: some View {
        HStack(spacing: 8) {
            Button {
                withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) {
                    environment.overlay = .controlCentre
                }
            } label: {
                Image(systemName: "slider.horizontal.3")
            }
            .accessibilityLabel("Control Centre")

            Button {
                withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) {
                    environment.overlay = .notifications
                }
            } label: {
                ZStack(alignment: .topTrailing) {
                    Image(systemName: "bell")
                    if environment.badgeCount > 0 {
                        Text("\(environment.badgeCount)")
                            .font(.system(size: 8, weight: .bold))
                            .foregroundStyle(.white)
                            .padding(2)
                            .background(Circle().fill(VortexPalette.critical))
                            .offset(x: 7, y: -6)
                    }
                }
            }
            .accessibilityLabel("Notification Centre")
        }
        .font(.system(size: 13, weight: .semibold))
        .foregroundStyle(Color.white.opacity(0.85))
    }

    // MARK: - Grid

    private var pagesView: some View {
        TabView(selection: $pageIndex) {
            ForEach(0..<model.pageCount, id: \.self) { index in
                pageView(index)
                    .tag(index)
            }
        }
        .tabViewStyle(.page(indexDisplayMode: .never))
        .animation(.easeInOut(duration: 0.22), value: model.pageCount)
    }

    private func pageView(_ index: Int) -> some View {
        VStack(spacing: 0) {
            LazyVGrid(columns: columns, spacing: 18) {
                ForEach(model.apps(onPage: index)) { app in
                    iconCell(app)
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 16)

            Spacer(minLength: 0)
        }
    }

    private func iconCell(_ app: SimulatedApp) -> some View {
        SpringBoardIconButton(app: app,
                              size: 66,
                              showsLabel: true,
                              isEditing: model.isEditing,
                              showsDeleteBadge: model.isEditing && app.isRemovable,
                              onOpen: { launch(app) },
                              onLongPress: { model.beginEditing() },
                              onDelete: { model.requestDeletion(app) })
            .dropDestination(for: String.self) { items, _ in
                guard let dragged = items.first else { return false }
                model.move(draggedID: dragged, before: app.id)
                return true
            }
    }

    /// One pipeline for every icon. Built-in apps switch the environment to their
    /// host-side view; an installed package goes to the interpreter; anything
    /// else gets a report naming what is missing.
    private func launch(_ app: SimulatedApp) {
        switch app.id {
        case "monitor":
            model.launch(app)
            if case .returnedToHost = model.launchReport?.outcome {
                onOpenMonitor()
            }
            model.launchReport = nil
            return
        case "files":
            onOpenFiles()
            return
        case "settings":
            onOpenSettings()
            return
        case "store":
            onOpenFiles()
            return
        case "terminal":
            isShowingConsole = true
            return
        default:
            break
        }

        if let package = environment.filesystem.installedPackages.first(where: { package in
            AppPackage.identifier(from: app.name) == package.identifier
        }) {
            let root = "/Apps/\(package.identifier)/\(package.executable)"
            let result = environment.core.launchPackage(name: app.name, path: root)
            environment.loadEvents()
            launchReport = LaunchReport(app: app,
                                        checks: [
                                            LaunchReport.Check(id: "package",
                                                               title: "Package",
                                                               detail: "\(package.identifier) v\(package.version) is installed.",
                                                               state: .pass),
                                            LaunchReport.Check(id: "executable",
                                                               title: "Guest executable",
                                                               detail: root,
                                                               state: .pass),
                                            LaunchReport.Check(id: "filesystem",
                                                               title: "Virtual filesystem",
                                                               detail: "Mounted with \(environment.filesystem.nodeCount) entries.",
                                                               state: .pass),
                                            LaunchReport.Check(id: "runtime",
                                                               title: "Guest runtime",
                                                               detail: result >= 0
                                                                   ? "Process \(result) is running in the interpreter."
                                                                   : "The runtime refused the launch.",
                                                               state: result >= 0 ? .pass : .fail)
                                        ],
                                        outcome: result >= 0
                                            ? .running(processIndex: Int(result))
                                            : .cannotLaunch("The runtime refused the launch: \(environment.runtime.errorText.isEmpty ? "no reason reported" : environment.runtime.errorText)"),
                                        footnote: SpringBoardModel.environmentFootnote)
            return
        }

        model.launch(app)
    }

    private var pageDots: some View {
        HStack(spacing: 8) {
            ForEach(0..<model.pageCount, id: \.self) { index in
                Circle()
                    .fill(index == pageIndex ? Color.white : Color.white.opacity(0.28))
                    .frame(width: 7, height: 7)
            }
        }
        .frame(height: 10)
    }

    // MARK: - Dock

    private var dock: some View {
        HStack(spacing: 18) {
            ForEach(model.dockApps) { app in
                SpringBoardIconButton(app: app,
                                      size: 56,
                                      showsLabel: false,
                                      isEditing: model.isEditing,
                                      showsDeleteBadge: model.isEditing && app.isRemovable,
                                      onOpen: { launch(app) },
                                      onLongPress: { model.beginEditing() },
                                      onDelete: { model.requestDeletion(app) })
                    .dropDestination(for: String.self) { items, _ in
                        guard let dragged = items.first else { return false }
                        model.move(draggedID: dragged, before: app.id)
                        return true
                    }
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .frame(maxWidth: .infinity)
        .background {
            RoundedRectangle(cornerRadius: 30, style: .continuous)
                .fill(.ultraThinMaterial)
                .overlay(RoundedRectangle(cornerRadius: 30, style: .continuous)
                    .fill(Color.white.opacity(0.06)))
                .overlay(RoundedRectangle(cornerRadius: 30, style: .continuous)
                    .strokeBorder(Color.white.opacity(0.12), lineWidth: 1))
        }
    }

    // MARK: - Edit bar

    private var editBar: some View {
        HStack(spacing: 10) {
            Button {
                isShowingWallpaperPicker = true
            } label: {
                Label("Wallpaper", systemImage: "photo")
                    .font(.system(size: 12, weight: .medium))
            }
            .buttonStyle(.bordered)

            Button {
                model.restoreDefaultLayout()
            } label: {
                Text("Restore Defaults")
                    .font(.system(size: 12, weight: .medium))
            }
            .buttonStyle(.bordered)

            Spacer(minLength: 0)

            Button {
                model.endEditing()
            } label: {
                Text("Done")
                    .font(.system(size: 12, weight: .semibold))
            }
            .buttonStyle(.borderedProminent)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(RoundedRectangle(cornerRadius: 20, style: .continuous).fill(.ultraThinMaterial))
    }

    private var homeIndicator: some View {
        Capsule()
            .fill(Color.white.opacity(0.55))
            .frame(width: 134, height: 5)
    }
}

// MARK: - Status bar

struct SimulatedStatusBar: View {
    let date: Date
    let sessionStart: Date

    var body: some View {
        HStack {
            Text(SimulatedClock.timeString(elapsed: date.timeIntervalSince(sessionStart)))
                .font(.system(size: 16, weight: .semibold))
                .monospacedDigit()
                .foregroundStyle(Color.white)

            Spacer()

            HStack(spacing: 7) {
                signalBars
                Image(systemName: "wifi")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Color.white)
                battery
            }
        }
        .frame(height: 24)
    }

    private var signalBars: some View {
        HStack(alignment: .bottom, spacing: 2) {
            ForEach(0..<4, id: \.self) { index in
                Capsule()
                    .fill(Color.white)
                    .frame(width: 3, height: 4 + CGFloat(index) * 2.2)
            }
        }
        .frame(height: 11, alignment: .bottom)
    }

    private var battery: some View {
        HStack(spacing: 1.5) {
            ZStack(alignment: .leading) {
                RoundedRectangle(cornerRadius: 3.4, style: .continuous)
                    .strokeBorder(Color.white.opacity(0.9), lineWidth: 1)
                    .frame(width: 24, height: 12)
                RoundedRectangle(cornerRadius: 1.8, style: .continuous)
                    .fill(Color.white)
                    .frame(width: 19, height: 8)
                    .offset(x: 2.5)
            }
            Capsule()
                .fill(Color.white.opacity(0.9))
                .frame(width: 1.6, height: 4)
        }
    }
}

// MARK: - Icon button

struct SpringBoardIconButton: View {
    let app: SimulatedApp
    var size: CGFloat = 66
    var showsLabel = true
    let isEditing: Bool
    let showsDeleteBadge: Bool
    let onOpen: () -> Void
    let onLongPress: () -> Void
    let onDelete: () -> Void

    @State private var jiggleAngle: Double = 0

    private var wobble: Double {
        app.id.count.isMultiple(of: 2) ? 1.5 : -1.5
    }

    var body: some View {
        VStack(spacing: 8) {
            icon
            if showsLabel {
                Text(app.name)
                    .font(.system(size: 12.5, weight: .regular))
                    .foregroundStyle(Color.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
                    .shadow(color: .black.opacity(0.35), radius: 4, y: 1)
            }
        }
        .rotationEffect(.degrees(jiggleAngle))
        .onChange(of: isEditing) { _, editing in
            updateJiggle(editing)
        }
        .onAppear {
            if isEditing { updateJiggle(true) }
        }
    }

    @ViewBuilder
    private var icon: some View {
        let content = Button {
            if !isEditing { onOpen() }
        } label: {
            ZStack(alignment: .topLeading) {
                SimulatedAppIcon(app: app, size: size)

                if showsDeleteBadge {
                    Button {
                        onDelete()
                    } label: {
                        Image(systemName: "minus")
                            .font(.system(size: 11, weight: .bold))
                            .foregroundStyle(Color.white)
                            .frame(width: 22, height: 22)
                            .background(Circle().fill(Color(white: 0.25)))
                            .overlay(Circle().strokeBorder(Color.white.opacity(0.25), lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                    .offset(x: -7, y: -7)
                    .accessibilityLabel("Remove \(app.name)")
                }
            }
        }
        .buttonStyle(SpringBoardIconButtonStyle(app: app))
        .simultaneousGesture(LongPressGesture(minimumDuration: 0.45).onEnded { _ in
            onLongPress()
        })
        .accessibilityLabel(isEditing ? "\(app.name), editing" : app.name)

        if isEditing {
            content.draggable(app.id)
        } else {
            content
        }
    }

    private func updateJiggle(_ editing: Bool) {
        if editing {
            withAnimation(.easeInOut(duration: 0.13).repeatForever(autoreverses: true)) {
                jiggleAngle = wobble
            }
        } else {
            withAnimation(.easeOut(duration: 0.16)) {
                jiggleAngle = 0
            }
        }
    }
}

struct SpringBoardIconButtonStyle: ButtonStyle {
    let app: SimulatedApp

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 1.10 : 1.0)
            .shadow(color: app.tint.top.opacity(configuration.isPressed ? 0.8 : 0.28),
                    radius: configuration.isPressed ? 18 : 7,
                    y: configuration.isPressed ? 0 : 4)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

// MARK: - Icon artwork

struct SimulatedAppIcon: View {
    let app: SimulatedApp
    var size: CGFloat = 66

    private var cornerRadius: CGFloat { size * 0.23 }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                .fill(LinearGradient(colors: [app.tint.top, app.tint.bottom],
                                     startPoint: .top,
                                     endPoint: .bottom))
                .overlay(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .fill(LinearGradient(colors: [Color.white.opacity(0.10), .clear],
                                         startPoint: .topLeading,
                                         endPoint: .center)))

            glyph
        }
        .frame(width: size, height: size)
        .overlay(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
            .strokeBorder(Color.white.opacity(0.10), lineWidth: 1))
    }

    @ViewBuilder
    private var glyph: some View {
        switch app.glyph {
        case .folder:
            Image(systemName: "folder.fill")
                .font(.system(size: size * 0.44, weight: .regular))
                .foregroundStyle(app.tint.glyph)
        case .gear:
            Image(systemName: "gearshape.fill")
                .font(.system(size: size * 0.46, weight: .regular))
                .foregroundStyle(app.tint.glyph)
        case .terminal:
            Text(">_")
                .font(.system(size: size * 0.30, weight: .bold, design: .monospaced))
                .foregroundStyle(app.tint.glyph)
        case .note:
            Image(systemName: "note.text")
                .font(.system(size: size * 0.40, weight: .regular))
                .foregroundStyle(app.tint.glyph)
        case .clock:
            ClockDial(size: size * 0.60, colour: app.tint.glyph)
        case .photos:
            PhotoFlower(size: size * 0.66)
        case .compass:
            Image(systemName: "safari.fill")
                .font(.system(size: size * 0.48, weight: .regular))
                .foregroundStyle(app.tint.glyph)
        case .bag:
            Image(systemName: "bag.fill")
                .font(.system(size: size * 0.42, weight: .regular))
                .foregroundStyle(app.tint.glyph)
        case .display:
            Image(systemName: "display")
                .font(.system(size: size * 0.44, weight: .regular))
                .foregroundStyle(app.tint.glyph)
        }
    }
}

struct ClockDial: View {
    let size: CGFloat
    let colour: Color

    var body: some View {
        ZStack {
            Circle()
                .strokeBorder(colour, lineWidth: max(1.4, size * 0.035))
            Capsule()
                .fill(colour)
                .frame(width: size * 0.045, height: size * 0.30)
                .offset(y: -size * 0.15)
            Capsule()
                .fill(colour)
                .frame(width: size * 0.04, height: size * 0.22)
                .offset(x: size * 0.08, y: -size * 0.02)
                .rotationEffect(.degrees(120))
        }
        .frame(width: size, height: size)
    }
}

struct PhotoFlower: View {
    let size: CGFloat

    private let petalColours: [Color] = [
        Color(red: 0.98, green: 0.28, blue: 0.30),
        Color(red: 0.99, green: 0.55, blue: 0.20),
        Color(red: 0.99, green: 0.82, blue: 0.24),
        Color(red: 0.44, green: 0.82, blue: 0.32),
        Color(red: 0.24, green: 0.83, blue: 0.62),
        Color(red: 0.25, green: 0.66, blue: 0.94),
        Color(red: 0.44, green: 0.44, blue: 0.95),
        Color(red: 0.74, green: 0.36, blue: 0.94)
    ]

    var body: some View {
        ZStack {
            ForEach(0..<8, id: \.self) { index in
                ZStack {
                    Ellipse()
                        .fill(petalColours[index])
                        .frame(width: size * 0.30, height: size * 0.46)
                        .offset(y: -size * 0.19)
                        .blendMode(.screen)
                }
                .frame(width: size, height: size)
                .rotationEffect(.degrees(Double(index) * 45))
            }
        }
        .frame(width: size, height: size)
        .compositingGroup()
    }
}

// MARK: - Launch report

struct LaunchReportView: View {
    let report: LaunchReport
    var onReturnToDisplay: () -> Void

    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    HStack(spacing: 14) {
                        SimulatedAppIcon(app: report.app, size: 52)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(report.app.name)
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundStyle(VortexPalette.primaryText)
                            Text(headline)
                                .font(.system(size: 12))
                                .foregroundStyle(headlineTint)
                        }
                        Spacer()
                    }
                    .padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(VortexPalette.surface))

                    if case .cannotLaunch(let reason) = report.outcome {
                        Text(reason)
                            .font(.system(size: 13))
                            .foregroundStyle(VortexPalette.secondaryText)
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(16)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(VortexPalette.surface))
                    }

                    VStack(spacing: 0) {
                        ForEach(Array(report.checks.enumerated()), id: \.element.id) { index, check in
                            HStack(alignment: .top, spacing: 10) {
                                Circle()
                                    .fill(colour(for: check.state))
                                    .frame(width: 8, height: 8)
                                    .padding(.top, 5)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(check.title)
                                        .font(.system(size: 13, weight: .medium))
                                        .foregroundStyle(VortexPalette.primaryText)
                                    Text(check.detail)
                                        .font(.system(size: 12))
                                        .foregroundStyle(VortexPalette.secondaryText)
                                        .fixedSize(horizontal: false, vertical: true)
                                }
                                Spacer(minLength: 0)
                            }
                            .padding(.vertical, 9)
                            if index < report.checks.count - 1 {
                                Divider().overlay(Color.white.opacity(0.06))
                            }
                        }
                    }
                    .padding(.horizontal, 16)
                    .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(VortexPalette.surface))

                    Text(report.footnote)
                        .font(.system(size: 11))
                        .foregroundStyle(VortexPalette.tertiaryText)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(.horizontal, 18)
                .padding(.vertical, 14)
            }
            .background(VortexPalette.background.ignoresSafeArea())
            .navigationTitle("Launch")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
                if case .returnedToHost = report.outcome {
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Return to display") {
                            dismiss()
                            onReturnToDisplay()
                        }
                    }
                }
                if case .running = report.outcome {
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Open environment") {
                            dismiss()
                        }
                    }
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private var headline: String {
        switch report.outcome {
        case .returnedToHost: return "Host display, not a guest app"
        case .running: return "Guest process running"
        case .cannotLaunch: return "No guest process could start"
        }
    }

    private var headlineTint: Color {
        switch report.outcome {
        case .returnedToHost: return VortexPalette.accent
        case .running: return VortexPalette.positive
        case .cannotLaunch: return VortexPalette.warning
        }
    }

    private func colour(for state: LaunchReport.Check.State) -> Color {
        switch state {
        case .pass: return VortexPalette.positive
        case .fail: return VortexPalette.critical
        case .info: return VortexPalette.secondaryText
        }
    }
}

// MARK: - Wallpaper picker

struct WallpaperPickerView: View {
    @ObservedObject var model: SpringBoardModel
    @Environment(\.dismiss) private var dismiss

    private let columns = [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)]

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: columns, spacing: 16) {
                    ForEach(SimulatedWallpaper.all) { paper in
                        Button {
                            model.selectWallpaper(paper)
                        } label: {
                            VStack(alignment: .leading, spacing: 8) {
                                SimulatedWallpaperView(wallpaper: paper)
                                    .frame(height: 230)
                                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                                    .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous)
                                        .strokeBorder(model.wallpaper.id == paper.id
                                                        ? VortexPalette.accent
                                                        : Color.white.opacity(0.10),
                                                      lineWidth: model.wallpaper.id == paper.id ? 2 : 1))
                                Text(paper.name)
                                    .font(.system(size: 12, weight: .medium))
                                    .foregroundStyle(VortexPalette.secondaryText)
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(18)
            }
            .background(VortexPalette.background.ignoresSafeArea())
            .navigationTitle("Wallpaper")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}
