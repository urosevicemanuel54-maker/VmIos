//
//  LaunchReport.swift
//  Vortex
//
//  The result of an attempt to start something from the home screen: either a
//  running guest process, the host display, or a failure that names the reason.
//

import Foundation

struct LaunchReport: Identifiable {
    enum Outcome: Equatable {
        /// The icon is a host-side view, not a guest process.
        case returnedToHost
        /// A guest process started in the interpreter.
        case running(processIndex: Int)
        case cannotLaunch(String)
    }

    struct Check: Identifiable, Equatable {
        enum State: Equatable { case pass, fail, info }
        let id: String
        let title: String
        let detail: String
        let state: State
    }

    let app: SimulatedApp
    let checks: [Check]
    let outcome: Outcome
    let footnote: String

    var id: String { app.id }
}
