//
//  EnvironmentView.swift
//  Vortex
//
//  Root of the simulated environment: boot, lock screen, home screen and the
//  overlays that sit above it. Presenting this is a full-screen cover, so a
//  downward swipe from the home screen dismisses the whole environment.
//

import SwiftUI

struct EnvironmentView: View {
    @ObservedObject var emulator: EmulatorModel
    @Environment(\.dismiss) private var dismiss

    @StateObject private var environment: GuestEnvironmentModel
    @State private var isShowingFiles = false
    @State private var isShowingSettings = false

    init(emulator: EmulatorModel) {
        self.emulator = emulator
        _environment = StateObject(wrappedValue: GuestEnvironmentModel(core: emulator.core))
    }

    var body: some View {
        ZStack {
            if environment.bootStage == .idle {
                LockScreenView(environment: environment)
                    .transition(.opacity)
            } else if environment.isLocked {
                LockScreenView(environment: environment)
                    .transition(.opacity)
            } else {
                homeLayer
                    .transition(.opacity)
            }

            overlayLayer
        }
        .preferredColorScheme(.dark)
        .statusBarHidden(true)
        .onAppear {
            if environment.bootStage == .idle {
                environment.boot()
            }
            environment.tick(emulator.core.stats)
        }
        .fullScreenCover(isPresented: $isShowingFiles) {
            FilesAppView(environment: environment)
        }
        .sheet(isPresented: $isShowingSettings) {
            EnvironmentSettingsView(environment: environment, emulator: emulator)
        }
    }

    // MARK: - Home

    private var homeLayer: some View {
        HomeScreenView(environment: environment,
                       onReturnToHost: { dismiss() },
                       onOpenFiles: { isShowingFiles = true },
                       onOpenSettings: { isShowingSettings = true },
                       onOpenMonitor: { dismiss() })
    }

    // MARK: - Overlays

    @ViewBuilder
    private var overlayLayer: some View {
        if environment.isLocked == false, environment.overlay != .none {
            ZStack {
                Color.black.opacity(0.25)
                    .ignoresSafeArea()
                    .onTapGesture {
                        withAnimation(.easeOut(duration: 0.2)) { environment.overlay = .none }
                    }

                VStack {
                    if environment.overlay == .notifications {
                        NotificationCentreView(environment: environment,
                                               isPresented: overlayBinding)
                            .transition(.move(edge: .top).combined(with: .opacity))
                        Spacer(minLength: 0)
                    } else {
                        Spacer(minLength: 0)
                        ControlCentreView(environment: environment,
                                          emulator: emulator,
                                          isPresented: overlayBinding)
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
                .padding(.top, environment.overlay == .notifications ? 58 : 0)
                .padding(.bottom, environment.overlay == .controlCentre ? 20 : 0)
            }
            .transition(.opacity)
        }
    }

    private var overlayBinding: Binding<Bool> {
        Binding(get: { environment.overlay != .none },
                set: { isPresented in
                    if !isPresented {
                        withAnimation(.easeOut(duration: 0.22)) { environment.overlay = .none }
                    }
                })
    }
}

// MARK: - Environment settings

struct EnvironmentSettingsView: View {
    @ObservedObject var environment: GuestEnvironmentModel
    @ObservedObject var emulator: EmulatorModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section("Environment") {
                    LabeledContent("Boot stage", value: environment.bootStage.title)
                    LabeledContent("Locked", value: environment.isLocked ? "Yes" : "No")
                    Button("Re-run boot sequence") {
                        environment.reboot()
                    }
                    Button("Lock now") {
                        environment.lock()
                        dismiss()
                    }
                }

                Section("Guest runtime") {
                    LabeledContent("Execution", value: emulator.jit.executionMode.label)
                    LabeledContent("Processes", value: "\(environment.runtime.processes.count)")
                    LabeledContent("Syscalls serviced", value: "\(environment.runtime.syscallCount)")
                    LabeledContent("Slice budget", value: "\(emulator.core.sliceBudget) insn")
                    Button("Start framebuffer painter") {
                        environment.startPainter()
                    }
                    Button("Stop every guest process", role: .destructive) {
                        emulator.core.stopGuests()
                        environment.systemEvent("All guest processes stopped", severity: .warning)
                    }
                }

                Section("Virtual filesystem") {
                    LabeledContent("Container", value: "filesystem.vfs")
                    LabeledContent("Entries", value: "\(environment.filesystem.nodeCount)")
                    LabeledContent("File bytes", value: "\(environment.filesystem.usedBytes)")
                    Button("Save container now") {
                        let saved = environment.filesystem.save()
                        environment.systemEvent(saved ? "Filesystem container written" : "Filesystem save failed: \(environment.filesystem.lastError)",
                                                severity: saved ? .info : .error)
                    }
                    Button("Restore default tree", role: .destructive) {
                        environment.filesystem.seedDefaultTree()
                        environment.filesystem.save()
                        environment.systemEvent("Default filesystem tree restored", severity: .warning)
                    }
                }

                Section("Honest limits") {
                    Text("The lock screen, Control Centre and Notification Center are original Vortex interfaces. They do not run Apple code, and the boot sequence reports the guest runtime's own preparation rather than firmware execution.")
                        .font(.system(size: 12))
                        .foregroundStyle(.secondary)
                    Text("Brightness and volume are simulated values with no system effect. Frame limit and render scale are real settings on the host renderer.")
                        .font(.system(size: 12))
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}
