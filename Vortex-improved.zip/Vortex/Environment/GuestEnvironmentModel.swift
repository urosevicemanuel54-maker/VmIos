//
//  GuestEnvironmentModel.swift
//  Vortex
//
//  The simulated system environment's session state: boot progress, the lock
//  screen, the overlay panels and the event feed Notification Center shows.
//
//  Everything here is an original interface drawn by Vortex. It is not Apple's
//  operating system, and the boot sequence is a progress readout for the guest
//  runtime, not firmware execution.
//

import Foundation
import SwiftUI

/// One notification shown in Notification Center.
struct EnvironmentEvent: Identifiable, Equatable {
    enum Severity: Int, Equatable {
        case info = 0
        case warning = 1
        case error = 2

        var label: String {
            switch self {
            case .info: return "Info"
            case .warning: return "Warning"
            case .error: return "Error"
            }
        }

        var tint: Color {
            switch self {
            case .info: return VortexPalette.accent
            case .warning: return VortexPalette.warning
            case .error: return VortexPalette.critical
            }
        }

        var symbolName: String {
            switch self {
            case .info: return "info.circle.fill"
            case .warning: return "exclamationmark.triangle.fill"
            case .error: return "xmark.octagon.fill"
            }
        }
    }

    let id: UInt64
    let tick: UInt64
    let severity: Severity
    let message: String
    let date: Date
}

/// Which overlay is open over the home screen.
enum EnvironmentOverlay: Equatable {
    case none
    case controlCentre
    case notifications
}

final class GuestEnvironmentModel: ObservableObject {
    enum BootStage: Int, CaseIterable {
        case idle
        case graphics
        case memory
        case filesystem
        case runtime
        case springBoard
        case ready

        var title: String {
            switch self {
            case .idle: return "Waiting to boot"
            case .graphics: return "Metal display"
            case .memory: return "Guest memory"
            case .filesystem: return "Virtual filesystem"
            case .runtime: return "Guest runtime"
            case .springBoard: return "Home screen"
            case .ready: return "Ready"
            }
        }

        /// The progress bar fills in these steps; idle is zero.
        var progress: Double {
            Double(rawValue) / Double(BootStage.ready.rawValue)
        }
    }

    @Published private(set) var bootStage: BootStage = .idle
    @Published private(set) var bootLog: [String] = []
    @Published private(set) var isLocked = true
    @Published private(set) var events: [EnvironmentEvent] = []
    @Published var overlay: EnvironmentOverlay = .none
    @Published var isShowingEventLogForPanels = false

    /// Settings the Control Centre actually changes on the host renderer.
    @Published var brightness: Double = 0.85
    @Published var volume: Double = 0.6
    @Published var isLowPowerSimulated = false

    private var lastSeenEventSequence: UInt64 = 0
    private var lastSeenTick: UInt64 = 0

    let core: VortexCoreHandle
    let filesystem: GuestFilesystem
    let runtime: GuestRuntime

    init(core: VortexCoreHandle) {
        self.core = core
        self.filesystem = GuestFilesystem(pointer: core.filesystemPointer)
        self.runtime = GuestRuntime(pointer: core.runtimePointer)
        loadFilesystem()
    }

    // MARK: - Boot

    func loadFilesystem() {
        filesystem.load()
    }

    /// Runs the boot sequence. Each stage reports what was actually done: the
    /// Metal renderer and the runtime are real, and the filesystem is mounted
    /// from its container or seeded.
    func boot() {
        guard bootStage == .idle || bootStage == .ready else { return }
        bootStage = .idle
        bootLog = []
        isLocked = true

        advance(to: .graphics, log: "Metal device queried; virtual display ready at \(core.stats.guestWidth) x \(core.stats.guestHeight).")
        advance(to: .memory, log: "Guest arena \(cpuMemoryMB) MB mapped read-write, not executable.")
        advance(to: .filesystem, log: "Virtual filesystem mounted with \(filesystem.nodeCount) entries (\(filesystem.usedBytes) bytes of file content).")
        advance(to: .runtime, log: "Runtime attached: \(runtime.processes.count) process slots, \(VORTEX_RUNTIME_MAX_PROCESSES) maximum.")
        advance(to: .springBoard, log: "Home screen laid out from the saved layout.")
        advance(to: .ready, log: "Environment ready. This is a simulated interface, not Apple's operating system.")
        loadEvents()
    }

    func reboot() {
        bootStage = .idle
        events = []
        lastSeenEventSequence = 0
        boot()
    }

    private var cpuMemoryMB: Int {
        max(1, core.cpu.memorySize() / (1024 * 1024))
    }

    private func advance(to stage: BootStage, log: String) {
        bootStage = stage
        bootLog.append(log)
    }

    // MARK: - Lock

    func unlock() {
        withAnimation(.easeOut(duration: 0.28)) {
            isLocked = false
        }
        systemEvent("Guest environment unlocked", severity: .info)
    }

    func lock() {
        withAnimation(.easeInOut(duration: 0.2)) {
            isLocked = true
            overlay = .none
        }
    }

    // MARK: - Events

    /// Pulls new runtime events into the feed. Called on the environment's tick.
    func loadEvents() {
        guard let pointer = runtime.pointer else { return }
        var buffer = [vortex_runtime_event](repeating: vortex_runtime_event(), count: 32)
        var count = 0
        buffer.withUnsafeMutableBufferPointer { raw in
            guard let base = raw.baseAddress else { return }
            vortex_runtime_copy_events(pointer, base, raw.count, &count)
        }
        guard count > 0 else { return }

        var merged = events
        for index in 0..<count {
            let raw = buffer[index]
            guard raw.sequence > lastSeenEventSequence else { continue }
            lastSeenEventSequence = max(lastSeenEventSequence, raw.sequence)
            let message = withUnsafePointer(to: buffer[index].message) { pointer in
                pointer.withMemoryRebound(to: CChar.self, capacity: 160) { String(cString: $0) }
            }
            let trimmed = message.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty else { continue }
            merged.append(EnvironmentEvent(id: raw.sequence,
                                           tick: raw.tick,
                                           severity: EnvironmentEvent.Severity(rawValue: Int(raw.severity)) ?? .info,
                                           message: trimmed,
                                           date: Date()))
        }

        // Newest first, capped so the list stays readable.
        events = Array(merged.suffix(40).reversed())
    }

    /// Adds an event from the environment itself (package import, boot fault).
    func systemEvent(_ message: String, severity: EnvironmentEvent.Severity) {
        lastSeenEventSequence += 1
        let event = EnvironmentEvent(id: lastSeenEventSequence,
                                     tick: lastSeenTick,
                                     severity: severity,
                                     message: message,
                                     date: Date())
        events.insert(event, at: 0)
        if events.count > 40 {
            events.removeLast(events.count - 40)
        }
    }

    func dismiss(_ event: EnvironmentEvent) {
        events.removeAll { $0.id == event.id }
    }

    func dismissAll() {
        events.removeAll()
    }

    var unreadCount: Int {
        events.filter { !$0.isReadPlaceholder }.count
    }

    /// Number shown on the notification badge; the feed is capped, so this is
    /// the count of live entries rather than an unread tally.
    var badgeCount: Int { min(events.count, 9) }

    // MARK: - Guest control

    /// Boots the framebuffer painter so the environment has something to show.
    func startPainter() {
        let result = core.launchSample(.painter)
        if result >= 0 {
            systemEvent("Guest painter started in process slot \(result)", severity: .info)
        } else {
            systemEvent("Guest launch failed: \(runtimeErrorText)", severity: .error)
        }
        loadEvents()
    }

    private var runtimeErrorText: String {
        let text = runtime.errorText
        return text.isEmpty ? "the runtime did not report a reason" : text
    }

    func tick(_ stats: VortexCoreStats) {
        lastSeenTick = stats.guestTicks
        loadEvents()
    }
}

private extension EnvironmentEvent {
    /// The feed has no read/unread model yet; this keeps the badge honest.
    var isReadPlaceholder: Bool { false }
}
