//
//  EnvironmentPanels.swift
//  Vortex
//
//  Control Centre and Notification Center for the simulated environment.
//
//  Control Centre's frame-limit and render-scale controls act on the real host
//  renderer; the brightness, volume and connectivity tiles are simulated and say
//  so. Notification Center lists events the runtime actually raised.
//

import SwiftUI

// MARK: - Control Centre

struct ControlCentreView: View {
    @ObservedObject var environment: GuestEnvironmentModel
    @ObservedObject var emulator: EmulatorModel
    @Binding var isPresented: Bool

    var body: some View {
        VStack(spacing: 12) {
            grabber

            HStack(spacing: 12) {
                connectivityCluster
                mediaCluster
            }

            HStack(spacing: 12) {
                sliderTile(title: "Brightness",
                           symbolName: "sun.max.fill",
                           value: $environment.brightness,
                           isSimulated: true)
                sliderTile(title: "Volume",
                           symbolName: "speaker.wave.2.fill",
                           value: $environment.volume,
                           isSimulated: true)
            }

            framePacingTile

            toggleTile

            Text("Brightness, volume and the connectivity cluster are simulated. Frame limit and render scale change the real host renderer.")
                .font(.system(size: 10.5))
                .foregroundStyle(Color.white.opacity(0.5))
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.horizontal, 8)
        }
        .padding(16)
        .padding(.bottom, 6)
        .background {
            RoundedRectangle(cornerRadius: 34, style: .continuous)
                .fill(.ultraThinMaterial)
                .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous)
                    .fill(Color.black.opacity(0.22)))
                .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous)
                    .strokeBorder(Color.white.opacity(0.14), lineWidth: 1))
        }
        .padding(.horizontal, 12)
        .gesture(
            DragGesture(minimumDistance: 20)
                .onEnded { value in
                    if value.translation.height < -40 {
                        withAnimation(.easeOut(duration: 0.2)) { isPresented = false }
                    }
                }
        )
    }

    private var grabber: some View {
        Capsule()
            .fill(Color.white.opacity(0.32))
            .frame(width: 38, height: 5)
            .padding(.top, 2)
    }

    private var connectivityCluster: some View {
        VStack(spacing: 10) {
            HStack(spacing: 10) {
                clusterButton("airplane", active: false)
                clusterButton("wifi", active: true)
            }
            HStack(spacing: 10) {
                clusterButton("antenna.radiowaves.left.and.right", active: false)
                clusterButton("bluetooth", active: false)
            }
            Text("Simulated")
                .font(.system(size: 10, weight: .medium))
                .foregroundStyle(Color.white.opacity(0.55))
        }
        .padding(14)
        .frame(maxWidth: .infinity)
        .background(tileBackground(radius: 24))
    }

    private func clusterButton(_ symbol: String, active: Bool) -> some View {
        Image(systemName: symbol)
            .font(.system(size: 17, weight: .semibold))
            .foregroundStyle(active ? Color.white : Color.white.opacity(0.5))
            .frame(width: 44, height: 44)
            .background(Circle().fill(active ? VortexPalette.accent : Color.white.opacity(0.12)))
    }

    private var mediaCluster: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Nothing playing")
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(.white)
            Text("The environment has no audio pipeline.")
                .font(.system(size: 11))
                .foregroundStyle(Color.white.opacity(0.55))
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 16) {
                Image(systemName: "backward.fill")
                Image(systemName: "play.fill")
                Image(systemName: "forward.fill")
            }
            .font(.system(size: 13))
            .foregroundStyle(Color.white.opacity(0.35))
        }
        .padding(14)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .background(tileBackground(radius: 24))
    }

    private func sliderTile(title: String,
                            symbolName: String,
                            value: Binding<Double>,
                            isSimulated: Bool) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Image(systemName: symbolName)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(Color.white.opacity(0.75))
                Text(title)
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(Color.white.opacity(0.75))
            }
            GeometryReader { geometry in
                ZStack(alignment: .bottom) {
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(Color.white.opacity(0.14))
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(Color.white.opacity(0.85))
                        .frame(height: max(6, geometry.size.height * value.wrappedValue))
                }
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { drag in
                            let ratio = 1 - min(max(drag.location.y / geometry.size.height, 0), 1)
                            value.wrappedValue = ratio
                        }
                )
            }
            .frame(height: 96)
            if isSimulated {
                Text("Simulated")
                    .font(.system(size: 9.5, weight: .medium))
                    .foregroundStyle(Color.white.opacity(0.45))
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity)
        .background(tileBackground(radius: 24))
        .accessibilityElement()
        .accessibilityLabel("\(title), simulated")
        .accessibilityValue("\(Int(value.wrappedValue * 100)) percent")
    }

    private var framePacingTile: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Frame limit")
                    .font(.system(size: 12.5, weight: .medium))
                    .foregroundStyle(Color.white.opacity(0.8))
                Spacer()
                Text("Changes the host renderer")
                    .font(.system(size: 10))
                    .foregroundStyle(Color.white.opacity(0.45))
            }
            FrameLimitPicker(selection: $emulator.frameLimit)
                .frame(height: 38)
        }
        .padding(14)
        .background(tileBackground(radius: 24))
    }

    private var toggleTile: some View {
        HStack(spacing: 12) {
            roundToggle(symbol: "moon.fill", isOn: false, label: "Do Not Disturb")
            roundToggle(symbol: "lock.fill", isOn: environment.isLocked, label: "Lock") {
                environment.lock()
                isPresented = false
            }
            roundToggle(symbol: "arrow.clockwise", isOn: false, label: "Reboot") {
                environment.reboot()
                isPresented = false
            }
        }
        .frame(maxWidth: .infinity)
        .padding(12)
        .background(tileBackground(radius: 24))
    }

    private func roundToggle(symbol: String,
                             isOn: Bool,
                             label: String,
                             action: (() -> Void)? = nil) -> some View {
        Button {
            action?()
        } label: {
            Image(systemName: symbol)
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(isOn ? Color.white : Color.white.opacity(0.75))
                .frame(width: 52, height: 52)
                .background(Circle().fill(isOn ? VortexPalette.accent : Color.white.opacity(0.12)))
        }
        .buttonStyle(.plain)
        .disabled(action == nil)
        .accessibilityLabel(label)
    }

    private func tileBackground(radius: CGFloat) -> some View {
        RoundedRectangle(cornerRadius: radius, style: .continuous)
            .fill(Color.white.opacity(0.10))
            .overlay(RoundedRectangle(cornerRadius: radius, style: .continuous)
                .strokeBorder(Color.white.opacity(0.08), lineWidth: 1))
    }
}

// MARK: - Notification Center

struct NotificationCentreView: View {
    @ObservedObject var environment: GuestEnvironmentModel
    @Binding var isPresented: Bool

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Notifications")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(.white)
                Spacer()
                if !environment.events.isEmpty {
                    Button("Clear") {
                        environment.dismissAll()
                    }
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(VortexPalette.accent)
                }
            }
            .padding(.horizontal, 18)
            .padding(.top, 18)
            .padding(.bottom, 10)

            if environment.events.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "bell.slash")
                        .font(.system(size: 22))
                        .foregroundStyle(Color.white.opacity(0.4))
                    Text("No events yet")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(Color.white.opacity(0.6))
                    Text("Package imports, runtime faults and boot milestones appear here.")
                        .font(.system(size: 11))
                        .foregroundStyle(Color.white.opacity(0.4))
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 40)
            } else {
                ScrollView {
                    VStack(spacing: 8) {
                        ForEach(environment.events) { event in
                            eventRow(event)
                        }
                    }
                    .padding(.horizontal, 14)
                    .padding(.bottom, 16)
                }
            }
        }
        .frame(maxHeight: 420, alignment: .top)
        .background {
            RoundedRectangle(cornerRadius: 34, style: .continuous)
                .fill(.ultraThinMaterial)
                .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous)
                    .fill(Color.black.opacity(0.22)))
                .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous)
                    .strokeBorder(Color.white.opacity(0.14), lineWidth: 1))
        }
        .padding(.horizontal, 12)
        .gesture(
            DragGesture(minimumDistance: 20)
                .onEnded { value in
                    if value.translation.height < -40 {
                        withAnimation(.easeOut(duration: 0.2)) { isPresented = false }
                    }
                }
        )
    }

    private func eventRow(_ event: EnvironmentEvent) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: event.severity.symbolName)
                .font(.system(size: 14))
                .foregroundStyle(event.severity.tint)
                .padding(.top, 1)
            VStack(alignment: .leading, spacing: 3) {
                Text(event.message)
                    .font(.system(size: 12.5, weight: .medium))
                    .foregroundStyle(.white)
                    .fixedSize(horizontal: false, vertical: true)
                Text("\(event.severity.label) · tick \(event.tick)")
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(Color.white.opacity(0.45))
            }
            Spacer(minLength: 0)
            Button {
                environment.dismiss(event)
            } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundStyle(Color.white.opacity(0.5))
                    .frame(width: 26, height: 26)
                    .background(Circle().fill(Color.white.opacity(0.10)))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Dismiss notification")
        }
        .padding(12)
        .background {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(Color.white.opacity(0.10))
        }
    }
}
