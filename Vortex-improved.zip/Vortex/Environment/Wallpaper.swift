//
//  Wallpaper.swift
//  Vortex
//
//  Simulated wallpapers for the environment. Original artwork, drawn with
//  gradients and soft blooms rather than bundled images.
//

import SwiftUI

struct SimulatedWallpaper: Identifiable, Equatable {
    let id: String
    let name: String
    let base: Color
    let primary: Color
    let secondary: Color
    let rim: Color

    static let all: [SimulatedWallpaper] = [
        SimulatedWallpaper(id: "violet-bloom",
                           name: "Violet bloom",
                           base: Color(red: 0.027, green: 0.035, blue: 0.063),
                           primary: Color(red: 0.45, green: 0.20, blue: 0.95),
                           secondary: Color(red: 0.10, green: 0.62, blue: 0.80),
                           rim: Color(red: 0.62, green: 0.45, blue: 1.0)),
        SimulatedWallpaper(id: "deep-teal",
                           name: "Deep teal",
                           base: Color(red: 0.020, green: 0.043, blue: 0.051),
                           primary: Color(red: 0.05, green: 0.58, blue: 0.62),
                           secondary: Color(red: 0.06, green: 0.30, blue: 0.72),
                           rim: Color(red: 0.42, green: 0.92, blue: 0.95)),
        SimulatedWallpaper(id: "dusk",
                           name: "Dusk",
                           base: Color(red: 0.055, green: 0.031, blue: 0.055),
                           primary: Color(red: 0.74, green: 0.30, blue: 0.55),
                           secondary: Color(red: 0.95, green: 0.52, blue: 0.28),
                           rim: Color(red: 1.0, green: 0.66, blue: 0.45)),
        SimulatedWallpaper(id: "graphite",
                           name: "Graphite",
                           base: Color(red: 0.035, green: 0.037, blue: 0.043),
                           primary: Color(red: 0.32, green: 0.35, blue: 0.42),
                           secondary: Color(red: 0.16, green: 0.20, blue: 0.26),
                           rim: Color(red: 0.55, green: 0.60, blue: 0.70))
    ]

    static let fallback = all[0]

    static func wallpaper(id: String) -> SimulatedWallpaper {
        all.first { $0.id == id } ?? fallback
    }
}

struct SimulatedWallpaperView: View {
    let wallpaper: SimulatedWallpaper

    var body: some View {
        GeometryReader { geometry in
            let size = geometry.size
            ZStack {
                wallpaper.base

                // Large violet bloom with a bright rim, upper half.
                ZStack {
                    Circle()
                        .fill(RadialGradient(colors: [wallpaper.primary.opacity(0.75),
                                                      wallpaper.primary.opacity(0.12),
                                                      .clear],
                                             center: .center,
                                             startRadius: 0,
                                             endRadius: size.width * 0.72))
                        .frame(width: size.width * 1.6, height: size.width * 1.6)
                        .offset(x: -size.width * 0.42, y: size.height * 0.10)
                        .blur(radius: 42)

                    Circle()
                        .stroke(LinearGradient(colors: [wallpaper.rim.opacity(0.55),
                                                        wallpaper.rim.opacity(0.05)],
                                               startPoint: .top,
                                               endPoint: .bottom),
                                lineWidth: 1.4)
                        .frame(width: size.width * 1.6, height: size.width * 1.6)
                        .offset(x: -size.width * 0.42, y: size.height * 0.10)
                        .blur(radius: 6)
                }

                // Teal bloom sweeping in from the lower right.
                ZStack {
                    Circle()
                        .fill(RadialGradient(colors: [wallpaper.secondary.opacity(0.55),
                                                      wallpaper.secondary.opacity(0.08),
                                                      .clear],
                                             center: .center,
                                             startRadius: 0,
                                             endRadius: size.width * 0.70))
                        .frame(width: size.width * 1.5, height: size.width * 1.5)
                        .offset(x: size.width * 0.62, y: size.height * 0.46)
                        .blur(radius: 48)

                    Circle()
                        .stroke(wallpaper.rim.opacity(0.18), lineWidth: 1.2)
                        .frame(width: size.width * 1.5, height: size.width * 1.5)
                        .offset(x: size.width * 0.62, y: size.height * 0.46)
                        .blur(radius: 5)
                }

                // Slight vignette so the icons stay legible.
                RadialGradient(colors: [.clear, Color.black.opacity(0.35)],
                               center: .center,
                               startRadius: size.width * 0.35,
                               endRadius: size.width * 0.95)
            }
            .ignoresSafeArea()
        }
    }
}
