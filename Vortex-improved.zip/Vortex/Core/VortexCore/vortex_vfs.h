//
//  vortex_vfs.h
//  Vortex
//
//  The virtual filesystem: POSIX-like absolute paths, directories, files and
//  open handles, persisted as one container file so a session survives relaunch.
//
//  The filesystem lives in the emulator core, not in the guest's own RAM. The
//  guest reaches it only through the runtime's syscall table, exactly as a real
//  process would.
//

#ifndef VORTEX_VFS_H
#define VORTEX_VFS_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define VORTEX_VFS_MAX_NODES 256u
#define VORTEX_VFS_MAX_PATH 192u
#define VORTEX_VFS_MAX_HANDLES 24u
#define VORTEX_VFS_MAX_FILE_BYTES (1024u * 1024u)
#define VORTEX_VFS_MAX_COMPONENT 48u

/// Container file identity. The container is device-local and not a portable
/// archive format; version 1 is the only version this build reads.
#define VORTEX_VFS_CONTAINER_MAGIC 0x53465856u
#define VORTEX_VFS_CONTAINER_VERSION 1u

typedef enum vortex_vfs_node_type {
    VORTEX_VFS_TYPE_FILE = 0,
    VORTEX_VFS_TYPE_DIRECTORY = 1
} vortex_vfs_node_type;

/// Open flags. Read is 0; write truncates and opens at offset 0; create makes
/// the file when it is missing.
#define VORTEX_VFS_OPEN_READ 0u
#define VORTEX_VFS_OPEN_WRITE 1u
#define VORTEX_VFS_OPEN_CREATE 2u

typedef struct vortex_vfs_stat {
    char path[VORTEX_VFS_MAX_PATH];
    uint32_t type;
    uint64_t size;
} vortex_vfs_stat;

typedef struct vortex_vfs vortex_vfs;

vortex_vfs *vortex_vfs_create(void);
void vortex_vfs_destroy(vortex_vfs *vfs);

/// Empties the tree back to a bare root directory and closes every handle.
void vortex_vfs_reset(vortex_vfs *vfs);

/// Creates a directory. The parent must already exist. Returns false and sets
/// the last error when the path is invalid, already taken, or has no parent.
bool vortex_vfs_mkdir(vortex_vfs *vfs, const char *path);

/// Creates or replaces a file's contents.
bool vortex_vfs_write_file(vortex_vfs *vfs, const char *path, const void *bytes, size_t size);

/// Reads a whole file. Returns the number of bytes copied, 0 when the file is
/// empty or absent.
size_t vortex_vfs_read_file(const vortex_vfs *vfs, const char *path, void *out, size_t capacity);

/// Opens a file. Returns a handle index in 0..VORTEX_VFS_MAX_HANDLES-1, or -1.
int32_t vortex_vfs_open(vortex_vfs *vfs, const char *path, uint32_t flags);
size_t vortex_vfs_read(vortex_vfs *vfs, int32_t handle, void *out, size_t size);
size_t vortex_vfs_write(vortex_vfs *vfs, int32_t handle, const void *bytes, size_t size);
bool vortex_vfs_close(vortex_vfs *vfs, int32_t handle);
bool vortex_vfs_seek(vortex_vfs *vfs, int32_t handle, size_t offset);

bool vortex_vfs_remove(vortex_vfs *vfs, const char *path);
bool vortex_vfs_stat_path(const vortex_vfs *vfs, const char *path, vortex_vfs_stat *out);
bool vortex_vfs_exists(const vortex_vfs *vfs, const char *path);

/// Enumerates nodes in creation order, root first. Used by the file browser.
size_t vortex_vfs_node_count(const vortex_vfs *vfs);
bool vortex_vfs_node_at(const vortex_vfs *vfs, size_t index, vortex_vfs_stat *out);

/// Writes the whole tree to a container file. The write is atomic: it goes to a
/// sibling temporary file and is renamed into place only on success.
bool vortex_vfs_save(vortex_vfs *vfs, const char *container_path);

/// Replaces the whole tree from a container file. On any validation failure the
/// filesystem is left empty rather than half-loaded.
bool vortex_vfs_load(vortex_vfs *vfs, const char *container_path);

/// Human-readable reason for the last failure, or "" when the last call worked.
const char *vortex_vfs_last_error(const vortex_vfs *vfs);
void vortex_vfs_clear_error(vortex_vfs *vfs);

/// Exposed for tests: normalises an absolute path into `out`.
/// Returns false for relative paths, ".." components, or oversized results.
bool vortex_vfs_normalise(const char *input, char *out, size_t capacity);

#ifdef __cplusplus
}
#endif

#endif /* VORTEX_VFS_H */
