//
//  vortex_runtime.h
//  Vortex
//
//  The guest runtime layer: a process table, a scheduler that interleaves guest
//  execution slices with the host's render loop, a syscall table implemented on
//  top of the virtual filesystem, and a guest-writable framebuffer.
//
//  One CPU is shared by every process. Each process therefore keeps its own
//  architectural context, swapped in on scheduling and saved on yield; guest
//  memory is common because this build has no memory-protection unit to isolate
//  address spaces with. That is a real limitation and is reported as one.
//

#ifndef VORTEX_RUNTIME_H
#define VORTEX_RUNTIME_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "vortex_cpu.h"
#include "vortex_vfs.h"

#ifdef __cplusplus
extern "C" {
#endif

#define VORTEX_RUNTIME_MAX_PROCESSES 4u
#define VORTEX_RUNTIME_MAX_NAME 32u
#define VORTEX_RUNTIME_NULL_HANDLE 0xFFFFFFFFu

/// Syscall numbers. These are Vortex's own ABI, not the Linux or Darwin one:
/// the runtime is an original layer, and a guest is compiled against this table.
#define VORTEX_SYSCALL_EXIT 0u
#define VORTEX_SYSCALL_WRITE 1u
#define VORTEX_SYSCALL_READ 2u
#define VORTEX_SYSCALL_OPEN 3u
#define VORTEX_SYSCALL_CLOSE 4u
#define VORTEX_SYSCALL_YIELD 5u
#define VORTEX_SYSCALL_TICKS 6u
#define VORTEX_SYSCALL_FB_INFO 7u
#define VORTEX_SYSCALL_FB_FLUSH 8u
#define VORTEX_SYSCALL_CLEAR 9u
#define VORTEX_SYSCALL_PLOT 10u
#define VORTEX_SYSCALL_TEXTCLEAR 11u
#define VORTEX_SYSCALL_STDOUT 12u
#define VORTEX_SYSCALL_DRAWCHAR 13u
#define VORTEX_SYSCALL_COUNT 14u

typedef enum vortex_process_state {
    VORTEX_PROCESS_UNUSED = 0,
    VORTEX_PROCESS_READY = 1,
    VORTEX_PROCESS_RUNNING = 2,
    VORTEX_PROCESS_EXITED = 3,
    VORTEX_PROCESS_TRAPPED = 4
} vortex_process_state;

typedef enum vortex_runtime_severity {
    VORTEX_SEVERITY_INFO = 0,
    VORTEX_SEVERITY_WARNING = 1,
    VORTEX_SEVERITY_ERROR = 2
} vortex_runtime_severity;

/// Opaque runtime instance. Declared before the event API because that API
/// takes one by pointer.
typedef struct vortex_runtime vortex_runtime;

/// A runtime event: a spawn, a clean exit, a trap, or a filesystem failure. The
/// environment lists them in Notification Center; the severity colours them.
typedef struct vortex_runtime_event {
    uint64_t sequence;
    uint64_t tick;
    uint32_t severity;
    char message[160];
} vortex_runtime_event;

/// Events are kept in a ring; the environment drains them each frame.
void vortex_runtime_copy_events(const vortex_runtime *runtime,
                                vortex_runtime_event *out_events,
                                size_t capacity,
                                size_t *out_count);
size_t vortex_runtime_event_count(const vortex_runtime *runtime);

/// Records the guest tick an event is stamped with.
void vortex_runtime_note_tick(vortex_runtime *runtime, uint64_t tick);

/// Address space layout shared by every guest program in this build.
#define VORTEX_GUEST_TEXT_BASE 0x1000u
#define VORTEX_GUEST_STACK_TOP 0x003E0000u
#define VORTEX_GUEST_HEAP_BASE 0x00100000u
#define VORTEX_GUEST_FRAMEBUFFER_BASE 0x00200000u
#define VORTEX_GUEST_FRAMEBUFFER_WIDTH 320u
#define VORTEX_GUEST_FRAMEBUFFER_HEIGHT 208u
#define VORTEX_GUEST_FRAMEBUFFER_BYTES (VORTEX_GUEST_FRAMEBUFFER_WIDTH * VORTEX_GUEST_FRAMEBUFFER_HEIGHT * 4u)

typedef struct vortex_runtime_process {
    uint32_t state;
    char name[VORTEX_RUNTIME_MAX_NAME];
    char path[VORTEX_VFS_MAX_PATH];
    uint64_t x[31];
    uint64_t sp;
    uint64_t pc;
    uint32_t nzcv;
    uint64_t ticks;
    uint64_t slices;
    int32_t exit_code;
    uint32_t trap_syscall;
    char diagnosis[160];
} vortex_runtime_process;

typedef struct vortex_runtime_config {
    /// Instructions each process may execute per scheduling slice.
    size_t slice_instructions;
} vortex_runtime_config;

vortex_runtime *vortex_runtime_create(void);
void vortex_runtime_destroy(vortex_runtime *vortex);

void vortex_runtime_reset(vortex_runtime *runtime);

/// Replaces the runtime's CPU and filesystem. The runtime never owns either.
void vortex_runtime_attach(vortex_runtime *runtime, vortex_cpu *cpu, vortex_vfs *vfs);

/// Instructions each process may execute per slice.
void vortex_runtime_set_slice_instructions(vortex_runtime *runtime, size_t instructions);
size_t vortex_runtime_slice_instructions(const vortex_runtime *runtime);

/// Copies a program into guest memory and creates a process at the text base
/// with a fresh stack and frame buffer. Returns the process index, or -1 with
/// the reason in the runtime's last error.
int32_t vortex_runtime_spawn(vortex_runtime *runtime,
                             const char *name,
                             const char *path,
                             const uint32_t *program,
                             size_t word_count);

/// Runs the next ready process for one slice. Returns the number of
/// instructions executed; 0 means every process has stopped.
size_t vortex_runtime_run_slice(vortex_runtime *runtime);

/// Schedules one slice for a named process, regardless of the round-robin
/// cursor. Returns the instructions executed.
size_t vortex_runtime_slice_process(vortex_runtime *runtime, int32_t index);

/// Services a pending supervisor call. Called by the slice scheduler; exposed
/// so the inspector can single-step one.
bool vortex_runtime_service_pending_syscall(vortex_runtime *runtime);

void vortex_runtime_clear_error(vortex_runtime *runtime);

size_t vortex_runtime_process_count(const vortex_runtime *runtime);
bool vortex_runtime_process_at(const vortex_runtime *runtime, size_t index, vortex_runtime_process *out);
int32_t vortex_runtime_find(const vortex_runtime *runtime, const char *name);

/// Standard output of every process, concatenated in arrival order.
size_t vortex_runtime_stdout(const vortex_runtime *runtime, char *out, size_t capacity);
void vortex_runtime_clear_stdout(vortex_runtime *runtime);

/// True when a process painted the frame buffer since the last visit, so the
/// renderer can skip uploading an unchanged image.
bool vortex_runtime_take_framebuffer_dirty(vortex_runtime *runtime);
void vortex_runtime_copy_framebuffer(const vortex_runtime *runtime, void *out);

uint64_t vortex_runtime_syscall_count(const vortex_runtime *runtime);
const char *vortex_runtime_last_error(const vortex_runtime *runtime);

#ifdef __cplusplus
}
#endif

#endif /* VORTEX_RUNTIME_H */
