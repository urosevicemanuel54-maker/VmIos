//
//  vortex_guest_programs.h
//  Vortex
//
//  Two sample guest images shipped with the runtime: an arithmetic benchmark and
//  a framebuffer painter. Both are assembled at runtime from encoded
//  instructions so the encodings can be checked against the interpreter's own
//  disassembler rather than trusted as hand-written hex.
//

#ifndef VORTEX_GUEST_PROGRAMS_H
#define VORTEX_GUEST_PROGRAMS_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define VORTEX_GUEST_IMAGE_CAPACITY 4096u

typedef enum vortex_guest_program {
    VORTEX_GUEST_PROGRAM_BENCHMARK = 0,
    VORTEX_GUEST_PROGRAM_PAINTER = 1
} vortex_guest_program;

/// Builds a program image (code followed by its read-only data) into `out`.
/// Returns the image size in bytes, or 0 when the program is unknown or does
/// not fit.
size_t vortex_guest_build_image(vortex_guest_program program, uint8_t *out, size_t capacity);

/// Size of the code region (the instructions) for a built program. Read-only
/// data follows it, so anything at or beyond this offset is not an instruction.
size_t vortex_guest_code_size(vortex_guest_program program);

/// Address inside guest memory where the benchmark writes its result.
#define VORTEX_GUEST_RESULT_ADDRESS 0x8000u

/// Program name used by the runtime table and the environment's switcher.
const char *vortex_guest_program_name(vortex_guest_program program);

#ifdef __cplusplus
}
#endif

#endif /* VORTEX_GUEST_PROGRAMS_H */
