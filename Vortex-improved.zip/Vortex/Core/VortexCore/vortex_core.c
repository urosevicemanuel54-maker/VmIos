//
//  vortex_core.c
//  Vortex
//
//  Implementation of the native emulator core: the guest clock, the guest
//  raster geometry, the virtual filesystem, the guest runtime and the counters
//  the performance dashboard reports.
//
//  What is implemented here is real and measured: a fixed-step clock that
//  accumulates host time, executes at most VORTEX_CORE_MAX_STEPS_PER_ADVANCE
//  steps per call and runs one guest scheduling slice per tick, plus counters
//  for frames, instructions, syscalls and errors.
//

#include "vortex_core.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>

#define VORTEX_DEFAULT_GUEST_WIDTH 1280u
#define VORTEX_DEFAULT_GUEST_HEIGHT 832u
#define VORTEX_MARKER_PERIOD_SECONDS 6.0
#define VORTEX_MAX_FRAME_DELTA_SECONDS 0.25
#define VORTEX_DEFAULT_SLICE_BUDGET 20000u

struct vortex_core {
    uint32_t guest_width;
    uint32_t guest_height;
    double step_seconds;
    double accumulator;
    uint64_t frames_presented;
    uint64_t frames_skipped;
    uint64_t guest_ticks;
    uint64_t instructions_executed;
    uint64_t emulation_errors;
    size_t slice_budget;
    vortex_cpu *cpu;
    vortex_vfs *vfs;
    vortex_runtime *runtime;
};

static double vortex_fixed_step_seconds(void)
{
    return 1.0 / (double)VORTEX_GUEST_TICK_HZ;
}

vortex_core *vortex_core_create(void)
{
    vortex_core *core = (vortex_core *)calloc(1, sizeof(*core));
    if (core == NULL) {
        return NULL;
    }

    core->guest_width = VORTEX_DEFAULT_GUEST_WIDTH;
    core->guest_height = VORTEX_DEFAULT_GUEST_HEIGHT;
    core->step_seconds = vortex_fixed_step_seconds();
    core->accumulator = 0.0;
    core->slice_budget = VORTEX_DEFAULT_SLICE_BUDGET;

    core->cpu = vortex_cpu_create();
    core->vfs = vortex_vfs_create();
    core->runtime = vortex_runtime_create();
    if (core->cpu == NULL || core->vfs == NULL || core->runtime == NULL) {
        vortex_cpu_destroy(core->cpu);
        vortex_vfs_destroy(core->vfs);
        vortex_runtime_destroy(core->runtime);
        free(core);
        return NULL;
    }
    vortex_runtime_attach(core->runtime, core->cpu, core->vfs);
    return core;
}

void vortex_core_destroy(vortex_core *core)
{
    if (core == NULL) {
        return;
    }
    vortex_runtime_destroy(core->runtime);
    core->runtime = NULL;
    vortex_vfs_destroy(core->vfs);
    core->vfs = NULL;
    vortex_cpu_destroy(core->cpu);
    core->cpu = NULL;
    free(core);
}

void vortex_core_reset(vortex_core *core)
{
    if (core == NULL) {
        return;
    }
    core->accumulator = 0.0;
    core->frames_presented = 0;
    core->frames_skipped = 0;
    core->guest_ticks = 0;
    core->instructions_executed = 0;
    core->emulation_errors = 0;
    if (core->cpu != NULL) {
        vortex_cpu_reset(core->cpu);
    }
    if (core->runtime != NULL) {
        vortex_runtime_reset(core->runtime);
    }
}

bool vortex_core_set_guest_size(vortex_core *core, uint32_t width, uint32_t height)
{
    if (core == NULL) {
        return false;
    }
    if (width < 16u || height < 16u || width > 8192u || height > 8192u) {
        return false;
    }
    core->guest_width = width;
    core->guest_height = height;
    return true;
}

bool vortex_core_advance(vortex_core *core, double delta_seconds)
{
    if (core == NULL) {
        return false;
    }
    /* The comparison also rejects NaN and negative deltas. */
    if (!(delta_seconds > 0.0)) {
        return false;
    }
    if (delta_seconds > VORTEX_MAX_FRAME_DELTA_SECONDS) {
        delta_seconds = VORTEX_MAX_FRAME_DELTA_SECONDS;
    }

    core->accumulator += delta_seconds;

    uint32_t steps = 0;
    while (core->accumulator >= core->step_seconds &&
           steps < VORTEX_CORE_MAX_STEPS_PER_ADVANCE) {
        core->accumulator -= core->step_seconds;
        core->guest_ticks += 1u;
        steps += 1u;

        /* One scheduling slice per guest tick. The slice is capped so a single
           tick can never monopolise the frame, which keeps frame pacing honest
           even when a guest loops tightly. */
        if (core->runtime != NULL) {
            vortex_runtime_note_tick(core->runtime, core->guest_ticks);
            core->instructions_executed += vortex_runtime_run_slice(core->runtime);
        }
    }

    if (steps == VORTEX_CORE_MAX_STEPS_PER_ADVANCE && core->accumulator >= core->step_seconds) {
        /* Too far behind to catch up: drop the debt instead of stalling. */
        core->accumulator = fmod(core->accumulator, core->step_seconds);
    }

    return steps > 0u;
}

void vortex_core_note_frame_presented(vortex_core *core)
{
    if (core == NULL) {
        return;
    }
    core->frames_presented += 1u;
}

void vortex_core_note_frame_skipped(vortex_core *core)
{
    if (core == NULL) {
        return;
    }
    core->frames_skipped += 1u;
}

void vortex_core_note_error(vortex_core *core)
{
    if (core == NULL) {
        return;
    }
    core->emulation_errors += 1u;
}

vortex_core_stats vortex_core_get_stats(const vortex_core *core)
{
    vortex_core_stats stats;

    if (core == NULL) {
        stats.frames_presented = 0;
        stats.frames_skipped = 0;
        stats.guest_ticks = 0;
        stats.instructions_executed = 0;
        stats.emulation_errors = 0;
        stats.guest_width = VORTEX_DEFAULT_GUEST_WIDTH;
        stats.guest_height = VORTEX_DEFAULT_GUEST_HEIGHT;
        stats.tick_hz = VORTEX_GUEST_TICK_HZ;
        stats.syscalls_serviced = 0;
        stats.guest_processes = 0;
        stats.guest_running = 0;
        return stats;
    }

    stats.frames_presented = core->frames_presented;
    stats.frames_skipped = core->frames_skipped;
    stats.guest_ticks = core->guest_ticks;
    stats.instructions_executed = core->instructions_executed;
    stats.emulation_errors = core->emulation_errors;
    if (core->cpu != NULL) {
        vortex_cpu_snapshot snapshot;
        vortex_cpu_copy_snapshot(core->cpu, &snapshot);
        stats.instructions_executed += snapshot.instructions_executed;
        stats.emulation_errors += snapshot.error_count;
    }
    stats.syscalls_serviced = vortex_runtime_syscall_count(core->runtime);
    stats.guest_processes = (uint32_t)vortex_runtime_process_count(core->runtime);
    stats.guest_running = 0;
    for (size_t index = 0; index < VORTEX_RUNTIME_MAX_PROCESSES; index += 1u) {
        vortex_runtime_process process;
        if (!vortex_runtime_process_at(core->runtime, index, &process)) {
            continue;
        }
        if (process.state == VORTEX_PROCESS_READY || process.state == VORTEX_PROCESS_RUNNING) {
            stats.guest_running += 1u;
        }
    }
    stats.guest_width = core->guest_width;
    stats.guest_height = core->guest_height;
    stats.tick_hz = VORTEX_GUEST_TICK_HZ;
    return stats;
}

vortex_cpu *vortex_core_get_cpu(vortex_core *core)
{
    return core == NULL ? NULL : core->cpu;
}

vortex_vfs *vortex_core_get_vfs(vortex_core *core)
{
    return core == NULL ? NULL : core->vfs;
}

vortex_runtime *vortex_core_get_runtime(vortex_core *core)
{
    return core == NULL ? NULL : core->runtime;
}

void vortex_core_set_slice_budget(vortex_core *core, size_t instructions)
{
    if (core == NULL) {
        return;
    }
    size_t bounded = instructions < 1000u ? 1000u : instructions;
    if (bounded > 1000000u) {
        bounded = 1000000u;
    }
    core->slice_budget = bounded;
    if (core->runtime != NULL) {
        vortex_runtime_set_slice_instructions(core->runtime, bounded);
    }
}

size_t vortex_core_slice_budget(const vortex_core *core)
{
    return core == NULL ? 0u : core->slice_budget;
}

int32_t vortex_core_launch_sample(vortex_core *core, vortex_guest_program program)
{
    if (core == NULL || core->runtime == NULL) {
        return -1;
    }

    uint8_t image[VORTEX_GUEST_IMAGE_CAPACITY];
    size_t size = vortex_guest_build_image(program, image, sizeof(image));
    if (size == 0u || (size % 4u) != 0u) {
        return -1;
    }

    int32_t index = vortex_runtime_spawn(core->runtime,
                                         vortex_guest_program_name(program),
                                         "",
                                         (const uint32_t *)image,
                                         size / 4u);
    return index;
}

int32_t vortex_core_launch_package(vortex_core *core, const char *name, const char *path)
{
    if (core == NULL || core->runtime == NULL || core->vfs == NULL || path == NULL) {
        return -1;
    }

    static uint8_t image[VORTEX_GUEST_IMAGE_CAPACITY];
    size_t size = vortex_vfs_read_file(core->vfs, path, image, sizeof(image));
    if (size == 0u) {
        return -1;
    }
    /* A non-multiple of four means the payload is not an instruction stream. */
    if ((size % 4u) != 0u) {
        return -1;
    }
    return vortex_runtime_spawn(core->runtime, name, path, (const uint32_t *)image, size / 4u);
}

void vortex_core_stop_guests(vortex_core *core)
{
    if (core == NULL || core->runtime == NULL) {
        return;
    }
    vortex_runtime_reset(core->runtime);
    if (core->cpu != NULL) {
        vortex_cpu_reset(core->cpu);
    }
}

bool vortex_core_save_filesystem(vortex_core *core, const char *container_path)
{
    if (core == NULL || core->vfs == NULL) {
        return false;
    }
    return vortex_vfs_save(core->vfs, container_path);
}

bool vortex_core_load_filesystem(vortex_core *core, const char *container_path)
{
    if (core == NULL || core->vfs == NULL) {
        return false;
    }
    return vortex_vfs_load(core->vfs, container_path);
}

void vortex_core_copy_framebuffer(const vortex_core *core, void *out)
{
    if (core == NULL) {
        return;
    }
    vortex_runtime_copy_framebuffer(core->runtime, out);
}

bool vortex_core_take_framebuffer_dirty(vortex_core *core)
{
    return core == NULL ? false : vortex_runtime_take_framebuffer_dirty(core->runtime);
}

uint32_t vortex_core_guest_framebuffer_width(void)
{
    return VORTEX_GUEST_FRAMEBUFFER_WIDTH;
}

uint32_t vortex_core_guest_framebuffer_height(void)
{
    return VORTEX_GUEST_FRAMEBUFFER_HEIGHT;
}

float vortex_core_marker_position(const vortex_core *core)
{
    if (core == NULL) {
        return 0.12f;
    }

    const uint64_t period_ticks = (uint64_t)(VORTEX_MARKER_PERIOD_SECONDS * (double)VORTEX_GUEST_TICK_HZ);
    if (period_ticks == 0u) {
        return 0.5f;
    }

    double phase = (double)(core->guest_ticks % period_ticks) / (double)period_ticks;
    double sweep = phase < 0.5 ? phase * 2.0 : (1.0 - phase) * 2.0;

    /* Keep the marker inside the raster so it never clips at the edges. */
    return (float)(0.12 + sweep * 0.76);
}

uint32_t vortex_core_abi_version(void)
{
    return VORTEX_CORE_ABI_VERSION;
}

const char *vortex_core_build_label(void)
{
    return "Vortex core 0.2 (ARM64 interpreter, VFS, runtime)";
}
