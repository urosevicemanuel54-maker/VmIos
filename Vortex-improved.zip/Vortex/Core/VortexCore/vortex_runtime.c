//
//  vortex_runtime.c
//  Vortex
//
//  Implementation of the guest runtime layer.
//
//  Scheduling is cooperative and round-robin: each process gets a fixed
//  instruction slice, then its architectural context is saved and the next
//  ready process is swapped in. A supervisor call is serviced between slices,
//  which is the only way a guest talks to the outside world.
//

#include "vortex_runtime.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define VORTEX_STDOUT_CAPACITY 4096u
#define VORTEX_DEFAULT_SLICE 20000u
#define VORTEX_EVENT_CAPACITY 32u

struct vortex_runtime {
    vortex_cpu *cpu;
    vortex_vfs *vfs;

    vortex_runtime_process processes[VORTEX_RUNTIME_MAX_PROCESSES];
    size_t next_process;
    size_t current_process;
    size_t slice_instructions;

    uint8_t *framebuffer;
    bool framebuffer_dirty;
    bool framebuffer_owned;

    char stdout_buffer[VORTEX_STDOUT_CAPACITY];
    size_t stdout_length;

    vortex_runtime_event events[VORTEX_EVENT_CAPACITY];
    size_t event_count;
    size_t event_head;
    uint64_t event_sequence;
    uint64_t current_tick;

    uint64_t syscall_count;
    uint64_t events_emitted;
    char error[160];
};

// MARK: - Helpers

static void vortex_runtime_set_error(vortex_runtime *runtime, const char *message)
{
    if (runtime == NULL) {
        return;
    }
    snprintf(runtime->error, sizeof(runtime->error), "%s", message ? message : "");
}

const char *vortex_runtime_last_error(const vortex_runtime *runtime)
{
    return runtime == NULL ? "" : runtime->error;
}

/// Ring buffer, so a chatty guest cannot grow the event list without bound.
static void vortex_runtime_log(vortex_runtime *runtime, uint32_t severity, const char *message)
{
    if (runtime == NULL || message == NULL) {
        return;
    }
    runtime->event_sequence += 1u;
    runtime->events_emitted += 1u;

    vortex_runtime_event *event;
    if (runtime->event_count < VORTEX_EVENT_CAPACITY) {
        event = &runtime->events[(runtime->event_head + runtime->event_count) % VORTEX_EVENT_CAPACITY];
        runtime->event_count += 1u;
    } else {
        event = &runtime->events[runtime->event_head];
        runtime->event_head = (runtime->event_head + 1u) % VORTEX_EVENT_CAPACITY;
    }

    memset(event, 0, sizeof(*event));
    event->sequence = runtime->event_sequence;
    event->tick = runtime->current_tick;
    event->severity = severity;
    snprintf(event->message, sizeof(event->message), "%s", message);
}

void vortex_runtime_copy_events(const vortex_runtime *runtime,
                                vortex_runtime_event *out_events,
                                size_t capacity,
                                size_t *out_count)
{
    if (out_count != NULL) {
        *out_count = 0u;
    }
    if (runtime == NULL || out_events == NULL || capacity == 0u) {
        return;
    }
    size_t written = 0u;
    for (size_t index = 0; index < runtime->event_count && written < capacity; index += 1u) {
        out_events[written] = runtime->events[(runtime->event_head + index) % VORTEX_EVENT_CAPACITY];
        written += 1u;
    }
    if (out_count != NULL) {
        *out_count = written;
    }
}

size_t vortex_runtime_event_count(const vortex_runtime *runtime)
{
    return runtime == NULL ? 0u : runtime->event_count;
}

void vortex_runtime_note_tick(vortex_runtime *runtime, uint64_t tick)
{
    if (runtime != NULL) {
        runtime->current_tick = tick;
    }
}

static uint8_t *vortex_runtime_framebuffer_pointers(vortex_runtime *runtime)
{
    if (runtime == NULL) {
        return NULL;
    }
    return runtime->framebuffer;
}

static void vortex_runtime_append_stdout(vortex_runtime *runtime, const char *bytes, size_t length)
{
    if (bytes == NULL) {
        return;
    }
    for (size_t index = 0; index < length; index += 1u) {
        if (bytes[index] == '\0') {
            break;
        }
        if (runtime->stdout_length + 1u < VORTEX_STDOUT_CAPACITY) {
            runtime->stdout_buffer[runtime->stdout_length] = bytes[index];
            runtime->stdout_length += 1u;
        }
    }
    runtime->stdout_buffer[runtime->stdout_length] = '\0';
}

static vortex_runtime_process *vortex_runtime_current(vortex_runtime *runtime)
{
    if (runtime == NULL || runtime->current_process >= VORTEX_RUNTIME_MAX_PROCESSES) {
        return NULL;
    }
    vortex_runtime_process *process = &runtime->processes[runtime->current_process];
    return process->state == VORTEX_PROCESS_RUNNING ? process : NULL;
}

/// Guest memory the runtime can touch. Both are inside the CPU's arena.
static bool vortex_runtime_guest_read(vortex_runtime *runtime, uint64_t address, void *out, size_t size)
{
    if (size == 0u) {
        return true;
    }
    return vortex_cpu_read_memory(runtime->cpu, address, out, size);
}

static bool vortex_runtime_guest_write(vortex_runtime *runtime, uint64_t address, const void *bytes, size_t size)
{
    if (size == 0u) {
        return true;
    }
    return vortex_cpu_write_memory(runtime->cpu, address, bytes, size);
}

static bool vortex_runtime_read_string(vortex_runtime *runtime, uint64_t address, char *out, size_t capacity)
{
    if (capacity == 0u) {
        return false;
    }
    for (size_t index = 0; index + 1u < capacity; index += 1u) {
        char byte = 0;
        if (!vortex_runtime_guest_read(runtime, address + index, &byte, 1u)) {
            out[index] = '\0';
            return false;
        }
        out[index] = byte;
        if (byte == '\0') {
            return true;
        }
    }
    out[capacity - 1u] = '\0';
    return true;
}

// MARK: - Frame buffer drawing

static void vortex_runtime_plot(vortex_runtime *runtime, uint32_t x, uint32_t y, uint32_t colour)
{
    if (x >= VORTEX_GUEST_FRAMEBUFFER_WIDTH || y >= VORTEX_GUEST_FRAMEBUFFER_HEIGHT) {
        return;
    }
    size_t offset = ((size_t)y * VORTEX_GUEST_FRAMEBUFFER_WIDTH + x) * 4u;
    runtime->framebuffer[offset + 0u] = (uint8_t)(colour & 0xFFu);
    runtime->framebuffer[offset + 1u] = (uint8_t)((colour >> 8) & 0xFFu);
    runtime->framebuffer[offset + 2u] = (uint8_t)((colour >> 16) & 0xFFu);
    runtime->framebuffer[offset + 3u] = 0xFFu;
    runtime->framebuffer_dirty = true;
}

/// 5x7 bitmap font for the printable ASCII range the samples use. Each glyph is
/// seven rows of five bits, most significant bit leftmost.
static const uint8_t vortex_font[][7] = {
    { 0x0E, 0x11, 0x13, 0x15, 0x19, 0x11, 0x0E }, /* 0 */
    { 0x04, 0x0C, 0x04, 0x04, 0x04, 0x04, 0x0E }, /* 1 */
    { 0x0E, 0x11, 0x01, 0x02, 0x04, 0x08, 0x1F }, /* 2 */
    { 0x1F, 0x02, 0x04, 0x02, 0x01, 0x11, 0x0E }, /* 3 */
    { 0x02, 0x06, 0x0A, 0x12, 0x1F, 0x02, 0x02 }, /* 4 */
    { 0x1F, 0x10, 0x1E, 0x01, 0x01, 0x11, 0x0E }, /* 5 */
    { 0x06, 0x08, 0x10, 0x1E, 0x11, 0x11, 0x0E }, /* 6 */
    { 0x1F, 0x01, 0x02, 0x04, 0x08, 0x08, 0x08 }, /* 7 */
    { 0x0E, 0x11, 0x11, 0x0E, 0x11, 0x11, 0x0E }, /* 8 */
    { 0x0E, 0x11, 0x11, 0x0F, 0x01, 0x02, 0x0C }, /* 9 */
    { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }, /* space */
    { 0x04, 0x04, 0x04, 0x04, 0x04, 0x00, 0x04 }, /* ! */
    { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }, /* " */
    { 0x0A, 0x0A, 0x1F, 0x0A, 0x1F, 0x0A, 0x0A }, /* # */
    { 0x04, 0x0F, 0x14, 0x0E, 0x05, 0x1E, 0x04 }, /* $ */
    { 0x18, 0x19, 0x02, 0x04, 0x08, 0x13, 0x03 }, /* % */
    { 0x0C, 0x12, 0x14, 0x08, 0x15, 0x12, 0x0D }, /* & */
    { 0x0C, 0x04, 0x08, 0x00, 0x00, 0x00, 0x00 }, /* ' */
    { 0x02, 0x04, 0x08, 0x08, 0x08, 0x04, 0x02 }, /* ( */
    { 0x08, 0x04, 0x02, 0x02, 0x02, 0x04, 0x08 }, /* ) */
    { 0x00, 0x04, 0x15, 0x0E, 0x15, 0x04, 0x00 }, /* * */
    { 0x00, 0x04, 0x04, 0x1F, 0x04, 0x04, 0x00 }, /* + */
    { 0x00, 0x00, 0x00, 0x00, 0x0C, 0x04, 0x08 }, /* , */
    { 0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00 }, /* - */
    { 0x00, 0x00, 0x00, 0x00, 0x00, 0x0C, 0x0C }, /* . */
    { 0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x00 }, /* / */
    { 0x0E, 0x11, 0x13, 0x15, 0x19, 0x11, 0x0E }, /* @ (reused) */
    { 0x0E, 0x11, 0x11, 0x1F, 0x11, 0x11, 0x11 }, /* A */
    { 0x1E, 0x11, 0x11, 0x1E, 0x11, 0x11, 0x1E }, /* B */
    { 0x0E, 0x11, 0x10, 0x10, 0x10, 0x11, 0x0E }, /* C */
    { 0x1C, 0x12, 0x11, 0x11, 0x11, 0x12, 0x1C }, /* D */
    { 0x1F, 0x10, 0x10, 0x1E, 0x10, 0x10, 0x1F }, /* E */
    { 0x1F, 0x10, 0x10, 0x1E, 0x10, 0x10, 0x10 }, /* F */
    { 0x0E, 0x11, 0x10, 0x17, 0x11, 0x11, 0x0F }, /* G */
    { 0x11, 0x11, 0x11, 0x1F, 0x11, 0x11, 0x11 }, /* H */
    { 0x0E, 0x04, 0x04, 0x04, 0x04, 0x04, 0x0E }, /* I */
    { 0x07, 0x02, 0x02, 0x02, 0x02, 0x12, 0x0C }, /* J */
    { 0x11, 0x12, 0x14, 0x18, 0x14, 0x12, 0x11 }, /* K */
    { 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x1F }, /* L */
    { 0x11, 0x1B, 0x15, 0x15, 0x11, 0x11, 0x11 }, /* M */
    { 0x11, 0x19, 0x15, 0x13, 0x11, 0x11, 0x11 }, /* N */
    { 0x0E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0E }, /* O */
    { 0x1E, 0x11, 0x11, 0x1E, 0x10, 0x10, 0x10 }, /* P */
    { 0x0E, 0x11, 0x11, 0x11, 0x15, 0x12, 0x0D }, /* Q */
    { 0x1E, 0x11, 0x11, 0x1E, 0x14, 0x12, 0x11 }, /* R */
    { 0x0F, 0x10, 0x10, 0x0E, 0x01, 0x01, 0x1E }, /* S */
    { 0x1F, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04 }, /* T */
    { 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0E }, /* U */
    { 0x11, 0x11, 0x11, 0x11, 0x11, 0x0A, 0x04 }, /* V */
    { 0x11, 0x11, 0x11, 0x15, 0x15, 0x15, 0x0A }, /* W */
    { 0x11, 0x11, 0x0A, 0x04, 0x0A, 0x11, 0x11 }, /* X */
    { 0x11, 0x11, 0x0A, 0x04, 0x04, 0x04, 0x04 }, /* Y */
    { 0x1F, 0x01, 0x02, 0x04, 0x08, 0x10, 0x1F }  /* Z */
};

static void vortex_runtime_draw_char(vortex_runtime *runtime, uint32_t x, uint32_t y, char character, uint32_t colour)
{
    int index = -1;
    if (character >= '0' && character <= '9') {
        index = character - '0';
    } else if (character == ' ') {
        index = 10;
    } else if (character >= 'A' && character <= 'Z') {
        index = 36 + (character - 'A');
    } else if (character >= 'a' && character <= 'z') {
        index = 36 + (character - 'a');
    }
    if (index < 0) {
        return;
    }
    const uint8_t *glyph = vortex_font[index];
    for (uint32_t row = 0; row < 7u; row += 1u) {
        for (uint32_t column = 0; column < 5u; column += 1u) {
            if (((glyph[row] >> (4u - column)) & 1u) != 0u) {
                vortex_runtime_plot(runtime, x + column, y + row, colour);
            }
        }
    }
}

// MARK: - Lifecycle

vortex_runtime *vortex_runtime_create(void)
{
    vortex_runtime *runtime = (vortex_runtime *)calloc(1, sizeof(*runtime));
    if (runtime == NULL) {
        return NULL;
    }
    runtime->framebuffer = (uint8_t *)calloc(1, VORTEX_GUEST_FRAMEBUFFER_BYTES);
    if (runtime->framebuffer == NULL) {
        free(runtime);
        return NULL;
    }
    runtime->framebuffer_owned = true;
    runtime->slice_instructions = VORTEX_DEFAULT_SLICE;
    runtime->next_process = 0u;
    runtime->current_process = VORTEX_RUNTIME_MAX_PROCESSES;
    return runtime;
}

void vortex_runtime_destroy(vortex_runtime *runtime)
{
    if (runtime == NULL) {
        return;
    }
    if (runtime->framebuffer_owned) {
        free(runtime->framebuffer);
    }
    free(runtime);
}

void vortex_runtime_reset(vortex_runtime *runtime)
{
    if (runtime == NULL) {
        return;
    }
    memset(runtime->processes, 0, sizeof(runtime->processes));
    runtime->next_process = 0u;
    runtime->current_process = VORTEX_RUNTIME_MAX_PROCESSES;
    runtime->stdout_length = 0;
    runtime->stdout_buffer[0] = '\0';
    runtime->syscall_count = 0u;
    runtime->event_count = 0u;
    runtime->event_head = 0u;
    runtime->current_tick = 0u;
    runtime->framebuffer_dirty = false;
    if (runtime->framebuffer != NULL) {
        memset(runtime->framebuffer, 0, VORTEX_GUEST_FRAMEBUFFER_BYTES);
    }
    vortex_runtime_clear_error(runtime);
}

void vortex_runtime_attach(vortex_runtime *runtime, vortex_cpu *cpu, vortex_vfs *vfs)
{
    if (runtime == NULL) {
        return;
    }
    runtime->cpu = cpu;
    runtime->vfs = vfs;
}

// MARK: - Processes

void vortex_runtime_set_slice_instructions(vortex_runtime *runtime, size_t instructions)
{
    if (runtime == NULL) {
        return;
    }
    runtime->slice_instructions = instructions < 1000u ? 1000u
                                                       : (instructions > 1000000u ? 1000000u : instructions);
}

size_t vortex_runtime_slice_instructions(const vortex_runtime *runtime)
{
    return runtime == NULL ? 0u : runtime->slice_instructions;
}

int32_t vortex_runtime_spawn(vortex_runtime *runtime,
                             const char *name,
                             const char *path,
                             const uint32_t *program,
                             size_t word_count)
{
    if (runtime == NULL || runtime->cpu == NULL) {
        return -1;
    }
    vortex_runtime_clear_error(runtime);

    if (program == NULL || word_count == 0u) {
        vortex_runtime_set_error(runtime, "program is empty");
        return -1;
    }

    size_t slot = VORTEX_RUNTIME_MAX_PROCESSES;
    for (size_t index = 0; index < VORTEX_RUNTIME_MAX_PROCESSES; index += 1u) {
        if (runtime->processes[index].state == VORTEX_PROCESS_UNUSED ||
            runtime->processes[index].state == VORTEX_PROCESS_EXITED ||
            runtime->processes[index].state == VORTEX_PROCESS_TRAPPED) {
            slot = index;
            break;
        }
    }
    if (slot >= VORTEX_RUNTIME_MAX_PROCESSES) {
        vortex_runtime_set_error(runtime, "process table is full");
        return -1;
    }

    /* Every spawn starts from a clear arena: the text, heap, stack and frame
       buffer live at fixed addresses, so a second process would otherwise run
       on the first one's memory. */
    vortex_cpu_clear_memory(runtime->cpu);
    vortex_cpu_reset(runtime->cpu);

    size_t bytes = word_count * sizeof(uint32_t);
    if (!vortex_cpu_write_memory(runtime->cpu, VORTEX_GUEST_TEXT_BASE, program, bytes)) {
        vortex_runtime_set_error(runtime, "program does not fit in guest memory");
        return -1;
    }

    if (runtime->framebuffer != NULL) {
        memset(runtime->framebuffer, 0, VORTEX_GUEST_FRAMEBUFFER_BYTES);
    }
    runtime->framebuffer_dirty = true;
    runtime->stdout_length = 0;
    runtime->stdout_buffer[0] = '\0';
    runtime->syscall_count = 0u;

    vortex_runtime_process *process = &runtime->processes[slot];
    memset(process, 0, sizeof(*process));
    process->state = VORTEX_PROCESS_READY;
    snprintf(process->name, sizeof(process->name), "%s", name == NULL ? "guest" : name);
    snprintf(process->path, sizeof(process->path), "%s", path == NULL ? "" : path);
    process->pc = VORTEX_GUEST_TEXT_BASE;
    process->sp = VORTEX_GUEST_STACK_TOP;
    process->exit_code = 0;
    runtime->next_process = slot;
    {
        char line[128];
        snprintf(line, sizeof(line), "%s spawned at 0x%x", process->name, VORTEX_GUEST_TEXT_BASE);
        vortex_runtime_log(runtime, VORTEX_SEVERITY_INFO, line);
    }
    return (int32_t)slot;
}

size_t vortex_runtime_process_count(const vortex_runtime *runtime)
{
    if (runtime == NULL) {
        return 0u;
    }
    size_t count = 0u;
    for (size_t index = 0; index < VORTEX_RUNTIME_MAX_PROCESSES; index += 1u) {
        if (runtime->processes[index].state != VORTEX_PROCESS_UNUSED) {
            count += 1u;
        }
    }
    return count;
}

bool vortex_runtime_process_at(const vortex_runtime *runtime, size_t index, vortex_runtime_process *out)
{
    if (runtime == NULL || out == NULL || index >= VORTEX_RUNTIME_MAX_PROCESSES) {
        return false;
    }
    const vortex_runtime_process *process = &runtime->processes[index];
    if (process->state == VORTEX_PROCESS_UNUSED) {
        return false;
    }
    *out = *process;
    return true;
}

int32_t vortex_runtime_find(const vortex_runtime *runtime, const char *name)
{
    if (runtime == NULL || name == NULL) {
        return -1;
    }
    for (size_t index = 0; index < VORTEX_RUNTIME_MAX_PROCESSES; index += 1u) {
        if (runtime->processes[index].state != VORTEX_PROCESS_UNUSED &&
            strcmp(runtime->processes[index].name, name) == 0) {
            return (int32_t)index;
        }
    }
    return -1;
}

// MARK: - Scheduling

static void vortex_runtime_save_context(vortex_runtime *runtime, vortex_runtime_process *process)
{
    for (uint32_t index = 0; index < 31u; index += 1u) {
        process->x[index] = vortex_cpu_read_register(runtime->cpu, index);
    }
    process->sp = vortex_cpu_read_register(runtime->cpu, 31u);
    process->nzcv = vortex_cpu_get_nzcv(runtime->cpu);
    process->pc = vortex_cpu_get_pc(runtime->cpu);
}

static void vortex_runtime_load_context(vortex_runtime *runtime, const vortex_runtime_process *process)
{
    for (uint32_t index = 0; index < 31u; index += 1u) {
        vortex_cpu_write_register(runtime->cpu, index, process->x[index]);
    }
    vortex_cpu_write_register(runtime->cpu, 31u, process->sp);
    vortex_cpu_set_nzcv(runtime->cpu, process->nzcv);
    vortex_cpu_set_pc(runtime->cpu, process->pc);
    vortex_cpu_clear_last_error(runtime->cpu);
}

static void vortex_runtime_trap(vortex_runtime *runtime,
                                vortex_runtime_process *process,
                                uint32_t syscall,
                                const char *diagnosis)
{
    process->state = VORTEX_PROCESS_TRAPPED;
    process->trap_syscall = syscall;
    process->exit_code = -1;
    snprintf(process->diagnosis, sizeof(process->diagnosis), "%s", diagnosis);
    char line[192];
    snprintf(line, sizeof(line), "[%s] trapped on syscall %u: %s\n", process->name, syscall, diagnosis);
    vortex_runtime_append_stdout(runtime, line, strlen(line));
    vortex_runtime_log(runtime, VORTEX_SEVERITY_ERROR, line);
}

/// Executes one supervisor call with the current process's context in the CPU.
static void vortex_runtime_dispatch(vortex_runtime *runtime,
                                    vortex_runtime_process *process,
                                    uint32_t syscall)
{
    runtime->syscall_count += 1u;
    process->ticks += 1u;

    uint64_t number = vortex_cpu_read_register(runtime->cpu, 8u);
    uint64_t argument0 = vortex_cpu_read_register(runtime->cpu, 0u);
    uint64_t argument1 = vortex_cpu_read_register(runtime->cpu, 1u);
    uint64_t argument2 = vortex_cpu_read_register(runtime->cpu, 2u);
    (void)syscall;

    switch ((uint32_t)number) {
        case VORTEX_SYSCALL_EXIT: {
            process->state = VORTEX_PROCESS_EXITED;
            process->exit_code = (int32_t)(uint32_t)argument0;
            vortex_cpu_write_register(runtime->cpu, 0u, 0u);
            char line[128];
            snprintf(line, sizeof(line), "%s exited with code %d", process->name, process->exit_code);
            vortex_runtime_log(runtime, VORTEX_SEVERITY_INFO, line);
            return;
        }

        case VORTEX_SYSCALL_YIELD:
            vortex_cpu_write_register(runtime->cpu, 0u, 0u);
            return;

        case VORTEX_SYSCALL_TICKS:
            vortex_cpu_write_register(runtime->cpu, 0u, process->ticks);
            return;

        case VORTEX_SYSCALL_STDOUT: {
            char text[192];
            if (!vortex_runtime_read_string(runtime, argument0, text, sizeof(text))) {
                vortex_runtime_trap(runtime, process, (uint32_t)number, "stdout pointer is outside guest memory");
                return;
            }
            vortex_runtime_append_stdout(runtime, text, strlen(text));
            vortex_cpu_write_register(runtime->cpu, 0u, (uint64_t)strlen(text));
            return;
        }

        case VORTEX_SYSCALL_OPEN: {
            char path[VORTEX_VFS_MAX_PATH];
            if (!vortex_runtime_read_string(runtime, argument0, path, sizeof(path))) {
                vortex_runtime_trap(runtime, process, (uint32_t)number, "open path is outside guest memory");
                return;
            }
            if (runtime->vfs == NULL) {
                vortex_runtime_trap(runtime, process, (uint32_t)number, "no virtual filesystem is mounted");
                return;
            }
            int32_t handle = vortex_vfs_open(runtime->vfs, path, (uint32_t)argument1);
            if (handle < 0) {
                vortex_cpu_write_register(runtime->cpu, 0u, (uint64_t)VORTEX_RUNTIME_NULL_HANDLE);
                return;
            }
            vortex_cpu_write_register(runtime->cpu, 0u, (uint64_t)(uint32_t)handle);
            return;
        }

        case VORTEX_SYSCALL_READ: {
            if (runtime->vfs == NULL) {
                vortex_runtime_trap(runtime, process, (uint32_t)number, "no virtual filesystem is mounted");
                return;
            }
            uint8_t buffer[256];
            size_t wanted = (size_t)argument2;
            if (wanted > sizeof(buffer)) {
                wanted = sizeof(buffer);
            }
            size_t read = vortex_vfs_read(runtime->vfs, (int32_t)(uint32_t)argument0, buffer, wanted);
            if (read > 0u && !vortex_runtime_guest_write(runtime, argument1, buffer, read)) {
                vortex_runtime_trap(runtime, process, (uint32_t)number, "read destination is outside guest memory");
                return;
            }
            vortex_cpu_write_register(runtime->cpu, 0u, (uint64_t)read);
            return;
        }

        case VORTEX_SYSCALL_WRITE: {
            if (runtime->vfs == NULL) {
                vortex_runtime_trap(runtime, process, (uint32_t)number, "no virtual filesystem is mounted");
                return;
            }
            uint8_t buffer[256];
            size_t wanted = (size_t)argument2;
            if (wanted > sizeof(buffer)) {
                wanted = sizeof(buffer);
            }
            if (wanted > 0u && !vortex_runtime_guest_read(runtime, argument1, buffer, wanted)) {
                vortex_runtime_trap(runtime, process, (uint32_t)number, "write source is outside guest memory");
                return;
            }
            size_t written = vortex_vfs_write(runtime->vfs, (int32_t)(uint32_t)argument0, buffer, wanted);
            vortex_cpu_write_register(runtime->cpu, 0u, (uint64_t)written);
            return;
        }

        case VORTEX_SYSCALL_CLOSE: {
            if (runtime->vfs == NULL) {
                vortex_runtime_trap(runtime, process, (uint32_t)number, "no virtual filesystem is mounted");
                return;
            }
            bool closed = vortex_vfs_close(runtime->vfs, (int32_t)(uint32_t)argument0);
            vortex_cpu_write_register(runtime->cpu, 0u, closed ? 0u : 1u);
            return;
        }

        case VORTEX_SYSCALL_FB_INFO: {
            vortex_runtime_guest_write(runtime, argument0, &(uint32_t){ VORTEX_GUEST_FRAMEBUFFER_WIDTH }, sizeof(uint32_t));
            vortex_runtime_guest_write(runtime, argument1, &(uint32_t){ VORTEX_GUEST_FRAMEBUFFER_HEIGHT }, sizeof(uint32_t));
            vortex_cpu_write_register(runtime->cpu, 0u, 0u);
            return;
        }

        case VORTEX_SYSCALL_FB_FLUSH:
            runtime->framebuffer_dirty = true;
            vortex_cpu_write_register(runtime->cpu, 0u, 0u);
            return;

        case VORTEX_SYSCALL_CLEAR: {
            uint32_t colour = (uint32_t)argument0;
            for (uint32_t y = 0; y < VORTEX_GUEST_FRAMEBUFFER_HEIGHT; y += 1u) {
                for (uint32_t x = 0; x < VORTEX_GUEST_FRAMEBUFFER_WIDTH; x += 1u) {
                    vortex_runtime_plot(runtime, x, y, colour);
                }
            }
            vortex_cpu_write_register(runtime->cpu, 0u, 0u);
            return;
        }

        case VORTEX_SYSCALL_PLOT:
            vortex_runtime_plot(runtime, (uint32_t)argument0, (uint32_t)argument1, (uint32_t)argument2);
            vortex_cpu_write_register(runtime->cpu, 0u, 0u);
            return;

        case VORTEX_SYSCALL_DRAWCHAR: {
            uint64_t colour = vortex_cpu_read_register(runtime->cpu, 3u);
            vortex_runtime_draw_char(runtime, (uint32_t)argument0, (uint32_t)argument1, (char)(uint32_t)argument2, (uint32_t)colour);
            vortex_cpu_write_register(runtime->cpu, 0u, 0u);
            return;
        }

        case VORTEX_SYSCALL_TEXTCLEAR:
            vortex_runtime_clear_stdout(runtime);
            vortex_cpu_write_register(runtime->cpu, 0u, 0u);
            return;

        default:
            vortex_runtime_trap(runtime, process, (uint32_t)number, "syscall number is not in the Vortex ABI");
            return;
    }
}

bool vortex_runtime_service_pending_syscall(vortex_runtime *runtime)
{
    if (runtime == NULL || runtime->cpu == NULL) {
        return false;
    }
    uint32_t immediate = 0;
    if (!vortex_cpu_take_syscall(runtime->cpu, &immediate)) {
        return false;
    }
    vortex_runtime_process *process = vortex_runtime_current(runtime);
    if (process == NULL) {
        /* A trap outside a running process means the CPU was stepped by hand:
           acknowledge it so the machine does not wedge. */
        vortex_cpu_write_register(runtime->cpu, 0u, 0u);
        return true;
    }
    vortex_runtime_dispatch(runtime, process, immediate);
    return true;
}

size_t vortex_runtime_slice_process(vortex_runtime *runtime, int32_t index)
{
    if (runtime == NULL || runtime->cpu == NULL) {
        return 0u;
    }
    if (index < 0 || index >= (int32_t)VORTEX_RUNTIME_MAX_PROCESSES) {
        return 0u;
    }
    vortex_runtime_process *process = &runtime->processes[index];
    if (process->state != VORTEX_PROCESS_READY && process->state != VORTEX_PROCESS_RUNNING) {
        return 0u;
    }

    runtime->current_process = (size_t)index;
    process->state = VORTEX_PROCESS_RUNNING;
    vortex_runtime_load_context(runtime, process);

    size_t executed = 0u;
    while (executed < runtime->slice_instructions) {
        size_t step = vortex_cpu_run(runtime->cpu, runtime->slice_instructions - executed);
        executed += step;

        if (vortex_cpu_take_syscall(runtime->cpu, NULL)) {
            vortex_runtime_dispatch(runtime, process, 0u);
            process->slices += 1u;
            if (process->state != VORTEX_PROCESS_RUNNING) {
                break;
            }
            continue;
        }

        if (step == 0u) {
            /* Halt, typed error, or a breakpoint set by the inspector. */
            if (process->state != VORTEX_PROCESS_EXITED) {
                uint32_t kind = 0;
                char message[160];
                if (vortex_cpu_copy_last_error(runtime->cpu, &kind, NULL, NULL, message, sizeof(message))) {
                    vortex_runtime_trap(runtime, process, 0xFFFFFFFFu, message);
                } else {
                    process->state = VORTEX_PROCESS_READY;
                }
            }
            break;
        }
    }

    vortex_runtime_save_context(runtime, process);
    if (process->state == VORTEX_PROCESS_RUNNING) {
        process->state = VORTEX_PROCESS_READY;
    }
    runtime->current_process = VORTEX_RUNTIME_MAX_PROCESSES;
    process->slices += 1u;
    return executed;
}

size_t vortex_runtime_run_slice(vortex_runtime *runtime)
{
    if (runtime == NULL) {
        return 0u;
    }
    for (size_t attempts = 0; attempts < VORTEX_RUNTIME_MAX_PROCESSES; attempts += 1u) {
        size_t index = (runtime->next_process + attempts) % VORTEX_RUNTIME_MAX_PROCESSES;
        vortex_runtime_process *process = &runtime->processes[index];
        if (process->state != VORTEX_PROCESS_READY) {
            continue;
        }
        runtime->next_process = (index + 1u) % VORTEX_RUNTIME_MAX_PROCESSES;
        return vortex_runtime_slice_process(runtime, (int32_t)index);
    }
    return 0u;
}

// MARK: - Output

size_t vortex_runtime_stdout(const vortex_runtime *runtime, char *out, size_t capacity)
{
    if (runtime == NULL || out == NULL || capacity == 0u) {
        return 0u;
    }
    size_t copied = runtime->stdout_length < capacity - 1u ? runtime->stdout_length : capacity - 1u;
    memcpy(out, runtime->stdout_buffer, copied);
    out[copied] = '\0';
    return copied;
}

void vortex_runtime_clear_stdout(vortex_runtime *runtime)
{
    if (runtime == NULL) {
        return;
    }
    runtime->stdout_length = 0u;
    runtime->stdout_buffer[0] = '\0';
}

bool vortex_runtime_take_framebuffer_dirty(vortex_runtime *runtime)
{
    if (runtime == NULL) {
        return false;
    }
    bool dirty = runtime->framebuffer_dirty;
    runtime->framebuffer_dirty = false;
    return dirty;
}

void vortex_runtime_copy_framebuffer(const vortex_runtime *runtime, void *out)
{
    if (runtime == NULL || out == NULL || runtime->framebuffer == NULL) {
        return;
    }
    memcpy(out, runtime->framebuffer, VORTEX_GUEST_FRAMEBUFFER_BYTES);
}

void vortex_runtime_clear_error(vortex_runtime *runtime)
{
    if (runtime != NULL) {
        runtime->error[0] = '\0';
    }
}

uint64_t vortex_runtime_syscall_count(const vortex_runtime *runtime)
{
    return runtime == NULL ? 0u : runtime->syscall_count;
}
