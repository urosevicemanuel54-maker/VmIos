//
//  vortex_guest_programs.c
//  Vortex
//
//  A tiny assembler for the sample guest images. Every instruction the samples
//  use is emitted through a named encoder, so a wrong bit position shows up as a
//  disassembly mismatch in the tests instead of as a mystery trap at runtime.
//

#include "vortex_guest_programs.h"

#include <string.h>

#include "vortex_cpu.h"
#include "vortex_runtime.h"

#define VORTEX_MAX_CODE_WORDS 256u
#define VORTEX_MAX_FIXUPS 24u
#define VORTEX_MAX_LABELS 16u
#define VORTEX_DATA_LABEL 0xFFFFu

typedef struct vortex_assembler {
    uint32_t code[VORTEX_MAX_CODE_WORDS];
    size_t count;
    size_t labels[VORTEX_MAX_LABELS];
    char label_defined[VORTEX_MAX_LABELS];

    struct {
        size_t at;
        uint16_t label;
        uint8_t cond;   /* 0xFF means unconditional */
        uint8_t kind;   /* 0 branch, 1 adr */
        uint8_t rd;
    } fixups[VORTEX_MAX_FIXUPS];
    size_t fixup_count;

    uint8_t data[512];
    size_t data_count;
    bool overflow;
} vortex_assembler;

// MARK: - Encoders

static uint32_t vx_movz(uint32_t rd, uint32_t imm16, uint32_t shift)
{
    return 0xD2800000u | ((shift & 0x3u) << 21) | ((imm16 & 0xFFFFu) << 5) | (rd & 0x1Fu);
}

static uint32_t vx_movk(uint32_t rd, uint32_t imm16, uint32_t shift)
{
    return 0xF2800000u | ((shift & 0x3u) << 21) | ((imm16 & 0xFFFFu) << 5) | (rd & 0x1Fu);
}

static uint32_t vx_add_imm(uint32_t rd, uint32_t rn, uint32_t imm12)
{
    return 0x91000000u | ((imm12 & 0xFFFu) << 10) | ((rn & 0x1Fu) << 5) | (rd & 0x1Fu);
}

static uint32_t vx_sub_imm(uint32_t rd, uint32_t rn, uint32_t imm12)
{
    return 0xD1000000u | ((imm12 & 0xFFFu) << 10) | ((rn & 0x1Fu) << 5) | (rd & 0x1Fu);
}

/// SUBS xzr, xn, #imm12 — the compare form the interpreter renders as `cmp`.
static uint32_t vx_cmp_imm(uint32_t rn, uint32_t imm12)
{
    return 0xF1000000u | ((imm12 & 0xFFFu) << 10) | ((rn & 0x1Fu) << 5) | 31u;
}

static uint32_t vx_cmp_reg(uint32_t rn, uint32_t rm)
{
    return 0xEB000000u | ((rm & 0x1Fu) << 16) | ((rn & 0x1Fu) << 5) | 31u;
}

static uint32_t vx_add_reg(uint32_t rd, uint32_t rn, uint32_t rm)
{
    return 0x8B000000u | ((rm & 0x1Fu) << 16) | ((rn & 0x1Fu) << 5) | (rd & 0x1Fu);
}

static uint32_t vx_madd(uint32_t rd, uint32_t rn, uint32_t rm, uint32_t ra)
{
    return 0x9B000000u | ((rm & 0x1Fu) << 16) | ((ra & 0x1Fu) << 10) | ((rn & 0x1Fu) << 5) | (rd & 0x1Fu);
}

static uint32_t vx_udiv(uint32_t rd, uint32_t rn, uint32_t rm)
{
    return 0x9AC00800u | ((rm & 0x1Fu) << 16) | ((rn & 0x1Fu) << 5) | (rd & 0x1Fu);
}

static uint32_t vx_lslv(uint32_t rd, uint32_t rn, uint32_t rm)
{
    return 0x9AC02000u | ((rm & 0x1Fu) << 16) | ((rn & 0x1Fu) << 5) | (rd & 0x1Fu);
}

static uint32_t vx_orr_reg(uint32_t rd, uint32_t rn, uint32_t rm)
{
    return 0xAA000000u | ((rm & 0x1Fu) << 16) | ((rn & 0x1Fu) << 5) | (rd & 0x1Fu);
}

/// ORR xd, xzr, xm — the register move.
static uint32_t vx_mov_reg(uint32_t rd, uint32_t rm)
{
    return vx_orr_reg(rd, 31u, rm);
}

static uint32_t vx_str_x(uint32_t rt, uint32_t rn, uint32_t byte_offset)
{
    return 0xF9000000u | (((byte_offset / 8u) & 0xFFFu) << 10) | ((rn & 0x1Fu) << 5) | (rt & 0x1Fu);
}

static uint32_t vx_ldr_x(uint32_t rt, uint32_t rn, uint32_t byte_offset)
{
    return 0xF9400000u | (((byte_offset / 8u) & 0xFFFu) << 10) | ((rn & 0x1Fu) << 5) | (rt & 0x1Fu);
}

static uint32_t vx_svc(uint32_t immediate)
{
    return 0xD4000001u | ((immediate & 0xFFFFu) << 5);
}

// MARK: - Builder

static void vx_fail(vortex_assembler *assembler)
{
    assembler->overflow = true;
}

static size_t vx_emit(vortex_assembler *assembler, uint32_t word)
{
    if (assembler->count >= VORTEX_MAX_CODE_WORDS) {
        vx_fail(assembler);
        return 0u;
    }
    assembler->code[assembler->count] = word;
    assembler->count += 1u;
    return assembler->count - 1u;
}

static void vx_label(vortex_assembler *assembler, uint16_t label)
{
    if (label >= VORTEX_MAX_LABELS) {
        vx_fail(assembler);
        return;
    }
    assembler->labels[label] = assembler->count;
    assembler->label_defined[label] = 1;
}

static void vx_add_fixup(vortex_assembler *assembler, size_t at, uint16_t label, uint8_t cond, uint8_t kind, uint8_t rd)
{
    if (assembler->fixup_count >= VORTEX_MAX_FIXUPS) {
        vx_fail(assembler);
        return;
    }
    assembler->fixups[assembler->fixup_count].at = at;
    assembler->fixups[assembler->fixup_count].label = label;
    assembler->fixups[assembler->fixup_count].cond = cond;
    assembler->fixups[assembler->fixup_count].kind = kind;
    assembler->fixups[assembler->fixup_count].rd = rd;
    assembler->fixup_count += 1u;
}

/// Emits a branch placeholder and records it for the second pass.
static void vx_branch(vortex_assembler *assembler, uint16_t label, uint8_t cond)
{
    size_t at = vx_emit(assembler, 0u);
    vx_add_fixup(assembler, at, label, cond, 0u, 0u);
}

/// Emits `adr xd, data` — resolved to the start of the read-only data block.
static void vx_adr_data(vortex_assembler *assembler, uint32_t rd)
{
    size_t at = vx_emit(assembler, 0u);
    vx_add_fixup(assembler, at, VORTEX_DATA_LABEL, 0u, 1u, (uint8_t)(rd & 0x1Fu));
}

static void vx_add_data(vortex_assembler *assembler, const char *text)
{
    size_t length = strlen(text);
    if (assembler->data_count + length + 1u > sizeof(assembler->data)) {
        vx_fail(assembler);
        return;
    }
    memcpy(assembler->data + assembler->data_count, text, length + 1u);
    assembler->data_count += length + 1u;
}

/// A 64-bit immediate as MOVZ plus as many MOVKs as it needs.
static void vx_load_u64(vortex_assembler *assembler, uint32_t rd, uint64_t value)
{
    bool emitted = false;
    for (uint32_t shift = 0; shift < 4u; shift += 1u) {
        uint32_t halfword = (uint32_t)((value >> (shift * 16u)) & 0xFFFFu);
        if (halfword == 0u) {
            continue;
        }
        if (!emitted) {
            vx_emit(assembler, vx_movz(rd, halfword, shift));
            emitted = true;
        } else {
            vx_emit(assembler, vx_movk(rd, halfword, shift));
        }
    }
    if (!emitted) {
        vx_emit(assembler, vx_movz(rd, 0u, 0u));
    }
}

static bool vx_resolve(vortex_assembler *assembler)
{
    if (assembler->overflow) {
        return false;
    }

    /* The data block starts after the last instruction, rounded up to a word
       boundary, so an ADR offset is stable once assembly has finished. */
    size_t data_word = assembler->count;
    size_t data_byte_offset = data_word * 4u;

    for (size_t index = 0; index < assembler->fixup_count; index += 1u) {
        size_t at = assembler->fixups[index].at;
        uint16_t label = assembler->fixups[index].label;

        if (assembler->fixups[index].kind == 1u) {
            int64_t byte_delta = (int64_t)data_byte_offset - (int64_t)(at * 4u);
            if (byte_delta < -(1 << 20) || byte_delta > (1 << 20)) {
                return false;
            }
            uint32_t immlo = (uint32_t)((byte_delta >> 0) & 0x3);
            uint32_t immhi = (uint32_t)((byte_delta >> 2) & 0x7FFFF);
            assembler->code[at] = 0x10000000u | (immlo << 29) | (immhi << 5) | (assembler->fixups[index].rd & 0x1Fu);
            continue;
        }

        if (label >= VORTEX_MAX_LABELS || !assembler->label_defined[label]) {
            return false;
        }
        int64_t word_delta = (int64_t)assembler->labels[label] - (int64_t)at;
        uint8_t cond = assembler->fixups[index].cond;

        if (cond == 0xFFu) {
            if (word_delta < -(1 << 25) || word_delta >= (1 << 25)) {
                return false;
            }
            assembler->code[at] = 0x14000000u | ((uint32_t)word_delta & 0x3FFFFFFu);
        } else {
            if (word_delta < -(1 << 18) || word_delta >= (1 << 18)) {
                return false;
            }
            assembler->code[at] = 0x54000000u | (((uint32_t)word_delta & 0x7FFFFu) << 5) | (cond & 0xFu);
        }
    }
    return true;
}

// MARK: - Programs

/// Sums the squares of 1..20000, writes the total to VORTEX_GUEST_RESULT_ADDRESS,
/// prints a line and exits cleanly.
static void vx_build_benchmark(vortex_assembler *assembler)
{
    vx_label(assembler, 0);           /* loop */
    vx_emit(assembler, vx_movz(0u, 0u, 0u));            /* mov x0, #0        */
    vx_emit(assembler, vx_movz(1u, 1u, 0u));            /* mov x1, #1        */
    /* The loop exits when x1 reaches the bound, so the bound is one past the
       last term: with 20000 the total would be one square short. */
    vx_emit(assembler, vx_movz(2u, 20001u, 0u));        /* movz x2, #20001   */

    /* Start of the loop body. */
    vx_label(assembler, 1);
    vx_emit(assembler, vx_madd(0u, 1u, 1u, 0u));        /* madd x0, x1, x1, x0 */
    vx_emit(assembler, vx_add_imm(1u, 1u, 1u));         /* add x1, x1, #1      */
    vx_emit(assembler, vx_cmp_reg(1u, 2u));             /* cmp x1, x2          */
    vx_branch(assembler, 1u, 0xBu);                     /* b.lt loop body      */

    /* Store the result where the host can read it. */
    vx_emit(assembler, vx_movz(3u, (VORTEX_GUEST_RESULT_ADDRESS >> 16) & 0xFFFFu, 1u));
    vx_emit(assembler, vx_movk(3u, VORTEX_GUEST_RESULT_ADDRESS & 0xFFFFu, 0u));
    vx_emit(assembler, vx_str_x(0u, 3u, 0u));           /* str x0, [x3]        */

    /* stdout(message) */
    vx_emit(assembler, vx_movz(8u, VORTEX_SYSCALL_STDOUT, 0u));
    vx_adr_data(assembler, 0u);
    vx_emit(assembler, vx_svc(0u));

    /* exit(0) */
    vx_emit(assembler, vx_movz(8u, VORTEX_SYSCALL_EXIT, 0u));
    vx_emit(assembler, vx_movz(0u, 0u, 0u));
    vx_emit(assembler, vx_svc(0u));

    vx_label(assembler, 2);
    vx_branch(assembler, 2u, 0xFFu);                    /* b .                 */

    vx_add_data(assembler, "benchmark: sum of squares 1..20000 written to 0x8000\n");
}

/// Clears the frame buffer, then sweeps a coloured row down it forever, flushing
/// each row. Exercises the plot and flush syscalls and yields between frames.
static void vx_build_painter(vortex_assembler *assembler)
{
    /* x19 y, x20 background, x21 x, x22 shift source, x23 shift amount 8,
       x24 base colour, x25 colour. */
    vx_emit(assembler, vx_movz(19u, 0u, 0u));                       /* y = 0 */
    vx_emit(assembler, vx_movz(20u, 0x1828u, 0u));                  /* background low */
    vx_emit(assembler, vx_movk(20u, 0x0010u, 1u));                  /* += 0x00100000  */
    vx_emit(assembler, vx_movz(8u, VORTEX_SYSCALL_CLEAR, 0u));
    vx_emit(assembler, vx_mov_reg(0u, 20u));
    vx_emit(assembler, vx_svc(0u));

    vx_emit(assembler, vx_movz(23u, 8u, 0u));                       /* shift = 8 */
    vx_emit(assembler, vx_movz(24u, 0x4060u, 0u));                  /* base low  */
    vx_emit(assembler, vx_movk(24u, 0x0020u, 1u));                  /* 0x00204060 */

    vx_label(assembler, 0);                                         /* frame */
    vx_emit(assembler, vx_movz(21u, 0u, 0u));                       /* x = 0 */

    vx_label(assembler, 1);                                         /* row */
    vx_emit(assembler, vx_lslv(22u, 21u, 23u));                     /* x << 8 */
    vx_emit(assembler, vx_add_reg(25u, 22u, 24u));                  /* colour */
    vx_emit(assembler, vx_movz(8u, VORTEX_SYSCALL_PLOT, 0u));
    vx_emit(assembler, vx_mov_reg(0u, 21u));
    vx_emit(assembler, vx_mov_reg(1u, 19u));
    vx_emit(assembler, vx_mov_reg(2u, 25u));
    vx_emit(assembler, vx_svc(0u));

    vx_emit(assembler, vx_add_imm(21u, 21u, 1u));
    vx_emit(assembler, vx_cmp_imm(21u, VORTEX_GUEST_FRAMEBUFFER_WIDTH));
    vx_branch(assembler, 1u, 0xBu);                                 /* b.lt row */

    vx_emit(assembler, vx_movz(8u, VORTEX_SYSCALL_FB_FLUSH, 0u));
    vx_emit(assembler, vx_svc(0u));

    vx_emit(assembler, vx_add_imm(19u, 19u, 1u));                   /* y += 1 */
    vx_emit(assembler, vx_cmp_imm(19u, VORTEX_GUEST_FRAMEBUFFER_HEIGHT));
    vx_branch(assembler, 2u, 0xBu);                                 /* b.lt next */
    vx_emit(assembler, vx_movz(19u, 0u, 0u));                       /* wrap y = 0 */

    vx_label(assembler, 2);                                         /* next */
    vx_emit(assembler, vx_movz(8u, VORTEX_SYSCALL_YIELD, 0u));
    vx_emit(assembler, vx_svc(0u));
    vx_branch(assembler, 0u, 0xFFu);                                /* b frame */
}

// MARK: - Public

const char *vortex_guest_program_name(vortex_guest_program program)
{
    switch (program) {
        case VORTEX_GUEST_PROGRAM_BENCHMARK: return "benchmark";
        case VORTEX_GUEST_PROGRAM_PAINTER: return "painter";
        default: return "guest";
    }
}

/// Both builders refuse to overflow the code array, so this can be computed by
/// formatting each program once and reporting the instruction count.
static size_t vx_count_words(vortex_guest_program program)
{
    vortex_assembler assembler;
    memset(&assembler, 0, sizeof(assembler));
    switch (program) {
        case VORTEX_GUEST_PROGRAM_BENCHMARK: vx_build_benchmark(&assembler); break;
        case VORTEX_GUEST_PROGRAM_PAINTER: vx_build_painter(&assembler); break;
        default: return 0u;
    }
    return assembler.count;
}

size_t vortex_guest_code_size(vortex_guest_program program)
{
    return vx_count_words(program) * 4u;
}

size_t vortex_guest_build_image(vortex_guest_program program, uint8_t *out, size_t capacity)
{
    if (out == NULL || capacity == 0u) {
        return 0u;
    }

    vortex_assembler assembler;
    memset(&assembler, 0, sizeof(assembler));

    switch (program) {
        case VORTEX_GUEST_PROGRAM_BENCHMARK:
            vx_build_benchmark(&assembler);
            break;
        case VORTEX_GUEST_PROGRAM_PAINTER:
            vx_build_painter(&assembler);
            break;
        default:
            return 0u;
    }

    if (!vx_resolve(&assembler)) {
        return 0u;
    }

    size_t code_bytes = assembler.count * 4u;
    /* The data block follows the code and both must be a whole number of
       instructions, so the last instruction is never a truncated word. */
    size_t total = code_bytes + assembler.data_count;
    size_t padded = (total + 3u) & ~(size_t)3u;
    if (padded > capacity) {
        return 0u;
    }

    memset(out, 0, padded);
    memcpy(out, assembler.code, code_bytes);
    if (assembler.data_count > 0u) {
        memcpy(out + code_bytes, assembler.data, assembler.data_count);
    }
    return padded;
}
