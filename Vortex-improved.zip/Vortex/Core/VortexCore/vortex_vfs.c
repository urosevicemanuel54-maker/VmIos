//
//  vortex_vfs.c
//  Vortex
//
//  Implementation of the virtual filesystem. Nodes are absolute POSIX-like
//  paths; the parent of a node always precedes it in the array, which lets the
//  container format validate a tree by walking forward once.
//

#include "vortex_vfs.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct vortex_vfs_node {
    uint32_t type;
    char path[VORTEX_VFS_MAX_PATH];
    size_t size;
    size_t capacity;
    uint8_t *data;
} vortex_vfs_node;

typedef struct vortex_vfs_handle {
    bool open;
    uint32_t node;
    size_t offset;
    uint32_t flags;
} vortex_vfs_handle;

struct vortex_vfs {
    vortex_vfs_node nodes[VORTEX_VFS_MAX_NODES];
    size_t node_count;
    vortex_vfs_handle handles[VORTEX_VFS_MAX_HANDLES];
    char error[160];
};

// MARK: - Errors

static void vortex_vfs_set_error(vortex_vfs *vfs, const char *message)
{
    if (vfs == NULL) {
        return;
    }
    snprintf(vfs->error, sizeof(vfs->error), "%s", message ? message : "");
}

const char *vortex_vfs_last_error(const vortex_vfs *vfs)
{
    return vfs == NULL ? "" : vfs->error;
}

void vortex_vfs_clear_error(vortex_vfs *vfs)
{
    if (vfs != NULL) {
        vfs->error[0] = '\0';
    }
}

// MARK: - Paths

bool vortex_vfs_normalise(const char *input, char *out, size_t capacity)
{
    if (input == NULL || out == NULL || capacity < 2u) {
        return false;
    }
    if (input[0] != '/') {
        return false;
    }

    char temp[VORTEX_VFS_MAX_PATH];
    size_t length = 0;
    temp[length++] = '/';

    const char *cursor = input;
    while (*cursor != '\0') {
        while (*cursor == '/') {
            cursor += 1;
        }
        if (*cursor == '\0') {
            break;
        }
        const char *start = cursor;
        while (*cursor != '\0' && *cursor != '/') {
            cursor += 1;
        }
        size_t component = (size_t)(cursor - start);

        if (component == 0u) {
            continue;
        }
        if (component == 1u && start[0] == '.') {
            continue;
        }
        if (component == 2u && start[0] == '.' && start[1] == '.') {
            /* Ascending is refused rather than clamped: a guest cannot escape
               its own tree, and pretending "/a/.." is "/" would hide a bug. */
            return false;
        }
        if (component > VORTEX_VFS_MAX_COMPONENT) {
            return false;
        }
        if (length > 1u) {
            if (length + 1u >= sizeof(temp)) {
                return false;
            }
            temp[length++] = '/';
        }
        if (length + component >= sizeof(temp)) {
            return false;
        }
        memcpy(temp + length, start, component);
        length += component;
    }

    temp[length] = '\0';
    if (length + 1u > capacity) {
        return false;
    }
    memcpy(out, temp, length + 1u);
    return true;
}

/// Parent of an absolute normalised path. Root has no parent.
static bool vortex_vfs_parent_path(const char *path, char *out, size_t capacity)
{
    size_t length = strlen(path);
    if (length <= 1u) {
        return false;
    }
    /* Walk back over the last component to the separator before it. */
    while (length > 0u && path[length - 1u] != '/') {
        length -= 1u;
    }
    if (length <= 1u) {
        /* "/Apps" is directly under the root. */
        if (capacity < 2u) {
            return false;
        }
        out[0] = '/';
        out[1] = '\0';
        return true;
    }
    /* Drop the trailing separator so the parent of "/A/b" is "/A". */
    length -= 1u;
    if (length + 1u > capacity) {
        return false;
    }
    memcpy(out, path, length);
    out[length] = '\0';
    return true;
}

static int32_t vortex_vfs_find(const vortex_vfs *vfs, const char *path)
{
    for (size_t index = 0; index < vfs->node_count; index += 1u) {
        if (strcmp(vfs->nodes[index].path, path) == 0) {
            return (int32_t)index;
        }
    }
    return -1;
}

// MARK: - Lifecycle

static void vortex_vfs_clear_handles(vortex_vfs *vfs)
{
    memset(vfs->handles, 0, sizeof(vfs->handles));
}

static void vortex_vfs_clear(vortex_vfs *vfs)
{
    for (size_t index = 0; index < vfs->node_count; index += 1u) {
        free(vfs->nodes[index].data);
        vfs->nodes[index].data = NULL;
    }
    memset(vfs->nodes, 0, sizeof(vfs->nodes));
    vfs->node_count = 0;
    vortex_vfs_clear_handles(vfs);
}

vortex_vfs *vortex_vfs_create(void)
{
    vortex_vfs *vfs = (vortex_vfs *)calloc(1, sizeof(*vfs));
    if (vfs == NULL) {
        return NULL;
    }
    vortex_vfs_reset(vfs);
    return vfs;
}

void vortex_vfs_destroy(vortex_vfs *vfs)
{
    if (vfs == NULL) {
        return;
    }
    vortex_vfs_clear(vfs);
    free(vfs);
}

void vortex_vfs_reset(vortex_vfs *vfs)
{
    if (vfs == NULL) {
        return;
    }
    vortex_vfs_clear(vfs);
    vfs->nodes[0].type = VORTEX_VFS_TYPE_DIRECTORY;
    snprintf(vfs->nodes[0].path, sizeof(vfs->nodes[0].path), "/");
    vfs->nodes[0].size = 0;
    vfs->nodes[0].capacity = 0;
    vfs->nodes[0].data = NULL;
    vfs->node_count = 1;
    vortex_vfs_clear_error(vfs);
}

// MARK: - Mutation

bool vortex_vfs_mkdir(vortex_vfs *vfs, const char *path)
{
    if (vfs == NULL) {
        return false;
    }
    vortex_vfs_clear_error(vfs);

    char normalised[VORTEX_VFS_MAX_PATH];
    if (!vortex_vfs_normalise(path, normalised, sizeof(normalised))) {
        vortex_vfs_set_error(vfs, "path must be absolute, relative to the root, and free of '..'");
        return false;
    }
    if (vortex_vfs_find(vfs, normalised) >= 0) {
        vortex_vfs_set_error(vfs, "path already exists");
        return false;
    }

    char parent[VORTEX_VFS_MAX_PATH];
    if (!vortex_vfs_parent_path(normalised, parent, sizeof(parent))) {
        vortex_vfs_set_error(vfs, "root already exists");
        return false;
    }
    int32_t parent_index = vortex_vfs_find(vfs, parent);
    if (parent_index < 0) {
        vortex_vfs_set_error(vfs, "parent directory does not exist");
        return false;
    }
    if (vfs->nodes[parent_index].type != VORTEX_VFS_TYPE_DIRECTORY) {
        vortex_vfs_set_error(vfs, "parent is not a directory");
        return false;
    }
    if (vfs->node_count >= VORTEX_VFS_MAX_NODES) {
        vortex_vfs_set_error(vfs, "filesystem is full");
        return false;
    }

    vortex_vfs_node *node = &vfs->nodes[vfs->node_count];
    memset(node, 0, sizeof(*node));
    node->type = VORTEX_VFS_TYPE_DIRECTORY;
    snprintf(node->path, sizeof(node->path), "%s", normalised);
    vfs->node_count += 1u;
    return true;
}

static bool vortex_vfs_store(vortex_vfs *vfs, vortex_vfs_node *node, const void *bytes, size_t size)
{
    if (size > VORTEX_VFS_MAX_FILE_BYTES) {
        vortex_vfs_set_error(vfs, "file is larger than the virtual filesystem allows");
        return false;
    }
    if (size > node->capacity) {
        uint8_t *grown = (uint8_t *)realloc(node->data, size == 0u ? 1u : size);
        if (grown == NULL) {
            vortex_vfs_set_error(vfs, "out of memory growing a file");
            return false;
        }
        node->data = grown;
        node->capacity = size;
    }
    if (size > 0u && bytes != NULL) {
        memcpy(node->data, bytes, size);
    }
    node->size = size;
    return true;
}

bool vortex_vfs_write_file(vortex_vfs *vfs, const char *path, const void *bytes, size_t size)
{
    if (vfs == NULL) {
        return false;
    }
    vortex_vfs_clear_error(vfs);

    char normalised[VORTEX_VFS_MAX_PATH];
    if (!vortex_vfs_normalise(path, normalised, sizeof(normalised))) {
        vortex_vfs_set_error(vfs, "path must be absolute, relative to the root, and free of '..'");
        return false;
    }

    int32_t existing = vortex_vfs_find(vfs, normalised);
    if (existing >= 0) {
        vortex_vfs_node *node = &vfs->nodes[existing];
        if (node->type == VORTEX_VFS_TYPE_DIRECTORY) {
            vortex_vfs_set_error(vfs, "path is a directory");
            return false;
        }
        return vortex_vfs_store(vfs, node, bytes, size);
    }

    char parent[VORTEX_VFS_MAX_PATH];
    if (!vortex_vfs_parent_path(normalised, parent, sizeof(parent))) {
        vortex_vfs_set_error(vfs, "cannot replace the root directory");
        return false;
    }
    int32_t parent_index = vortex_vfs_find(vfs, parent);
    if (parent_index < 0) {
        vortex_vfs_set_error(vfs, "parent directory does not exist");
        return false;
    }
    if (vfs->nodes[parent_index].type != VORTEX_VFS_TYPE_DIRECTORY) {
        vortex_vfs_set_error(vfs, "parent is not a directory");
        return false;
    }
    if (vfs->node_count >= VORTEX_VFS_MAX_NODES) {
        vortex_vfs_set_error(vfs, "filesystem is full");
        return false;
    }

    vortex_vfs_node *node = &vfs->nodes[vfs->node_count];
    memset(node, 0, sizeof(*node));
    node->type = VORTEX_VFS_TYPE_FILE;
    snprintf(node->path, sizeof(node->path), "%s", normalised);
    if (!vortex_vfs_store(vfs, node, bytes, size)) {
        memset(node, 0, sizeof(*node));
        return false;
    }
    vfs->node_count += 1u;
    return true;
}

size_t vortex_vfs_read_file(const vortex_vfs *vfs, const char *path, void *out, size_t capacity)
{
    if (vfs == NULL || out == NULL) {
        return 0u;
    }
    char normalised[VORTEX_VFS_MAX_PATH];
    if (!vortex_vfs_normalise(path, normalised, sizeof(normalised))) {
        return 0u;
    }
    int32_t index = vortex_vfs_find(vfs, normalised);
    if (index < 0) {
        return 0u;
    }
    const vortex_vfs_node *node = &vfs->nodes[index];
    if (node->type != VORTEX_VFS_TYPE_FILE) {
        return 0u;
    }
    size_t copied = node->size < capacity ? node->size : capacity;
    if (copied > 0u && node->data != NULL) {
        memcpy(out, node->data, copied);
    }
    return copied;
}

bool vortex_vfs_remove(vortex_vfs *vfs, const char *path)
{
    if (vfs == NULL) {
        return false;
    }
    vortex_vfs_clear_error(vfs);

    char normalised[VORTEX_VFS_MAX_PATH];
    if (!vortex_vfs_normalise(path, normalised, sizeof(normalised))) {
        vortex_vfs_set_error(vfs, "path must be absolute");
        return false;
    }
    if (strcmp(normalised, "/") == 0) {
        vortex_vfs_set_error(vfs, "the root directory cannot be removed");
        return false;
    }

    int32_t index = vortex_vfs_find(vfs, normalised);
    if (index < 0) {
        vortex_vfs_set_error(vfs, "path does not exist");
        return false;
    }

    if (vfs->nodes[index].type == VORTEX_VFS_TYPE_DIRECTORY) {
        char prefix[VORTEX_VFS_MAX_PATH];
        snprintf(prefix, sizeof(prefix), "%s/", normalised);
        for (size_t other = 0; other < vfs->node_count; other += 1u) {
            if (other != (size_t)index && strncmp(vfs->nodes[other].path, prefix, strlen(prefix)) == 0) {
                vortex_vfs_set_error(vfs, "directory is not empty");
                return false;
            }
        }
    }

    /* Any handle on the removed node, or on a node that shifts down, is
       maintained here so the guest cannot read freed storage. */
    for (size_t handle = 0; handle < VORTEX_VFS_MAX_HANDLES; handle += 1u) {
        if (!vfs->handles[handle].open) {
            continue;
        }
        if ((int32_t)vfs->handles[handle].node == index) {
            vfs->handles[handle].open = false;
        } else if ((int32_t)vfs->handles[handle].node > index) {
            vfs->handles[handle].node -= 1u;
        }
    }

    free(vfs->nodes[index].data);
    for (size_t move = (size_t)index; move + 1u < vfs->node_count; move += 1u) {
        vfs->nodes[move] = vfs->nodes[move + 1u];
    }
    vfs->node_count -= 1u;
    memset(&vfs->nodes[vfs->node_count], 0, sizeof(vortex_vfs_node));
    return true;
}

// MARK: - Handles

int32_t vortex_vfs_open(vortex_vfs *vfs, const char *path, uint32_t flags)
{
    if (vfs == NULL) {
        return -1;
    }
    vortex_vfs_clear_error(vfs);

    char normalised[VORTEX_VFS_MAX_PATH];
    if (!vortex_vfs_normalise(path, normalised, sizeof(normalised))) {
        vortex_vfs_set_error(vfs, "path must be absolute");
        return -1;
    }

    int32_t index = vortex_vfs_find(vfs, normalised);
    if (index < 0) {
        if ((flags & VORTEX_VFS_OPEN_CREATE) == 0u) {
            vortex_vfs_set_error(vfs, "file does not exist");
            return -1;
        }
        if (!vortex_vfs_write_file(vfs, normalised, NULL, 0u)) {
            return -1;
        }
        index = vortex_vfs_find(vfs, normalised);
        if (index < 0) {
            vortex_vfs_set_error(vfs, "file could not be created");
            return -1;
        }
    }

    if (vfs->nodes[index].type != VORTEX_VFS_TYPE_FILE) {
        vortex_vfs_set_error(vfs, "path is a directory");
        return -1;
    }

    for (int32_t slot = 0; slot < (int32_t)VORTEX_VFS_MAX_HANDLES; slot += 1) {
        if (vfs->handles[slot].open) {
            continue;
        }
        vfs->handles[slot].open = true;
        vfs->handles[slot].node = (uint32_t)index;
        vfs->handles[slot].offset = 0u;
        vfs->handles[slot].flags = flags;
        return slot;
    }

    vortex_vfs_set_error(vfs, "too many open files");
    return -1;
}

static vortex_vfs_handle *vortex_vfs_handle_at(vortex_vfs *vfs, int32_t handle)
{
    if (handle < 0 || handle >= (int32_t)VORTEX_VFS_MAX_HANDLES) {
        return NULL;
    }
    return vfs->handles[handle].open ? &vfs->handles[handle] : NULL;
}

size_t vortex_vfs_read(vortex_vfs *vfs, int32_t handle, void *out, size_t size)
{
    if (vfs == NULL || out == NULL) {
        return 0u;
    }
    vortex_vfs_handle *entry = vortex_vfs_handle_at(vfs, handle);
    if (entry == NULL || entry->node >= vfs->node_count) {
        return 0u;
    }
    vortex_vfs_node *node = &vfs->nodes[entry->node];
    if (node->type != VORTEX_VFS_TYPE_FILE || entry->offset >= node->size) {
        return 0u;
    }
    size_t available = node->size - entry->offset;
    size_t copied = available < size ? available : size;
    memcpy(out, node->data + entry->offset, copied);
    entry->offset += copied;
    return copied;
}

size_t vortex_vfs_write(vortex_vfs *vfs, int32_t handle, const void *bytes, size_t size)
{
    if (vfs == NULL || bytes == NULL) {
        return 0u;
    }
    vortex_vfs_handle *entry = vortex_vfs_handle_at(vfs, handle);
    if (entry == NULL || entry->node >= vfs->node_count) {
        return 0u;
    }
    vortex_vfs_node *node = &vfs->nodes[entry->node];
    if (node->type != VORTEX_VFS_TYPE_FILE || (entry->flags & VORTEX_VFS_OPEN_WRITE) == 0u) {
        vortex_vfs_set_error(vfs, "handle is not open for writing");
        return 0u;
    }
    if (entry->offset + size > VORTEX_VFS_MAX_FILE_BYTES) {
        vortex_vfs_set_error(vfs, "write would exceed the maximum file size");
        return 0u;
    }

    size_t needed = entry->offset + size;
    if (needed > node->capacity) {
        uint8_t *grown = (uint8_t *)realloc(node->data, needed);
        if (grown == NULL) {
            vortex_vfs_set_error(vfs, "out of memory growing a file");
            return 0u;
        }
        node->data = grown;
        node->capacity = needed;
    }
    memcpy(node->data + entry->offset, bytes, size);
    entry->offset += size;
    if (entry->offset > node->size) {
        node->size = entry->offset;
    }
    return size;
}

bool vortex_vfs_close(vortex_vfs *vfs, int32_t handle)
{
    vortex_vfs_handle *entry = vfs == NULL ? NULL : vortex_vfs_handle_at(vfs, handle);
    if (entry == NULL) {
        return false;
    }
    entry->open = false;
    entry->offset = 0u;
    return true;
}

bool vortex_vfs_seek(vortex_vfs *vfs, int32_t handle, size_t offset)
{
    vortex_vfs_handle *entry = vfs == NULL ? NULL : vortex_vfs_handle_at(vfs, handle);
    if (entry == NULL || entry->node >= vfs->node_count) {
        return false;
    }
    if (offset > vfs->nodes[entry->node].size && offset > VORTEX_VFS_MAX_FILE_BYTES) {
        return false;
    }
    entry->offset = offset;
    return true;
}

// MARK: - Inspection

bool vortex_vfs_stat_path(const vortex_vfs *vfs, const char *path, vortex_vfs_stat *out)
{
    if (vfs == NULL || out == NULL) {
        return false;
    }
    char normalised[VORTEX_VFS_MAX_PATH];
    if (!vortex_vfs_normalise(path, normalised, sizeof(normalised))) {
        return false;
    }
    int32_t index = vortex_vfs_find(vfs, normalised);
    if (index < 0) {
        return false;
    }
    const vortex_vfs_node *node = &vfs->nodes[index];
    memset(out, 0, sizeof(*out));
    snprintf(out->path, sizeof(out->path), "%s", node->path);
    out->type = node->type;
    out->size = node->type == VORTEX_VFS_TYPE_FILE ? (uint64_t)node->size : 0u;
    return true;
}

bool vortex_vfs_exists(const vortex_vfs *vfs, const char *path)
{
    vortex_vfs_stat ignored;
    return vortex_vfs_stat_path(vfs, path, &ignored);
}

size_t vortex_vfs_node_count(const vortex_vfs *vfs)
{
    return vfs == NULL ? 0u : vfs->node_count;
}

bool vortex_vfs_node_at(const vortex_vfs *vfs, size_t index, vortex_vfs_stat *out)
{
    if (vfs == NULL || out == NULL || index >= vfs->node_count) {
        return false;
    }
    const vortex_vfs_node *node = &vfs->nodes[index];
    memset(out, 0, sizeof(*out));
    snprintf(out->path, sizeof(out->path), "%s", node->path);
    out->type = node->type;
    out->size = node->type == VORTEX_VFS_TYPE_FILE ? (uint64_t)node->size : 0u;
    return true;
}

// MARK: - Container

static bool vortex_vfs_write_u32(FILE *file, uint32_t value)
{
    return fwrite(&value, sizeof(value), 1u, file) == 1u;
}

static bool vortex_vfs_write_u64(FILE *file, uint64_t value)
{
    return fwrite(&value, sizeof(value), 1u, file) == 1u;
}

bool vortex_vfs_save(vortex_vfs *vfs, const char *container_path)
{
    if (vfs == NULL || container_path == NULL) {
        return false;
    }
    vortex_vfs_clear_error(vfs);

    char temporary[1024];
    if (snprintf(temporary, sizeof(temporary), "%s.tmp", container_path) >= (int)sizeof(temporary)) {
        vortex_vfs_set_error(vfs, "container path is too long");
        return false;
    }

    FILE *file = fopen(temporary, "wb");
    if (file == NULL) {
        vortex_vfs_set_error(vfs, "container file could not be opened for writing");
        return false;
    }

    bool ok = vortex_vfs_write_u32(file, VORTEX_VFS_CONTAINER_MAGIC) &&
              vortex_vfs_write_u32(file, VORTEX_VFS_CONTAINER_VERSION) &&
              vortex_vfs_write_u32(file, (uint32_t)vfs->node_count) &&
              vortex_vfs_write_u32(file, 0u);

    for (size_t index = 0; ok && index < vfs->node_count; index += 1u) {
        const vortex_vfs_node *node = &vfs->nodes[index];
        uint32_t path_length = (uint32_t)strlen(node->path);
        ok = vortex_vfs_write_u32(file, node->type) &&
             vortex_vfs_write_u32(file, path_length) &&
             vortex_vfs_write_u64(file, (uint64_t)node->size);
        if (!ok) {
            break;
        }
        if (path_length > 0u && fwrite(node->path, 1u, path_length, file) != path_length) {
            ok = false;
            break;
        }
        if (node->type == VORTEX_VFS_TYPE_FILE && node->size > 0u) {
            if (fwrite(node->data, 1u, node->size, file) != node->size) {
                ok = false;
                break;
            }
        }
    }

    if (fclose(file) != 0) {
        ok = false;
    }
    if (!ok) {
        remove(temporary);
        vortex_vfs_set_error(vfs, "container file could not be written");
        return false;
    }
    if (rename(temporary, container_path) != 0) {
        remove(temporary);
        vortex_vfs_set_error(vfs, "container file could not be replaced");
        return false;
    }
    return true;
}

static bool vortex_vfs_read_u32(FILE *file, uint32_t *value)
{
    return fread(value, sizeof(*value), 1u, file) == 1u;
}

static bool vortex_vfs_read_u64(FILE *file, uint64_t *value)
{
    return fread(value, sizeof(*value), 1u, file) == 1u;
}

bool vortex_vfs_load(vortex_vfs *vfs, const char *container_path)
{
    if (vfs == NULL || container_path == NULL) {
        return false;
    }
    vortex_vfs_clear_error(vfs);

    FILE *file = fopen(container_path, "rb");
    if (file == NULL) {
        vortex_vfs_set_error(vfs, "no container file to load");
        return false;
    }

    uint32_t magic = 0;
    uint32_t version = 0;
    uint32_t count = 0;
    uint32_t reserved = 0;
    if (!vortex_vfs_read_u32(file, &magic) || magic != VORTEX_VFS_CONTAINER_MAGIC) {
        fclose(file);
        vortex_vfs_set_error(vfs, "container has an unknown signature");
        return false;
    }
    if (!vortex_vfs_read_u32(file, &version) || version != VORTEX_VFS_CONTAINER_VERSION) {
        fclose(file);
        vortex_vfs_set_error(vfs, "container version is not supported");
        return false;
    }
    if (!vortex_vfs_read_u32(file, &count) || !vortex_vfs_read_u32(file, &reserved) ||
        count == 0u || count > VORTEX_VFS_MAX_NODES) {
        fclose(file);
        vortex_vfs_set_error(vfs, "container node count is invalid");
        return false;
    }

    vortex_vfs_clear(vfs);
    vfs->nodes[0].type = VORTEX_VFS_TYPE_DIRECTORY;
    snprintf(vfs->nodes[0].path, sizeof(vfs->nodes[0].path), "/");
    vfs->node_count = 1;

    bool ok = true;
    for (uint32_t index = 0; ok && index < count; index += 1u) {
        uint32_t type = 0;
        uint32_t path_length = 0;
        uint64_t size = 0;
        ok = vortex_vfs_read_u32(file, &type) &&
             vortex_vfs_read_u32(file, &path_length) &&
             vortex_vfs_read_u64(file, &size);
        if (!ok || path_length == 0u || path_length >= VORTEX_VFS_MAX_PATH ||
            (type != VORTEX_VFS_TYPE_FILE && type != VORTEX_VFS_TYPE_DIRECTORY) ||
            size > VORTEX_VFS_MAX_FILE_BYTES) {
            ok = false;
            break;
        }

        char raw_path[VORTEX_VFS_MAX_PATH];
        if (fread(raw_path, 1u, path_length, file) != path_length) {
            ok = false;
            break;
        }
        raw_path[path_length] = '\0';

        char normalised[VORTEX_VFS_MAX_PATH];
        if (!vortex_vfs_normalise(raw_path, normalised, sizeof(normalised)) ||
            strcmp(normalised, raw_path) != 0) {
            ok = false;
            break;
        }

        /* The root is written as part of the tree, so index 0 is expected to
           be "/" and every later node needs an existing parent. */
        if (index == 0u) {
            if (strcmp(normalised, "/") != 0 || type != VORTEX_VFS_TYPE_DIRECTORY) {
                ok = false;
                break;
            }
            if (size > 0u) {
                fseek(file, (long)size, SEEK_CUR);
            }
            continue;
        }

        char parent[VORTEX_VFS_MAX_PATH];
        if (!vortex_vfs_parent_path(normalised, parent, sizeof(parent)) ||
            vortex_vfs_find(vfs, parent) < 0) {
            ok = false;
            break;
        }

        vortex_vfs_node *node = &vfs->nodes[vfs->node_count];
        memset(node, 0, sizeof(*node));
        node->type = type;
        snprintf(node->path, sizeof(node->path), "%s", normalised);

        if (type == VORTEX_VFS_TYPE_FILE && size > 0u) {
            uint8_t *data = (uint8_t *)malloc((size_t)size);
            if (data == NULL || fread(data, 1u, (size_t)size, file) != (size_t)size) {
                free(data);
                ok = false;
                break;
            }
            node->data = data;
            node->size = (size_t)size;
            node->capacity = (size_t)size;
        }
        vfs->node_count += 1u;
    }

    fclose(file);

    if (!ok) {
        vortex_vfs_reset(vfs);
        vortex_vfs_set_error(vfs, "container is malformed; the filesystem was left empty");
        return false;
    }
    return true;
}
