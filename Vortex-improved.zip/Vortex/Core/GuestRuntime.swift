//
//  GuestRuntime.swift
//  Vortex
//
//  Swift surface for the guest runtime: the process table, a console reader and
//  the two sample programs the app ships.
//

import Foundation

enum VortexGuestProgram: UInt32, CaseIterable, Identifiable {
    case benchmark = 0
    case painter = 1

    var id: UInt32 { rawValue }

    /// The C enum value this case maps to.
    var cValue: vortex_guest_program {
        VORTEX_GUEST_PROGRAM_BENCHMARK.rawValue == rawValue ? VORTEX_GUEST_PROGRAM_BENCHMARK : VORTEX_GUEST_PROGRAM_PAINTER
    }

    var title: String {
        switch self {
        case .benchmark: return "Arithmetic benchmark"
        case .painter: return "Framebuffer painter"
        }
    }

    var name: String {
        switch self {
        case .benchmark: return "benchmark"
        case .painter: return "painter"
        }
    }

    var summary: String {
        switch self {
        case .benchmark:
            return "Sums the squares of 1 to 20000 in ARM64, writes the total to guest memory and exits. Prints one line to the console."
        case .painter:
            return "Paints the guest frame buffer one row per frame through the plot syscall, then yields. This is the program the display shows."
        }
    }

    var symbolName: String {
        switch self {
        case .benchmark: return "function"
        case .painter: return "paintbrush.pointed.fill"
        }
    }
}

struct GuestProcessInfo: Identifiable, Equatable {
    enum State: UInt32 {
        case unused = 0
        case ready = 1
        case running = 2
        case exited = 3
        case trapped = 4

        var label: String {
            switch self {
            case .unused: return "Unused"
            case .ready: return "Ready"
            case .running: return "Running"
            case .exited: return "Exited"
            case .trapped: return "Trapped"
            }
        }

        var isFinished: Bool {
            self == .exited || self == .trapped
        }
    }

    let index: Int
    let name: String
    let path: String
    let state: State
    let pc: UInt64
    let ticks: UInt64
    let slices: UInt64
    let exitCode: Int32
    let diagnosis: String

    var id: Int { index }
}

final class GuestRuntime {
    private(set) var pointer: OpaquePointer?

    init(pointer: OpaquePointer?) {
        self.pointer = pointer
    }

    func detach() {
        pointer = nil
    }

    var isAvailable: Bool { pointer != nil }

    // MARK: - Processes

    var processes: [GuestProcessInfo] {
        guard let pointer else { return [] }
        var result: [GuestProcessInfo] = []
        for index in 0..<Int(VORTEX_RUNTIME_MAX_PROCESSES) {
            var raw = vortex_runtime_process()
            guard vortex_runtime_process_at(pointer, index, &raw) else { continue }
            let name = withUnsafePointer(to: &raw.name) { buffer in
                buffer.withMemoryRebound(to: CChar.self, capacity: Int(VORTEX_RUNTIME_MAX_NAME)) {
                    String(cString: $0)
                }
            }
            let path = withUnsafePointer(to: &raw.path) { buffer in
                buffer.withMemoryRebound(to: CChar.self, capacity: Int(VORTEX_VFS_MAX_PATH)) {
                    String(cString: $0)
                }
            }
            let diagnosis = withUnsafePointer(to: &raw.diagnosis) { buffer in
                buffer.withMemoryRebound(to: CChar.self, capacity: 160) {
                    String(cString: $0)
                }
            }
            result.append(GuestProcessInfo(index: Int(index),
                                           name: name,
                                           path: path,
                                           state: GuestProcessInfo.State(rawValue: raw.state) ?? .unused,
                                           pc: raw.pc,
                                           ticks: raw.ticks,
                                           slices: raw.slices,
                                           exitCode: raw.exit_code,
                                           diagnosis: diagnosis))
        }
        return result
    }

    var runningCount: Int {
        processes.filter { $0.state == .ready || $0.state == .running }.count
    }

    var syscallCount: UInt64 {
        guard let pointer else { return 0 }
        return vortex_runtime_syscall_count(pointer)
    }

    var fragmentCount: Int { processes.count }

    // MARK: - Console

    /// Standard output of every process since the last clear.
    var consoleText: String {
        guard let pointer else { return "" }
        var buffer = [CChar](repeating: 0, count: 4096)
        let length = vortex_runtime_stdout(pointer, &buffer, buffer.count)
        guard length > 0 else { return "" }
        return String(cString: buffer)
    }

    func clearConsole() {
        guard let pointer else { return }
        vortex_runtime_clear_stdout(pointer)
    }

    var errorText: String {
        guard let pointer else { return "" }
        let text = String(cString: vortex_runtime_last_error(pointer))
        return text
    }

    /// The value the benchmark writes to guest memory, read straight out of the
    /// interpreter's arena so it is verified, not reported by the guest.
    func benchmarkResult(using core: VortexCoreHandle) -> UInt64? {
        core.cpu.readGuestWord(at: 0x8000)
    }
}
