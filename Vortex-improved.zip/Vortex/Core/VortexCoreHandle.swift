//
//  VortexCoreHandle.swift
//  Vortex
//
//  Swift ownership of the opaque C core handle.
//

import Foundation

/// Measured counters reported by the C core.
struct VortexCoreStats {
    var framesPresented: UInt64
    var framesSkipped: UInt64
    var guestTicks: UInt64
    var instructionsExecuted: UInt64
    var emulationErrors: UInt64
    var syscallsServiced: UInt64
    var guestProcesses: Int
    var guestRunning: Int
    var guestWidth: Int
    var guestHeight: Int
    var tickHz: Int

    static let zero = VortexCoreStats(framesPresented: 0,
                                     framesSkipped: 0,
                                     guestTicks: 0,
                                     instructionsExecuted: 0,
                                     emulationErrors: 0,
                                     syscallsServiced: 0,
                                     guestProcesses: 0,
                                     guestRunning: 0,
                                     guestWidth: 1280,
                                     guestHeight: 832,
                                     tickHz: Int(VORTEX_GUEST_TICK_HZ))
}

/// Sole owner of a `vortex_core` instance.
///
/// The handle is created once per app launch and destroyed on deinit. Every
/// call must happen on the main thread: the render loop is the only caller.
final class VortexCoreHandle {
    private var handle = vortex_core_create()
    private var cpuStorage: GuestCPU?

    init() {}

    deinit {
        cpuStorage?.detach()
        cpuStorage = nil
        if let handle {
            vortex_core_destroy(handle)
        }
        handle = nil
    }

    /// Guest CPU owned by the core. Created on first use.
    var cpu: GuestCPU {
        if let existing = cpuStorage {
            return existing
        }
        let created = GuestCPU(pointer: handle.map { vortex_core_get_cpu($0) })
        cpuStorage = created
        return created
    }

    var isReady: Bool { handle != nil }

    static var abiVersion: UInt32 { vortex_core_abi_version() }

    static var buildLabel: String {
        guard let label = vortex_core_build_label() else { return "unknown" }
        return String(cString: label)
    }

    var stats: VortexCoreStats {
        guard let handle else { return .zero }
        let raw = vortex_core_get_stats(handle)
        return VortexCoreStats(framesPresented: raw.frames_presented,
                               framesSkipped: raw.frames_skipped,
                               guestTicks: raw.guest_ticks,
                               instructionsExecuted: raw.instructions_executed,
                               emulationErrors: raw.emulation_errors,
                               syscallsServiced: raw.syscalls_serviced,
                               guestProcesses: Int(raw.guest_processes),
                               guestRunning: Int(raw.guest_running),
                               guestWidth: Int(raw.guest_width),
                               guestHeight: Int(raw.guest_height),
                               tickHz: Int(raw.tick_hz))
    }

    // MARK: - Runtime

    /// The C runtime handle, or nil when the core failed to allocate.
    var runtimePointer: OpaquePointer? {
        guard let handle else { return nil }
        return vortex_core_get_runtime(handle)
    }

    /// Filesystem handle, or nil when the core failed to allocate.
    var filesystemPointer: OpaquePointer? {
        guard let handle else { return nil }
        return vortex_core_get_vfs(handle)
    }

    /// Instructions per scheduling slice, shared by every guest process.
    var sliceBudget: Int {
        get { Int(vortex_core_slice_budget(handle)) }
        set { vortex_core_set_slice_budget(handle, newValue) }
    }

    @discardableResult
    func launchSample(_ program: VortexGuestProgram) -> Int32 {
        guard let handle else { return -1 }
        return vortex_core_launch_sample(handle, program.cValue)
    }

    @discardableResult
    func launchPackage(name: String, path: String) -> Int32 {
        guard let handle else { return -1 }
        return path.withCString { pointer in
            vortex_core_launch_package(handle, name, pointer)
        }
    }

    func stopGuests() {
        guard let handle else { return }
        vortex_core_stop_guests(handle)
    }

    /// Reason the runtime refused its last operation, or nil when it did not.
    var runtimeErrorText: String? {
        guard let runtime = runtimePointer else { return "The runtime is not attached." }
        let text = String(cString: vortex_runtime_last_error(runtime))
        return text.isEmpty ? nil : text
    }

    /// Reason the filesystem refused its last operation, or nil.
    var filesystemErrorText: String? {
        guard let pointer = filesystemPointer else { return "The filesystem is not mounted." }
        let text = String(cString: vortex_vfs_last_error(pointer))
        return text.isEmpty ? nil : text
    }

    @discardableResult
    func saveFilesystem(to path: String) -> Bool {
        guard let handle else { return false }
        return path.withCString { vortex_core_save_filesystem(handle, $0) }
    }

    @discardableResult
    func loadFilesystem(from path: String) -> Bool {
        guard let handle else { return false }
        return path.withCString { vortex_core_load_filesystem(handle, $0) }
    }

    // MARK: - Frame buffer

    static var guestFramebufferWidth: Int { Int(vortex_core_guest_framebuffer_width()) }
    static var guestFramebufferHeight: Int { Int(vortex_core_guest_framebuffer_height()) }

    /// True when a guest painted the frame buffer since the last call.
    var takeFramebufferDirty: Bool {
        guard let handle else { return false }
        return vortex_core_take_framebuffer_dirty(handle)
    }

    /// Copies the guest frame buffer (BGRA, guest size) into a destination.
    func copyFramebuffer(into destination: UnsafeMutableRawPointer, length: Int) {
        let required = Self.guestFramebufferWidth * Self.guestFramebufferHeight * 4
        guard let handle, length >= required else { return }
        vortex_core_copy_framebuffer(handle, destination)
    }

    /// Normalised horizontal position of the test-pattern marker.
    var markerPosition: Float {
        guard let handle else { return 0.12 }
        return vortex_core_marker_position(handle)
    }

    @discardableResult
    func advance(delta: Double) -> Bool {
        guard let handle else { return false }
        return vortex_core_advance(handle, delta)
    }

    func noteFramePresented() {
        guard let handle else { return }
        vortex_core_note_frame_presented(handle)
    }

    func noteFrameSkipped() {
        guard let handle else { return }
        vortex_core_note_frame_skipped(handle)
    }

    func noteError() {
        guard let handle else { return }
        vortex_core_note_error(handle)
    }

    func reset() {
        guard let handle else { return }
        vortex_core_reset(handle)
    }

    @discardableResult
    func setGuestSize(width: Int, height: Int) -> Bool {
        guard let handle, width > 0, height > 0 else { return false }
        return vortex_core_set_guest_size(handle, UInt32(width), UInt32(height))
    }
}
