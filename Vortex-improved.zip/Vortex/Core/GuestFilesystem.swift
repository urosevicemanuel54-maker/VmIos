//
//  GuestFilesystem.swift
//  Vortex
//
//  Swift surface for the virtual filesystem: a path-based view of the C tree,
//  plus the app-side policy of where its container file lives and how packages
//  are validated before they are installed.
//

import Foundation

struct VirtualFileEntry: Identifiable, Equatable {
    enum Kind: Equatable {
        case file
        case directory

        var label: String {
            switch self {
            case .file: return "File"
            case .directory: return "Folder"
            }
        }

        var symbolName: String {
            switch self {
            case .file: return "doc.fill"
            case .directory: return "folder.fill"
            }
        }
    }

    let path: String
    let kind: Kind
    let size: UInt64

    var id: String { path }

    /// Final path component, or "/" for the root.
    var name: String {
        guard path != "/" else { return "/" }
        return (path as NSString).lastPathComponent
    }

    var depth: Int {
        max(0, path.split(separator: "/").count - 1)
    }
}

enum PackageValidationError: Error, Equatable, LocalizedError {
    case unreadableContainer
    case missingManifest
    case tooManyFiles(Int)
    case invalidManifest(String)
    case missingExecutable(String)
    case executableNotAligned(String)

    var errorDescription: String? {
        switch self {
        case .unreadableContainer:
            return "The folder could not be read, or it is empty."
        case .missingManifest:
            return "No manifest.json at the top of the folder."
        case .tooManyFiles(let count):
            return "The folder holds \(count) files; a virtual package may hold at most \(AppPackage.maximumFileCount)."
        case .invalidManifest(let detail):
            return "The manifest is not valid: \(detail)"
        case .missingExecutable(let path):
            return "The manifest names \(path) as its entry executable, but the package does not contain it."
        case .executableNotAligned(let path):
            return "\(path) is \(PackageValidationError.detail(for: path)) bytes; an ARM64 image must be a multiple of four."
        }
    }

    private static func detail(for path: String) -> String {
        path
    }
}

/// The manifest a virtual package carries, and the app it describes.
struct AppPackage: Equatable {
    static let manifestName = "manifest.json"
    static let maximumFileCount = 64
    static let maximumExecutableBytes = 512 * 1024

    var identifier: String
    var displayName: String
    var version: String
    var executable: String
    var capabilities: [String]

    /// Lowers a display name into an identifier-shaped string for the manifest
    /// when the package author left one out.
    static func identifier(from displayName: String) -> String {
        let lowered = displayName.lowercased()
        let allowed = lowered.map { character -> Character in
            if character.isLetter || character.isNumber { return character }
            return "-"
        }
        let joined = String(allowed)
        let collapsed = joined.split(separator: "-").joined(separator: "-")
        return collapsed.isEmpty ? "app" : collapsed
    }
}

/// A file staged in the app's Documents folder for import.
struct ImportCandidate: Identifiable, Equatable {
    let url: URL
    let name: String
    let isDirectory: Bool

    var id: String { url.path }
}

final class GuestFilesystem {
    private(set) var pointer: OpaquePointer?

    /// The container is one file in Application Support; the host writes it, the
    /// guest never sees the path.
    static var containerURL: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        return base.appendingPathComponent("Vortex", isDirectory: true)
            .appendingPathComponent("filesystem.vfs")
    }

    static var documentsURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
    }

    init(pointer: OpaquePointer?) {
        self.pointer = pointer
    }

    func detach() {
        pointer = nil
    }

    var isAvailable: Bool { pointer != nil }

    // MARK: - Reading

    var entries: [VirtualFileEntry] {
        guard let pointer else { return [] }
        let count = vortex_vfs_node_count(pointer)
        var result: [VirtualFileEntry] = []
        result.reserveCapacity(Int(count))
        for index in 0..<count {
            var raw = vortex_vfs_stat()
            guard vortex_vfs_node_at(pointer, index, &raw) else { continue }
            let path = withUnsafePointer(to: &raw.path) { buffer in
                buffer.withMemoryRebound(to: CChar.self, capacity: Int(VORTEX_VFS_MAX_PATH)) {
                    String(cString: $0)
                }
            }
            result.append(VirtualFileEntry(path: path,
                                           kind: raw.type == UInt32(VORTEX_VFS_TYPE_DIRECTORY.rawValue)
                                               ? .directory
                                               : .file,
                                           size: raw.size))
        }
        return result.sorted { lhs, rhs in
            if lhs.path == "/" { return true }
            if rhs.path == "/" { return false }
            return lhs.path.localizedStandardCompare(rhs.path) == .orderedAscending
        }
    }

    var nodeCount: Int {
        guard let pointer else { return 0 }
        return Int(vortex_vfs_node_count(pointer))
    }

    var usedBytes: UInt64 {
        entries.reduce(0) { $0 + $1.size }
    }

    var lastError: String {
        guard let pointer else { return "The filesystem is not mounted." }
        let text = String(cString: vortex_vfs_last_error(pointer))
        return text.isEmpty ? "" : text
    }

    @discardableResult
    func createDirectory(_ path: String) -> Bool {
        guard let pointer else { return false }
        return path.withCString { vortex_vfs_mkdir(pointer, $0) }
    }

    @discardableResult
    func writeFile(_ path: String, data: Data) -> Bool {
        guard let pointer, !data.isEmpty else { return false }
        return data.withUnsafeBytes { buffer -> Bool in
            guard let base = buffer.baseAddress else { return false }
            return path.withCString { vortex_vfs_write_file(pointer, $0, base, data.count) }
        }
    }

    func readFile(_ path: String) -> Data? {
        guard let pointer else { return nil }
        var buffer = [UInt8](repeating: 0, count: AppPackage.maximumExecutableBytes)
        let read = buffer.withUnsafeMutableBytes { raw -> Int in
            guard let base = raw.baseAddress else { return 0 }
            return path.withCString { vortex_vfs_read_file(pointer, $0, base, raw.count) }
        }
        guard read > 0 else { return nil }
        return Data(buffer.prefix(read))
    }

    @discardableResult
    func remove(_ path: String) -> Bool {
        guard let pointer else { return false }
        return path.withCString { vortex_vfs_remove(pointer, $0) }
    }

    /// Whether an absolute path is acceptable to the filesystem at all.
    static func validatePath(_ path: String) -> Bool {
        var output = [CChar](repeating: 0, count: Int(VORTEX_VFS_MAX_PATH))
        return path.withCString { input in
            vortex_vfs_normalise(input, &output, output.count)
        }
    }

    // MARK: - Persistence

    @discardableResult
    func save(to url: URL = GuestFilesystem.containerURL) -> Bool {
        guard let pointer else { return false }
        let directory = url.deletingLastPathComponent()
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return url.path.withCString { vortex_vfs_save(pointer, $0) }
    }

    /// Loads the container, or builds the default tree when there is no
    /// container or it is unreadable.
    func load(from url: URL = GuestFilesystem.containerURL) {
        guard let pointer else { return }
        if url.path.withCString({ vortex_vfs_load(pointer, $0) }) {
            return
        }
        seedDefaultTree()
        save(to: url)
    }

    /// The tree a fresh install boots with. Files here are the stock content the
    /// simulated environment shows in its Files app.
    func seedDefaultTree() {
        guard pointer != nil else { return }
        _ = createDirectory("/Apps")
        _ = createDirectory("/Documents")
        _ = createDirectory("/System")

        writeFile("/System/version.txt", data: Data("Vortex virtual filesystem 0.2\nNot Apple's filesystem.\n".utf8))
        writeFile("/Documents/readme.txt", data: Data("""
            Vortex virtual filesystem
            -------------------------
            This tree lives inside one container file in the app's Application
            Support directory. Guest processes reach it only through the runtime's
            syscall table (open, read, write, close).

            Install a package by making a folder with a manifest.json and an
            executable, then importing it from the Files screen.
            """.utf8))
    }

    // MARK: - Package import

    /// Reads a staged folder and returns its manifest and payload without
    /// touching the virtual filesystem.
    static func inspectPackage(at url: URL) throws -> (manifest: AppPackage, files: [(path: String, data: Data)]) {
        let manager = FileManager.default
        guard let enumerator = manager.enumerator(at: url,
                                                  includingPropertiesForKeys: [.isRegularFileKey, .fileSizeKey],
                                                  options: [.skipsHiddenFiles]) else {
            throw PackageValidationError.unreadableContainer
        }

        var files: [(path: String, data: Data)] = []
        var manifestData: Data?
        let rootPrefix = url.standardizedFileURL.path

        for case let fileURL as URL in enumerator {
            let values = try? fileURL.resourceValues(forKeys: [.isRegularFileKey])
            guard values?.isRegularFile == true else { continue }

            let full = fileURL.standardizedFileURL.path
            guard full.hasPrefix(rootPrefix) else { continue }
            var relative = String(full.dropFirst(rootPrefix.count))
            if relative.hasPrefix("/") { relative.removeFirst() }
            if relative.isEmpty { continue }

            if files.count >= AppPackage.maximumFileCount {
                throw PackageValidationError.tooManyFiles(files.count + 1)
            }

            guard let data = try? Data(contentsOf: fileURL) else {
                throw PackageValidationError.unreadableContainer
            }
            if relative == AppPackage.manifestName {
                manifestData = data
            }
            files.append((relative, data))
        }

        guard !files.isEmpty else { throw PackageValidationError.unreadableContainer }
        guard let manifestData else { throw PackageValidationError.missingManifest }
        let manifest = try decodeManifest(manifestData)

        guard let executable = files.first(where: { $0.path == manifest.executable }) else {
            throw PackageValidationError.missingExecutable(manifest.executable)
        }
        guard executable.data.count % 4 == 0, !executable.data.isEmpty else {
            throw PackageValidationError.executableNotAligned(manifest.executable)
        }
        guard executable.data.count <= AppPackage.maximumExecutableBytes else {
            throw PackageValidationError.unreadableContainer
        }

        return (manifest, files)
    }

    static func decodeManifest(_ data: Data) throws -> AppPackage {
        guard let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw PackageValidationError.invalidManifest("it is not a JSON object")
        }

        let displayName = (object["displayName"] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines)
        let identifier = (object["identifier"] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines)
        let version = (object["version"] as? String) ?? "1.0"
        let executable = (object["executable"] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines)
        let capabilities = (object["capabilities"] as? [String]) ?? []

        guard let displayName, !displayName.isEmpty, displayName.count <= 32 else {
            throw PackageValidationError.invalidManifest("displayName must be 1 to 32 characters")
        }
        guard let executable, !executable.isEmpty, !executable.hasPrefix("/"), !executable.contains("..") else {
            throw PackageValidationError.invalidManifest("executable must be a relative path inside the package")
        }
        if let identifier, identifier.isEmpty {
            throw PackageValidationError.invalidManifest("identifier cannot be blank")
        }

        return AppPackage(identifier: identifier ?? AppPackage.identifier(from: displayName),
                          displayName: displayName,
                          version: version,
                          executable: executable,
                          capabilities: capabilities)
    }

    /// Copies an inspected package into the virtual filesystem under /Apps.
    /// Returns the installed root path, or throws with the reason.
    @discardableResult
    func install(_ inspection: (manifest: AppPackage, files: [(path: String, data: Data)])) throws -> String {
        guard pointer != nil else { throw PackageValidationError.unreadableContainer }

        let root = "/Apps/\(inspection.manifest.identifier)"
        _ = createDirectory("/Apps")
        _ = remove(root)
        guard createDirectory(root) else {
            throw PackageValidationError.unreadableContainer
        }

        var createdDirectories = Set<String>()
        for file in inspection.files {
            let destination = "\(root)/\(file.path)"
            let parent = (destination as NSString).deletingLastPathComponent
            if parent != root, !createdDirectories.contains(parent) {
                var path = ""
                for component in parent.split(separator: "/") {
                    path += "/\(component)"
                    if path != root {
                        _ = createDirectory(path)
                    }
                }
                createdDirectories.insert(parent)
            }
            guard writeFile(destination, data: file.data) else {
                _ = remove(root)
                throw PackageValidationError.executableNotAligned(file.path)
            }
        }
        return root
    }

    /// Installed packages, discovered by looking for a manifest under /Apps.
    var installedPackages: [AppPackage] {
        let all = entries
        return all.compactMap { entry -> AppPackage? in
            guard entry.kind == .file, entry.name == AppPackage.manifestName else { return nil }
            guard let data = readFile(entry.path) else { return nil }
            return try? Self.decodeManifest(data)
        }
    }

    // MARK: - Import staging

    /// Packages and folders waiting in Documents for an explicit import. Nothing
    /// is installed until the user asks for it.
    static func importCandidates() -> [ImportCandidate] {
        let manager = FileManager.default
        guard let contents = try? manager.contentsOfDirectory(at: documentsURL,
                                                             includingPropertiesForKeys: [.isDirectoryKey],
                                                             options: [.skipsHiddenFiles]) else {
            return []
        }

        return contents.compactMap { url -> ImportCandidate? in
            let name = url.lastPathComponent
            if name == "StikJIT" { return nil }
            let values = try? url.resourceValues(forKeys: [.isDirectoryKey])
            let isDirectory = values?.isDirectory ?? false
            // A loose file only makes sense if it is a ZIP this build cannot open.
            if !isDirectory && !name.lowercased().hasSuffix(".json") { return nil }
            return ImportCandidate(url: url, name: name, isDirectory: isDirectory)
        }
        .sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }
}
